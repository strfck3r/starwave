#!/usr/bin/env python3
"""
scripts/stream-qc.py - Automated IPTV Stream Health & Resolution QC Validator

Fetches live channel feeds from Samsung TV Plus and The Roku Channel, probes
HLS master playlists for stream availability and maximum decoded resolution,
filters out dead channels and streams < 720p, and outputs a clean M3U playlist
and QC audit report for Kodi IPTV Simple Client / IPTV Merge.
"""

import argparse
import gzip
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
from typing import Any, Dict, List, Optional, Tuple

SAMSUNG_DATA_URL = "https://i.mjh.nz/SamsungTVPlus/.channels.json.gz"
ROKU_DATA_URL = "https://i.mjh.nz/Roku/.channels.json.gz"

CREW_CHANNELS_URL = "https://raw.githubusercontent.com/posadka/xmls2/main/sports/channels/channels.xml"

DEFAULT_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
SAMSUNG_USER_AGENT = "okhttp/4.12.0"


def fetch_json_gz(url: str, timeout: int = 15) -> Dict[str, Any]:
    """Fetch and decompress gzipped JSON data."""
    req = urllib.request.Request(url, headers={"User-Agent": DEFAULT_USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(gzip.decompress(resp.read()))


def probe_hls_stream(
    url: str,
    user_agent: str = DEFAULT_USER_AGENT,
    headers: Optional[Dict[str, str]] = None,
    timeout: int = 10,
) -> Tuple[bool, Optional[int], str, List[Tuple[int, int]]]:
    """
    Probe an HLS stream URL.
    Returns:
        (is_alive: bool, max_height: Optional[int], reason: str, resolutions: List[(width, height)])
    """
    try:
        req_headers = {"User-Agent": user_agent}
        actual_url = url
        if "|" in url:
            actual_url, _, tail = url.partition("|")
            for part in tail.split("&"):
                if "=" in part:
                    k, v = part.split("=", 1)
                    k = k.strip()
                    v = v.strip()
                    if k.lower() == "user-agent":
                        req_headers["User-Agent"] = v
                    else:
                        req_headers[k] = v
        if headers:
            for k, v in headers.items():
                if k.lower() == "user-agent":
                    req_headers["User-Agent"] = v
                else:
                    req_headers[k] = v
        req = urllib.request.Request(actual_url, headers=req_headers)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            content = resp.read().decode("utf-8", errors="ignore")
            final_url = resp.geturl()

            # Parse RESOLUTION=WxH in master playlist
            res_matches = re.findall(r"RESOLUTION=(\d+)x(\d+)", content)
            resolutions = [(int(w), int(h)) for w, h in res_matches]

            if resolutions:
                max_h = max(h for w, h in resolutions)
                return True, max_h, "OK", resolutions
            elif "#EXTINF" in content:
                # Direct media playlist without master variants; height is unmeasured from text
                return True, None, "Direct media playlist (no explicit resolution tag)", []
            elif "#EXTM3U" in content:
                return True, None, "HLS master without explicit resolution tags", []
            else:
                return False, None, "Invalid HLS response format", []
    except urllib.error.HTTPError as e:
        if e.code in (401, 403, 451):
            return False, None, f"Geoblocked/Unauthorized (HTTP {e.code})", []
        elif e.code == 404:
            return False, None, f"Not Found (HTTP 404)", []
        else:
            return False, None, f"HTTP Error {e.code}", []
    except urllib.error.URLError as e:
        return False, None, f"Connection Failed: {e.reason}", []
    except TimeoutError:
        return False, None, "Connection Timeout", []
    except Exception as e:
        return False, None, f"Unexpected Error: {str(e)}", []


def collect_channels(provider: str = "all", region: str = "us", timeout: int = 15) -> List[Dict[str, Any]]:
    """Collect candidate channels from selected FAST providers and sports indexes."""
    channels: List[Dict[str, Any]] = []

    if provider in ("all", "samsung"):
        try:
            sam_data = fetch_json_gz(SAMSUNG_DATA_URL, timeout=timeout)
            reg_channels = sam_data.get("regions", {}).get(region, {}).get("channels", {})
            for ch_id, ch in reg_channels.items():
                if ch.get("license_url"):
                    continue  # Skip DRM-locked entries
                channels.append({
                    "id": f"samsung_{ch_id}",
                    "raw_id": ch_id,
                    "provider": "samsung",
                    "name": ch.get("name", ch_id),
                    "chno": int(ch.get("chno", 9999)),
                    "logo": ch.get("logo", ""),
                    "group": ch.get("group", "General"),
                    "stream_url": f"https://jmp2.uk/stvp-{ch_id}",
                    "user_agent": SAMSUNG_USER_AGENT,
                    "headers": {},
                    "description": ch.get("description", ""),
                })
        except Exception as e:
            print(f"[WARN] Failed to fetch Samsung TV Plus channels: {e}", file=sys.stderr)

    if provider in ("all", "roku"):
        try:
            roku_data = fetch_json_gz(ROKU_DATA_URL, timeout=timeout)
            for ch_id, ch in roku_data.get("channels", {}).items():
                groups = ch.get("groups", [])
                group = groups[0] if groups else "General"
                channels.append({
                    "id": f"roku_{ch_id}",
                    "raw_id": ch_id,
                    "provider": "roku",
                    "name": ch.get("name", ch_id),
                    "chno": int(ch.get("chno", 9999)),
                    "logo": ch.get("logo", ""),
                    "group": group,
                    "stream_url": f"https://jmp2.uk/rok-{ch_id}.m3u8",
                    "user_agent": DEFAULT_USER_AGENT,
                    "headers": {},
                    "description": ch.get("description", ""),
                })
        except Exception as e:
            print(f"[WARN] Failed to fetch Roku channels: {e}", file=sys.stderr)

    if provider in ("all", "crew", "crew-sports"):
        try:
            req = urllib.request.Request(CREW_CHANNELS_URL, headers={"User-Agent": DEFAULT_USER_AGENT})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                content = resp.read().decode("utf-8", errors="ignore")
            items = re.findall(r"<item>(.*?)</item>", content, re.S)
            for i, it in enumerate(items):
                title_m = re.search(r"<title>(.*?)</title>", it, re.S)
                logo_m = re.search(r"<thumbnail>(.*?)</thumbnail>", it, re.S)
                name = re.sub(r"\[.*?\]", "", title_m.group(1)).strip() if title_m else f"Crew Sports {i+1}"
                logo = logo_m.group(1).strip() if logo_m else ""

                links = re.findall(r"<sublink>(.*?)</sublink>", it, re.S)
                if not links:
                    l = re.search(r"<link>(.*?)</link>", it, re.S)
                    if l and l.group(1) != "0" and not l.group(1).startswith("$doregex"):
                        links = [l.group(1).strip()]

                for idx, raw_link in enumerate(links):
                    parts = raw_link.split("|")
                    stream_url = parts[0].strip()
                    ch_headers = {}
                    for p in parts[1:]:
                        if "=" in p:
                            k, v = p.split("=", 1)
                            ch_headers[k.strip()] = v.strip()

                    user_agent = ch_headers.get("User-Agent", DEFAULT_USER_AGENT)
                    ch_id = f"crew_{re.sub(r'[^a-zA-Z0-9_]', '', name.lower().replace(' ', '_'))}_{idx+1}"
                    channels.append({
                        "id": ch_id,
                        "raw_id": f"crew_{i}_{idx}",
                        "provider": "crew",
                        "name": f"{name} (Link {idx+1})" if len(links) > 1 else name,
                        "chno": 9000 + len(channels),
                        "logo": logo,
                        "group": "The Crew Sports",
                        "stream_url": stream_url,
                        "user_agent": user_agent,
                        "headers": ch_headers,
                        "description": f"The Crew Sports channel: {name}",
                    })
        except Exception as e:
            print(f"[WARN] Failed to fetch The Crew channels: {e}", file=sys.stderr)

    return sorted(channels, key=lambda c: (c["provider"], c["chno"], c["name"]))


def run_audit(
    channels: List[Dict[str, Any]],
    min_resolution: int = 720,
    workers: int = 10,
    timeout: int = 10,
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], Dict[str, Any]]:
    """Run concurrent QC audit on candidate channels."""
    passed: List[Dict[str, Any]] = []
    failed: List[Dict[str, Any]] = []
    stats = {
        "total_probed": len(channels),
        "passed": 0,
        "failed_dead": 0,
        "failed_sub_720": 0,
        "failed_geoblock": 0,
        "resolution_histogram": {"1080p": 0, "720p": 0, "sub_720p": 0, "unknown": 0},
    }

    def _probe_worker(ch: Dict[str, Any]) -> Tuple[Dict[str, Any], bool, Optional[int], str, List[Tuple[int, int]]]:
        alive, max_h, reason, res_list = probe_hls_stream(
            ch["stream_url"],
            user_agent=ch.get("user_agent", DEFAULT_USER_AGENT),
            headers=ch.get("headers"),
            timeout=timeout,
        )
        return ch, alive, max_h, reason, res_list

    def _process_result(res_tuple: Tuple[Dict[str, Any], bool, Optional[int], str, List[Tuple[int, int]]]) -> None:
        ch, alive, max_h, reason, res_list = res_tuple
        ch_record = dict(ch)
        ch_record["max_resolution"] = max_h
        ch_record["qc_reason"] = reason
        ch_record["variants"] = [f"{w}x{h}" for w, h in res_list]

        if not alive:
            if "Geoblocked" in reason:
                stats["failed_geoblock"] += 1
            else:
                stats["failed_dead"] += 1
            failed.append(ch_record)
        elif max_h is not None and max_h < min_resolution:
            stats["failed_sub_720"] += 1
            stats["resolution_histogram"]["sub_720p"] += 1
            ch_record["qc_reason"] = f"Sub-threshold resolution ({max_h}p < {min_resolution}p)"
            failed.append(ch_record)
        else:
            stats["passed"] += 1
            if max_h and max_h >= 1080:
                stats["resolution_histogram"]["1080p"] += 1
            elif max_h and max_h >= 720:
                stats["resolution_histogram"]["720p"] += 1
            else:
                stats["resolution_histogram"]["unknown"] += 1
            passed.append(ch_record)

    try:
        import concurrent.futures
        has_concurrent = True
    except ImportError:
        has_concurrent = False

    if has_concurrent and workers > 1:
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
            futures = [executor.submit(_probe_worker, ch) for ch in channels]
            for future in concurrent.futures.as_completed(futures):
                _process_result(future.result())
    else:
        for ch in channels:
            _process_result(_probe_worker(ch))

    passed.sort(key=lambda c: (c["provider"], c["chno"], c["name"]))
    failed.sort(key=lambda c: (c["provider"], c["chno"], c["name"]))
    return passed, failed, stats


def generate_m3u(channels: List[Dict[str, Any]], title: str = "StarWave IPTV") -> str:
    """Generate standard IPTV M3U8 content."""
    lines = [f"#EXTM3U name=\"{title}\""]
    for ch in channels:
        chno_tag = f" tvg-chno=\"{ch['chno']}\"" if ch.get("chno") else ""
        logo_tag = f" tvg-logo=\"{ch['logo']}\"" if ch.get("logo") else ""
        group_tag = f" group-title=\"{ch['group']}\"" if ch.get("group") else ""
        lines.append(f"#EXTINF:-1 tvg-id=\"{ch['id']}\" tvg-name=\"{ch['name']}\"{chno_tag}{logo_tag}{group_tag},{ch['name']}")
        if ch.get("user_agent"):
            lines.append(f"#EXTVLCOPT:http-user-agent={ch['user_agent']}")
        if ch.get("headers"):
            for hk, hv in ch["headers"].items():
                if hk.lower() == "referer":
                    lines.append(f"#EXTVLCOPT:http-referrer={hv}")
        lines.append("#KODIPROP:inputstream.adaptive.manifest_type=hls")
        lines.append(ch["stream_url"])
    return "\n".join(lines) + "\n"


def main():
    parser = argparse.ArgumentParser(description="StarWave IPTV Stream Health & Resolution QC Validator")
    parser.add_argument("--provider", choices=["all", "samsung", "roku", "crew", "crew-sports"], default="all", help="Provider to probe")
    parser.add_argument("--min-resolution", type=int, default=720, help="Minimum vertical video resolution in pixels (default: 720)")
    parser.add_argument("--workers", type=int, default=10, help="Concurrent worker threads (default: 10)")
    parser.add_argument("--timeout", type=int, default=10, help="Stream probe timeout in seconds (default: 10)")
    parser.add_argument("--sample", type=int, default=None, help="Probe only first N candidate channels")
    parser.add_argument("--output-dir", default="docs/iptv", help="Directory to save output M3U and QC report")
    parser.add_argument("--m3u-filename", default=None, help="Custom filename for M3U playlist (default: channels.m3u8 or crew_sports.m3u8)")
    parser.add_argument("--report-filename", default=None, help="Custom filename for QC JSON report (default: qc_report.json or crew_sports_qc.json)")
    parser.add_argument("--dry-run", action="store_true", help="Print summary without writing files")

    args = parser.parse_args()

    print(f"=== StarWave Stream QC: Provider={args.provider}, MinResolution={args.min_resolution}p ===")
    channels = collect_channels(provider=args.provider, timeout=args.timeout)
    print(f"Collected {len(channels)} candidate channels.")

    if args.sample:
        channels = channels[:args.sample]
        print(f"Sample mode enabled: Probing {len(channels)} channels.")

    start_t = time.time()
    passed, failed, stats = run_audit(
        channels,
        min_resolution=args.min_resolution,
        workers=args.workers,
        timeout=args.timeout,
    )
    elapsed = time.time() - start_t

    stats["elapsed_seconds"] = round(elapsed, 2)
    stats["min_resolution_threshold"] = args.min_resolution
    stats["generated_at"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

    print(f"\n--- QC Audit Summary (Completed in {stats['elapsed_seconds']}s) ---")
    print(f"Total Probed:    {stats['total_probed']}")
    print(f"Passed (>= {args.min_resolution}p):  {stats['passed']}")
    print(f"Failed Dead:     {stats['failed_dead']}")
    print(f"Failed Sub-{args.min_resolution}p: {stats['failed_sub_720']}")
    print(f"Failed Geoblock: {stats['failed_geoblock']}")
    print(f"Resolution Breakdown: 1080p={stats['resolution_histogram']['1080p']}, 720p={stats['resolution_histogram']['720p']}")

    if not args.dry_run:
        os.makedirs(args.output_dir, exist_ok=True)
        m3u_file = args.m3u_filename or ("crew_sports.m3u8" if "crew" in args.provider else "channels.m3u8")
        report_file = args.report_filename or ("crew_sports_qc.json" if "crew" in args.provider else "qc_report.json")
        m3u_path = os.path.join(args.output_dir, m3u_file)
        report_path = os.path.join(args.output_dir, report_file)

        title = "The Crew Sports IPTV" if "crew" in args.provider else "StarWave IPTV"
        with open(m3u_path, "w", encoding="utf-8") as f:
            f.write(generate_m3u(passed, title=title))

        with open(report_path, "w", encoding="utf-8") as f:
            json.dump({
                "stats": stats,
                "passed_channels": passed,
                "failed_channels": failed,
            }, f, indent=2)

        print(f"\nWrote filtered playlist to: {m3u_path}")
        print(f"Wrote audit report to:      {report_path}")


if __name__ == "__main__":
    main()

