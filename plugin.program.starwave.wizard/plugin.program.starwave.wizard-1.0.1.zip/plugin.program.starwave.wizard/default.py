# -*- coding: utf-8 -*-
"""StarWave Wizard — downloads the StarWave build and applies it to this Kodi."""

import os
import sys
import shutil
from urllib.parse import urlencode, parse_qsl
from urllib.request import Request, urlopen

import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ICON = ADDON.getAddonInfo('icon')
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1

# 'latest' resolves to the newest release carrying this asset, so the wizard
# keeps working when a new build is published without needing an update itself.
BUILD_URL = 'https://github.com/strfck3r/starwave/releases/latest/download/StarWave-V1-kodi.zip'

HOME = xbmcvfs.translatePath('special://home/')
PACKAGES = os.path.join(HOME, 'addons', 'packages')
TEMP_ZIP = os.path.join(xbmcvfs.translatePath('special://temp/'), 'starwave-build.zip')
ADDONS_DB = os.path.join(HOME, 'userdata', 'Database', 'Addons33.db')

# The build is assembled on an NVIDIA Shield, so these two ship as android-aarch64 binaries.
# They cannot load anywhere else, and installing them would replace whatever the host Kodi
# already has. Everything else in the build is Python, skin XML or images and is portable.
ANDROID_ONLY = ('inputstream.adaptive', 'vfs.libarchive')


def is_android():
    return xbmc.getCondVisibility('System.Platform.Android')


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), level)


def notify(msg, ms=4000):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, ICON, ms)


def build_url(**kwargs):
    return '%s?%s' % (sys.argv[0], urlencode(kwargs))


def add_item(label, action, description, folder=False):
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': ICON, 'thumb': ICON})
    li.setInfo('video', {'title': label, 'plot': description})
    xbmcplugin.addDirectoryItem(HANDLE, build_url(action=action), li, folder)


def menu():
    add_item(
        'Install the StarWave build',
        'install',
        'Downloads the current StarWave build and applies it to this Kodi: skin, home menu, '
        'widgets, add-ons and their configuration.\n\n'
        'This replaces your current Kodi setup. Kodi closes when it finishes — reopen it and '
        'you are on StarWave.',
    )
    add_item(
        'What this installs',
        'info',
        'Details of the build and what the install replaces.',
    )
    xbmcplugin.endOfDirectory(HANDLE)


def show_info():
    xbmcgui.Dialog().textviewer(
        ADDON_NAME,
        'StarWave — a Kodi 21 "Omega" build.\n\n'
        'INSTALLS\n'
        '  108 add-ons, the StarWave skin, the home menu and its widgets, and the Star Hubs '
        'setup screen.\n\n'
        'REPLACES\n'
        '  Your skin, home menu and widget layout.\n'
        '  The settings of any add-on the build also ships — including saved logins. Add-ons '
        'you have that the build does not are left alone.\n\n'
        'DOES NOT INCLUDE\n'
        '  Any Real-Debrid, Premiumize, Trakt or AniList credentials. Sign in afterwards via '
        'Trakt > Setup.\n\n'
        'AFTERWARDS\n'
        '  Kodi is closed so it cannot write its old settings back over the new ones. Reopen '
        'Kodi to come up on StarWave.\n\n'
        'For a predictable result, run this on a fresh Kodi install.',
    )


def _cleanup_temp():
    try:
        if os.path.exists(TEMP_ZIP):
            os.remove(TEMP_ZIP)
    except OSError as exc:
        log('could not remove temp zip: %s' % exc, xbmc.LOGWARNING)


def download(url, dest, dialog):
    """Stream the build to dest, driving the progress dialog. Returns False if cancelled."""
    req = Request(url, headers={'User-Agent': 'StarWave-Wizard'})
    resp = urlopen(req, timeout=30)
    total = resp.getheader('content-length')
    total = int(total) if total and total.isdigit() else 0
    total_mb = total / 1048576.0
    got = 0
    block = 1024 * 256

    with open(dest, 'wb') as fh:
        while True:
            if dialog.iscanceled():
                return False
            chunk = resp.read(block)
            if not chunk:
                break
            fh.write(chunk)
            got += len(chunk)
            if total:
                pct = int(got * 100 / total)
                dialog.update(
                    pct,
                    'Downloading the build\n%.0f of %.0f MB' % (got / 1048576.0, total_mb),
                )
            else:
                dialog.update(0, 'Downloading the build\n%.0f MB' % (got / 1048576.0))

    if total and got < total:
        raise IOError('download truncated: got %d of %d bytes' % (got, total))
    return True


def _skip(name, skip_ids):
    return any(name.startswith('addons/%s/' % a) for a in skip_ids)


def extract(zip_path, dest, dialog, skip_ids=()):
    """Extract into dest, omitting add-ons in skip_ids. Returns False if cancelled."""
    import zipfile

    with zipfile.ZipFile(zip_path) as zf:
        members = [m for m in zf.infolist() if not _skip(m.filename, skip_ids)]
        count = len(members)
        for i, member in enumerate(members):
            if dialog.iscanceled():
                return False
            zf.extract(member, dest)
            if i % 25 == 0 or i == count - 1:
                dialog.update(
                    int(i * 100 / max(count, 1)),
                    'Installing\n%d of %d files' % (i + 1, count),
                )
    return True


def drop_from_db(addon_ids):
    """Remove add-ons from the shipped add-on database.

    The database travels with the build and says these are installed and enabled. On a platform
    where their binaries cannot load, leaving those rows in tells Kodi to load them anyway.
    """
    if not addon_ids or not os.path.exists(ADDONS_DB):
        return
    import sqlite3
    try:
        con = sqlite3.connect(ADDONS_DB)
        for addon_id in addon_ids:
            for row in list(con.execute('SELECT id FROM addons WHERE addonID = ?', (addon_id,))):
                con.execute('DELETE FROM addonlinkrepo WHERE idAddon = ?', (row[0],))
            for table in ('addons', 'installed', 'update_rules', 'package'):
                con.execute('DELETE FROM %s WHERE addonID = ?' % table, (addon_id,))
        con.commit()
        con.close()
        log('dropped from add-on database: %s' % ', '.join(addon_ids))
    except Exception as exc:  # noqa: BLE001
        log('could not patch the add-on database: %s' % exc, xbmc.LOGWARNING)


def clear_packages():
    """Drop cached add-on packages so Kodi does not reinstall stale versions."""
    if not os.path.isdir(PACKAGES):
        return
    for name in os.listdir(PACKAGES):
        path = os.path.join(PACKAGES, name)
        try:
            if os.path.isfile(path) or os.path.islink(path):
                os.remove(path)
            else:
                shutil.rmtree(path, ignore_errors=True)
        except OSError as exc:
            log('could not clear %s: %s' % (path, exc), xbmc.LOGWARNING)


def install():
    ok = xbmcgui.Dialog().yesno(
        ADDON_NAME,
        'This replaces your current Kodi setup — skin, home menu, widgets and the settings of '
        'any add-on the build also ships.\n\n'
        'Kodi will close when it finishes. Continue?',
        nolabel='Cancel',
        yeslabel='Install',
    )
    if not ok:
        return

    skip_ids = () if is_android() else ANDROID_ONLY
    dialog = xbmcgui.DialogProgress()
    dialog.create(ADDON_NAME, 'Starting')
    _cleanup_temp()

    try:
        if not download(BUILD_URL, TEMP_ZIP, dialog):
            dialog.close()
            _cleanup_temp()
            notify('Install cancelled')
            return

        dialog.update(0, 'Installing')
        if not extract(TEMP_ZIP, HOME, dialog, skip_ids):
            dialog.close()
            _cleanup_temp()
            xbmcgui.Dialog().ok(
                ADDON_NAME,
                'Cancelled part-way through installing, so this Kodi is now a mix of the old '
                'setup and the new one.\n\nRun the wizard again and let it finish.',
            )
            return

        dialog.update(100, 'Tidying up')
        drop_from_db(skip_ids)
        clear_packages()
        _cleanup_temp()
        dialog.close()

    except Exception as exc:  # noqa: BLE001 - surface anything that goes wrong to the user
        dialog.close()
        _cleanup_temp()
        log('install failed: %s' % exc, xbmc.LOGERROR)
        xbmcgui.Dialog().ok(
            ADDON_NAME,
            'The install did not finish.\n\n%s\n\nYour Kodi has not been fully changed. Check '
            'your connection and try again.' % exc,
        )
        return

    tail = ''
    if skip_ids:
        tail = (
            '\n\nTwo add-ons were skipped because this build carries the Android versions and '
            'they cannot run here: %s. Kodi\'s own copies are untouched. If streams will not '
            'play, install InputStream Adaptive from the Kodi Add-on repository.'
            % ', '.join(skip_ids)
        )
    xbmcgui.Dialog().ok(
        ADDON_NAME,
        'StarWave is installed.\n\nKodi will now close so it cannot write its old settings back '
        'over the new ones.\n\nReopen Kodi to finish.%s' % tail,
    )
    # Hard exit on purpose. A normal Quit() makes Kodi save its in-memory settings on the way
    # out, which would overwrite the configuration that was just extracted.
    log('install complete, hard-exiting so Kodi cannot rewrite userdata')
    xbmc.executebuiltin('InhibitIdleShutdown(true)')
    os._exit(1)


def router(qs):
    action = dict(parse_qsl(qs.lstrip('?'))).get('action')
    if action == 'install':
        install()
    elif action == 'info':
        show_info()
    else:
        menu()


if __name__ == '__main__':
    router(sys.argv[2] if len(sys.argv) > 2 else '')
