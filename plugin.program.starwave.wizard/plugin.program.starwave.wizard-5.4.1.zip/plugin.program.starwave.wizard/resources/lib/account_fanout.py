# -*- coding: utf-8 -*-
"""StarWave Wizard - Account authentication and fan-out engine.

Enables 'Sign In Once' across Real-Debrid, Premiumize, AllDebrid, and Trakt.
Authenticates once via OAuth device-code flows and fans out credentials to all
installed add-ons (Umbrella, Seren, The Crew/ResolveURL, The Gears, Otaku, TMDb Helper).
"""

import os
import sys
import json
import time
import sqlite3
import urllib.request
import urllib.parse
import urllib.error

try:
    import xbmc
    import xbmcgui
    import xbmcaddon
    import xbmcvfs
    KODI_AVAILABLE = True
except ImportError:
    KODI_AVAILABLE = False


# Public Trakt App Client ID for StarWave multi-addon sync
STARWAVE_TRAKT_CLIENT_ID = '0c9a30819e4af6ffaf3b954cbeae9b54499088513863c03c02911de00ac2de79'
STARWAVE_TRAKT_CLIENT_SECRET = 'bf02417f27b514cee6a8d135f2ddc261a15eecfb6ed6289c36239826dcdd1842'

# Standard Debrid App IDs
RD_APP_ID = 'X245A4XAIBGVM'
PM_CLIENT_ID = '149408327'
AD_AGENT = 'StarWave'


def _get_home():
    if KODI_AVAILABLE:
        return xbmcvfs.translatePath('special://home/')
    return os.environ.get('KODI_HOME', '/tmp/fakehome')


def _log(msg, level=None):
    if KODI_AVAILABLE:
        if level is None:
            level = xbmc.LOGINFO
        xbmc.log(f'[StarWave AccountFanout] {msg}', level)
    else:
        print(f'[StarWave AccountFanout] {msg}')


def _safe_set_addon_setting(addon_id, key, value, home_dir=None):
    """Set setting via xbmcaddon if Kodi is live; fallback to settings.xml on disk."""
    if KODI_AVAILABLE:
        try:
            addon = xbmcaddon.Addon(addon_id)
            addon.setSetting(key, str(value))
            return True
        except Exception:
            pass

    # File-level persistence fallback (or offline mode)
    if home_dir is None:
        home_dir = _get_home()
    settings_xml = os.path.join(home_dir, 'userdata', 'addon_data', addon_id, 'settings.xml')
    if os.path.exists(settings_xml):
        try:
            _update_settings_xml(settings_xml, key, str(value))
            return True
        except Exception as exc:
            _log(f'Failed updating {settings_xml} for {key}: {exc}')
    return False


def _clean_val(val, default=''):
    if not val:
        return default
    val_str = str(val).strip()
    if val_str.lower() in ('empty_setting', 'none', 'false', '0', 'default', 'null', '""', "''"):
        return default
    return val_str


def _safe_get_addon_setting(addon_id, key, default='', home_dir=None):
    if KODI_AVAILABLE:
        try:
            val = xbmcaddon.Addon(addon_id).getSetting(key)
            cleaned = _clean_val(val)
            if cleaned:
                return cleaned
        except Exception:
            pass

    if home_dir is None:
        home_dir = _get_home()
    settings_xml = os.path.join(home_dir, 'userdata', 'addon_data', addon_id, 'settings.xml')
    if os.path.exists(settings_xml):
        val = _read_setting_xml(settings_xml, key, default)
        return _clean_val(val, default)
    return default


def _update_settings_xml(filepath, key, value):
    """Update or insert a setting in Kodi settings.xml format."""
    import xml.etree.ElementTree as ET
    try:
        tree = ET.parse(filepath)
        root = tree.getroot()
    except Exception:
        root = ET.Element('settings')
        tree = ET.ElementTree(root)

    found = False
    for setting in root.findall('setting'):
        if setting.get('id') == key:
            found = True
            if setting.text is not None or setting.get('value') is None:
                setting.text = value
                if 'default' in setting.attrib:
                    setting.attrib['default'] = 'false'
            else:
                setting.set('value', value)
            break

    if not found:
        is_v2 = root.get('version') == '2' or any(s.text for s in root.findall('setting'))
        new_elem = ET.SubElement(root, 'setting', {'id': key})
        if is_v2 or root.get('version') == '2':
            new_elem.text = value
            new_elem.set('default', 'false')
        else:
            new_elem.set('value', value)

    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    tree.write(filepath, encoding='utf-8', xml_declaration=True)


def _read_setting_xml(filepath, key, default=''):
    import xml.etree.ElementTree as ET
    try:
        tree = ET.parse(filepath)
        root = tree.getroot()
        for setting in root.findall('setting'):
            if setting.get('id') == key:
                if setting.text:
                    return setting.text.strip()
                if setting.get('value'):
                    return setting.get('value').strip()
    except Exception:
        pass
    return default


def _update_gears_db(key, value, setting_type='string', home_dir=None):
    """Update The Gears settings in userdata/addon_data/plugin.video.gears/databases/settings.db."""
    if home_dir is None:
        home_dir = _get_home()
    gears_db = os.path.join(home_dir, 'userdata', 'addon_data', 'plugin.video.gears', 'databases', 'settings.db')
    os.makedirs(os.path.dirname(gears_db), exist_ok=True)
    try:
        conn = sqlite3.connect(gears_db)
        cursor = conn.cursor()
        cursor.execute(
            'CREATE TABLE IF NOT EXISTS settings '
            '(setting_id text not null unique, setting_type text, setting_default text, setting_value text)'
        )
        default_val = 'false' if setting_type == 'boolean' else ''
        cursor.execute(
            'INSERT OR REPLACE INTO settings (setting_id, setting_type, setting_default, setting_value) '
            'VALUES (?, ?, ?, ?)',
            (key, setting_type, default_val, str(value))
        )
        conn.commit()
        conn.close()

        # Update in-memory property if running inside Kodi
        if KODI_AVAILABLE:
            try:
                xbmcgui.Window(10000).setProperty(f'gears.{key}', str(value))
            except Exception:
                pass
        return True
    except Exception as exc:
        _log(f'Failed updating Gears db for {key}: {exc}')
        return False


def _read_gears_db(key, default='', home_dir=None):
    if home_dir is None:
        home_dir = _get_home()
    gears_db = os.path.join(home_dir, 'userdata', 'addon_data', 'plugin.video.gears', 'databases', 'settings.db')
    if not os.path.exists(gears_db):
        return default
    try:
        conn = sqlite3.connect(gears_db)
        cursor = conn.cursor()
        cursor.execute('SELECT setting_value FROM settings WHERE setting_id = ?', (key,))
        row = cursor.fetchone()
        conn.close()
        val = row[0] if row and row[0] is not None else default
        return _clean_val(val, default)
    except Exception:
        return default


# -----------------------------------------------------------------------------
# Fan-out Core Functions
# -----------------------------------------------------------------------------

def fanout_realdebrid(token, refresh='', client_id='', secret='', username='', home_dir=None):
    """Fan out Real-Debrid credentials to all target add-ons."""
    updated = []
    if not token:
        return updated

    # 1. Umbrella
    if _safe_set_addon_setting('plugin.video.umbrella', 'realdebridtoken', token, home_dir):
        _safe_set_addon_setting('plugin.video.umbrella', 'realdebridrefresh', refresh, home_dir)
        _safe_set_addon_setting('plugin.video.umbrella', 'realdebrid.clientid', client_id, home_dir)
        _safe_set_addon_setting('plugin.video.umbrella', 'realdebridsecret', secret, home_dir)
        if username:
            _safe_set_addon_setting('plugin.video.umbrella', 'realdebridusername', username, home_dir)
        updated.append('Umbrella')

    # 2. Seren
    if _safe_set_addon_setting('plugin.video.seren', 'rd.auth', token, home_dir):
        _safe_set_addon_setting('plugin.video.seren', 'rd.refresh', refresh, home_dir)
        _safe_set_addon_setting('plugin.video.seren', 'rd.client_id', client_id, home_dir)
        _safe_set_addon_setting('plugin.video.seren', 'rd.secret', secret, home_dir)
        _safe_set_addon_setting('plugin.video.seren', 'rd.enabled', 'true', home_dir)
        if username:
            _safe_set_addon_setting('plugin.video.seren', 'rd.username', username, home_dir)
        updated.append('Seren')

    # 3. ResolveURL (for The Crew and common scrapers)
    if _safe_set_addon_setting('script.module.resolveurl', 'RealDebridResolver_token', token, home_dir):
        _safe_set_addon_setting('script.module.resolveurl', 'RealDebridResolver_enabled', 'true', home_dir)
        _safe_set_addon_setting('script.module.resolveurl', 'RealDebridResolver_refresh', refresh, home_dir)
        _safe_set_addon_setting('script.module.resolveurl', 'RealDebridResolver_client_id', client_id, home_dir)
        _safe_set_addon_setting('script.module.resolveurl', 'RealDebridResolver_client_secret', secret, home_dir)
        if username:
            _safe_set_addon_setting('script.module.resolveurl', 'RealDebridResolver_user', username, home_dir)
        updated.append('ResolveURL (The Crew)')

    # 4. The Gears
    if _update_gears_db('rd.token', token, 'string', home_dir):
        _update_gears_db('rd.enabled', 'true', 'boolean', home_dir)
        _update_gears_db('rd.refresh', refresh, 'string', home_dir)
        _update_gears_db('rd.client_id', client_id, 'string', home_dir)
        _update_gears_db('rd.secret', secret, 'string', home_dir)
        if username:
            _update_gears_db('rd.account_id', username, 'string', home_dir)
        updated.append('The Gears')

    # 5. Otaku
    if _safe_set_addon_setting('plugin.video.otaku.testing', 'realdebrid.token', token, home_dir):
        _safe_set_addon_setting('plugin.video.otaku.testing', 'realdebrid.refresh', refresh, home_dir)
        _safe_set_addon_setting('plugin.video.otaku.testing', 'realdebrid.client_id', client_id, home_dir)
        _safe_set_addon_setting('plugin.video.otaku.testing', 'realdebrid.secret', secret, home_dir)
        if username:
            _safe_set_addon_setting('plugin.video.otaku.testing', 'realdebrid.username', username, home_dir)
        updated.append('Otaku')

    return updated


def fanout_premiumize(token, username='', home_dir=None):
    """Fan out Premiumize credentials to all target add-ons."""
    updated = []
    if not token:
        return updated

    # 1. Umbrella
    if _safe_set_addon_setting('plugin.video.umbrella', 'premiumizetoken', token, home_dir):
        if username:
            _safe_set_addon_setting('plugin.video.umbrella', 'premiumize.username', username, home_dir)
        updated.append('Umbrella')

    # 2. Seren
    if _safe_set_addon_setting('plugin.video.seren', 'premiumize.token', token, home_dir):
        _safe_set_addon_setting('plugin.video.seren', 'premiumize.enabled', 'true', home_dir)
        _safe_set_addon_setting('plugin.video.seren', 'premiumize.status', 'Premium', home_dir)
        if username:
            _safe_set_addon_setting('plugin.video.seren', 'premiumize.username', username, home_dir)
        updated.append('Seren')

    # 3. ResolveURL
    if _safe_set_addon_setting('script.module.resolveurl', 'PremiumizeMeResolver_token', token, home_dir):
        _safe_set_addon_setting('script.module.resolveurl', 'PremiumizeMeResolver_enabled', 'true', home_dir)
        updated.append('ResolveURL (The Crew)')

    # 4. The Gears
    if _update_gears_db('pm.token', token, 'string', home_dir):
        _update_gears_db('pm.enabled', 'true', 'boolean', home_dir)
        if username:
            _update_gears_db('pm.account_id', username, 'string', home_dir)
        updated.append('The Gears')

    # 5. Otaku
    if _safe_set_addon_setting('plugin.video.otaku.testing', 'premiumize.token', token, home_dir):
        if username:
            _safe_set_addon_setting('plugin.video.otaku.testing', 'premiumize.username', username, home_dir)
        updated.append('Otaku')

    return updated


def fanout_alldebrid(token, username='', home_dir=None):
    """Fan out AllDebrid credentials to all target add-ons."""
    updated = []
    if not token:
        return updated

    # 1. Umbrella
    if _safe_set_addon_setting('plugin.video.umbrella', 'alldebridtoken', token, home_dir):
        if username:
            _safe_set_addon_setting('plugin.video.umbrella', 'alldebridusername', username, home_dir)
        updated.append('Umbrella')

    # 2. Seren
    if _safe_set_addon_setting('plugin.video.seren', 'alldebrid.token', token, home_dir):
        _safe_set_addon_setting('plugin.video.seren', 'alldebrid.enabled', 'true', home_dir)
        if username:
            _safe_set_addon_setting('plugin.video.seren', 'alldebrid.username', username, home_dir)
        updated.append('Seren')

    # 3. ResolveURL
    if _safe_set_addon_setting('script.module.resolveurl', 'AllDebridResolver_token', token, home_dir):
        _safe_set_addon_setting('script.module.resolveurl', 'AllDebridResolver_enabled', 'true', home_dir)
        updated.append('ResolveURL (The Crew)')

    # 4. The Gears
    if _update_gears_db('ad.token', token, 'string', home_dir):
        _update_gears_db('ad.enabled', 'true', 'boolean', home_dir)
        if username:
            _update_gears_db('ad.account_id', username, 'string', home_dir)
        updated.append('The Gears')

    # 5. Otaku
    if _safe_set_addon_setting('plugin.video.otaku.testing', 'alldebrid.token', token, home_dir):
        if username:
            _safe_set_addon_setting('plugin.video.otaku.testing', 'alldebrid.username', username, home_dir)
        updated.append('Otaku')

    return updated


def fanout_trakt(token, refresh='', expires_at=0, client_id=None, secret=None, username='', home_dir=None):
    """Fan out Trakt credentials to all target add-ons."""
    updated = []
    if not token:
        return updated

    if client_id is None:
        client_id = STARWAVE_TRAKT_CLIENT_ID
    if secret is None:
        secret = STARWAVE_TRAKT_CLIENT_SECRET
    if not expires_at:
        expires_at = int(time.time()) + (90 * 86400)

    # 1. Umbrella (native client ID support)
    if _safe_set_addon_setting('plugin.video.umbrella', 'trakt.user.token', token, home_dir):
        _safe_set_addon_setting('plugin.video.umbrella', 'trakt.refreshtoken', refresh, home_dir)
        _safe_set_addon_setting('plugin.video.umbrella', 'trakt.token.expires', str(expires_at), home_dir)
        _safe_set_addon_setting('plugin.video.umbrella', 'trakt.authed.clientid', client_id, home_dir)
        if secret:
            _safe_set_addon_setting('plugin.video.umbrella', 'trakt.authed.secret', secret, home_dir)
        _safe_set_addon_setting('plugin.video.umbrella', 'trakt.isauthed', 'true', home_dir)
        if username:
            _safe_set_addon_setting('plugin.video.umbrella', 'trakt.username', username, home_dir)
        updated.append('Umbrella')

    # 2. Seren (dynamic client ID support)
    if _safe_set_addon_setting('plugin.video.seren', 'trakt.auth', token, home_dir):
        _safe_set_addon_setting('plugin.video.seren', 'trakt.refresh', refresh, home_dir)
        _safe_set_addon_setting('plugin.video.seren', 'trakt.expires', str(expires_at), home_dir)
        _safe_set_addon_setting('plugin.video.seren', 'trakt.clientid', client_id, home_dir)
        if secret:
            _safe_set_addon_setting('plugin.video.seren', 'trakt.secret', secret, home_dir)
        if username:
            _safe_set_addon_setting('plugin.video.seren', 'trakt.username', username, home_dir)
        updated.append('Seren')

    # 3. The Gears (dynamic client ID support)
    if _update_gears_db('trakt.token', token, 'string', home_dir):
        _update_gears_db('trakt.refresh', refresh, 'string', home_dir)
        _update_gears_db('trakt.expires', str(expires_at), 'string', home_dir)
        _update_gears_db('trakt.client', client_id, 'string', home_dir)
        if secret:
            _update_gears_db('trakt.secret', secret, 'string', home_dir)
        if username:
            _update_gears_db('trakt.user', username, 'string', home_dir)
        updated.append('The Gears')

    # 4. TMDb Helper (JSON token storage)
    token_json = json.dumps({
        'access_token': token,
        'refresh_token': refresh,
        'expires_in': max(0, int(expires_at - time.time())),
        'created_at': int(time.time()),
        'token_type': 'bearer',
        'scope': 'public'
    })
    if _safe_set_addon_setting('plugin.video.themoviedb.helper', 'trakt_token', token_json, home_dir):
        if username:
            _safe_set_addon_setting('plugin.video.themoviedb.helper', 'trakt_username', username, home_dir)
        updated.append('TMDb Helper')

    # 5. The Crew (live token copy)
    if _safe_set_addon_setting('plugin.video.thecrew', 'trakt.token', token, home_dir):
        _safe_set_addon_setting('plugin.video.thecrew', 'trakt.refresh', refresh, home_dir)
        _safe_set_addon_setting('plugin.video.thecrew', 'trakt.expires_at', str(expires_at), home_dir)
        if username:
            _safe_set_addon_setting('plugin.video.thecrew', 'trakt.user', username, home_dir)
        updated.append('The Crew')

    return updated


# -----------------------------------------------------------------------------
# Status Inspection
# -----------------------------------------------------------------------------

def get_account_status(home_dir=None):
    """Inspect all configured accounts across all add-ons."""
    status = {
        'realdebrid': {'active': False, 'username': '', 'addons': []},
        'premiumize': {'active': False, 'username': '', 'addons': []},
        'alldebrid': {'active': False, 'username': '', 'addons': []},
        'trakt': {'active': False, 'username': '', 'addons': []},
    }

    # RD inspection
    rd_umbrella = _safe_get_addon_setting('plugin.video.umbrella', 'realdebridtoken', '', home_dir)
    rd_seren = _safe_get_addon_setting('plugin.video.seren', 'rd.auth', '', home_dir)
    rd_resolveurl = _safe_get_addon_setting('script.module.resolveurl', 'RealDebridResolver_token', '', home_dir)
    rd_gears = _read_gears_db('rd.token', '', home_dir)
    rd_otaku = _safe_get_addon_setting('plugin.video.otaku.testing', 'realdebrid.token', '', home_dir)

    if any((rd_umbrella, rd_seren, rd_resolveurl, rd_gears, rd_otaku)):
        status['realdebrid']['active'] = True
        u = (_safe_get_addon_setting('plugin.video.umbrella', 'realdebridusername', '', home_dir) or
             _safe_get_addon_setting('plugin.video.seren', 'rd.username', '', home_dir) or
             _read_gears_db('rd.account_id', '', home_dir))
        status['realdebrid']['username'] = u
        if rd_umbrella: status['realdebrid']['addons'].append('Umbrella')
        if rd_seren: status['realdebrid']['addons'].append('Seren')
        if rd_resolveurl: status['realdebrid']['addons'].append('ResolveURL (The Crew)')
        if rd_gears: status['realdebrid']['addons'].append('The Gears')
        if rd_otaku: status['realdebrid']['addons'].append('Otaku')

    # PM inspection
    pm_umbrella = _safe_get_addon_setting('plugin.video.umbrella', 'premiumizetoken', '', home_dir)
    pm_seren = _safe_get_addon_setting('plugin.video.seren', 'premiumize.token', '', home_dir)
    pm_resolveurl = _safe_get_addon_setting('script.module.resolveurl', 'PremiumizeMeResolver_token', '', home_dir)
    pm_gears = _read_gears_db('pm.token', '', home_dir)
    pm_otaku = _safe_get_addon_setting('plugin.video.otaku.testing', 'premiumize.token', '', home_dir)

    if any((pm_umbrella, pm_seren, pm_resolveurl, pm_gears, pm_otaku)):
        status['premiumize']['active'] = True
        u = (_safe_get_addon_setting('plugin.video.umbrella', 'premiumize.username', '', home_dir) or
             _safe_get_addon_setting('plugin.video.seren', 'premiumize.username', '', home_dir) or
             _read_gears_db('pm.account_id', '', home_dir))
        status['premiumize']['username'] = u
        if pm_umbrella: status['premiumize']['addons'].append('Umbrella')
        if pm_seren: status['premiumize']['addons'].append('Seren')
        if pm_resolveurl: status['premiumize']['addons'].append('ResolveURL (The Crew)')
        if pm_gears: status['premiumize']['addons'].append('The Gears')
        if pm_otaku: status['premiumize']['addons'].append('Otaku')

    # AllDebrid inspection
    ad_umbrella = _safe_get_addon_setting('plugin.video.umbrella', 'alldebridtoken', '', home_dir)
    ad_seren = _safe_get_addon_setting('plugin.video.seren', 'alldebrid.token', '', home_dir)
    ad_resolveurl = _safe_get_addon_setting('script.module.resolveurl', 'AllDebridResolver_token', '', home_dir)
    ad_gears = _read_gears_db('ad.token', '', home_dir)
    ad_otaku = _safe_get_addon_setting('plugin.video.otaku.testing', 'alldebrid.token', '', home_dir)

    if any((ad_umbrella, ad_seren, ad_resolveurl, ad_gears, ad_otaku)):
        status['alldebrid']['active'] = True
        u = (_safe_get_addon_setting('plugin.video.umbrella', 'alldebridusername', '', home_dir) or
             _safe_get_addon_setting('plugin.video.seren', 'alldebrid.username', '', home_dir) or
             _read_gears_db('ad.account_id', '', home_dir))
        status['alldebrid']['username'] = u
        if ad_umbrella: status['alldebrid']['addons'].append('Umbrella')
        if ad_seren: status['alldebrid']['addons'].append('Seren')
        if ad_resolveurl: status['alldebrid']['addons'].append('ResolveURL (The Crew)')
        if ad_gears: status['alldebrid']['addons'].append('The Gears')
        if ad_otaku: status['alldebrid']['addons'].append('Otaku')

    # Trakt inspection
    tr_umbrella = _safe_get_addon_setting('plugin.video.umbrella', 'trakt.user.token', '', home_dir)
    tr_seren = _safe_get_addon_setting('plugin.video.seren', 'trakt.auth', '', home_dir)
    tr_gears = _read_gears_db('trakt.token', '', home_dir)
    tr_tmdb_raw = _safe_get_addon_setting('plugin.video.themoviedb.helper', 'trakt_token', '', home_dir)
    tr_tmdb = ''
    if tr_tmdb_raw:
        try:
            tok = json.loads(tr_tmdb_raw).get('access_token', '')
            if _clean_val(tok):
                tr_tmdb = tok
        except Exception:
            pass
    tr_crew = _safe_get_addon_setting('plugin.video.thecrew', 'trakt.token', '', home_dir)

    if any((tr_umbrella, tr_seren, tr_gears, tr_tmdb, tr_crew)):
        status['trakt']['active'] = True
        u = (_safe_get_addon_setting('plugin.video.umbrella', 'trakt.username', '', home_dir) or
             _safe_get_addon_setting('plugin.video.seren', 'trakt.username', '', home_dir) or
             _read_gears_db('trakt.user', '', home_dir) or
             _safe_get_addon_setting('plugin.video.thecrew', 'trakt.user', '', home_dir))
        status['trakt']['username'] = u
        if tr_umbrella: status['trakt']['addons'].append('Umbrella')
        if tr_seren: status['trakt']['addons'].append('Seren')
        if tr_gears: status['trakt']['addons'].append('The Gears')
        if tr_tmdb: status['trakt']['addons'].append('TMDb Helper')
        if tr_crew: status['trakt']['addons'].append('The Crew')

    return status


# -----------------------------------------------------------------------------
# Interactive OAuth Device Flows (Kodi UI)
# -----------------------------------------------------------------------------

def _http_get_json(url, headers=None, timeout=20):
    req = urllib.request.Request(url, headers=headers or {'User-Agent': 'StarWave-Wizard'})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode('utf-8'))


def _http_post_json(url, data=None, headers=None, timeout=20):
    if headers is None:
        headers = {}
    headers.setdefault('User-Agent', 'StarWave-Wizard')
    encoded_data = None
    if isinstance(data, dict):
        if headers.get('Content-Type') == 'application/json':
            encoded_data = json.dumps(data).encode('utf-8')
        else:
            encoded_data = urllib.parse.urlencode(data).encode('utf-8')
    req = urllib.request.Request(url, data=encoded_data, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode('utf-8'))


def auth_realdebrid(dialog_title='Real-Debrid Authorization'):
    """Interactive Real-Debrid OAuth Device Code Flow with Fan-Out."""
    if not KODI_AVAILABLE:
        return None
    try:
        url = f'https://api.real-debrid.com/oauth/v2/device/code?client_id={RD_APP_ID}&new_credentials=yes'
        res = _http_get_json(url)
        device_code = res['device_code']
        user_code = res['user_code']
        interval = max(int(res.get('interval', 5)), 1)
        device_ttl = int(res.get('expires_in', 600))
        verification_url = res.get('verification_url', 'https://real-debrid.com/device')

        dialog = xbmcgui.DialogProgress()
        dialog.create(dialog_title, f'Visit: {verification_url}\nEnter Code: {user_code}')

        poll_url = f'https://api.real-debrid.com/oauth/v2/device/credentials?client_id={RD_APP_ID}&code={device_code}'
        start = time.time()
        creds = None
        while not dialog.iscanceled() and (time.time() - start) < device_ttl:
            time.sleep(interval)
            pct = min(100, int((time.time() - start) / device_ttl * 100))
            dialog.update(
                pct,
                f'Visit: [B]{verification_url}[/B]\nEnter Code: [B]{user_code}[/B]\n\n'
                f'Waiting for confirmation on your phone or browser...'
            )
            try:
                poll_res = _http_get_json(poll_url)
                if 'client_id' in poll_res and 'client_secret' in poll_res:
                    creds = poll_res
                    break
            except urllib.error.HTTPError as exc:
                if exc.code in (400, 404):
                    continue
                break
            except Exception:
                continue
        dialog.close()

        if not creds:
            xbmcgui.Dialog().ok(dialog_title, 'Authorization cancelled or timed out.')
            return None

        token_url = 'https://api.real-debrid.com/oauth/v2/token'
        token_data = {
            'client_id': creds['client_id'],
            'client_secret': creds['client_secret'],
            'code': device_code,
            'grant_type': 'http://oauth.net/grant_type/device/1.0'
        }
        token_res = _http_post_json(token_url, data=token_data)
        access_token = token_res['access_token']
        refresh_token = token_res.get('refresh_token', '')
        client_id = creds['client_id']
        client_secret = creds['client_secret']

        username = ''
        try:
            user_info = _http_get_json(
                'https://api.real-debrid.com/rest/1.0/user',
                headers={'Authorization': f'Bearer {access_token}'}
            )
            username = user_info.get('username', '')
        except Exception:
            pass

        updated = fanout_realdebrid(access_token, refresh_token, client_id, client_secret, username)
        msg = f'Real-Debrid authorized successfully for [B]{username or "User"}[/B]!\n\nCredentials fanned out to:\n• ' + '\n• '.join(updated)
        xbmcgui.Dialog().ok(dialog_title, msg)
        return {'token': access_token, 'username': username, 'updated': updated}
    except Exception as exc:
        _log(f'RD auth error: {exc}')
        xbmcgui.Dialog().ok(dialog_title, f'Authorization failed: {exc}')
        return None


def auth_premiumize(dialog_title='Premiumize Authorization'):
    """Interactive Premiumize Device Code Flow with Fan-Out."""
    if not KODI_AVAILABLE:
        return None
    try:
        url = 'https://www.premiumize.me/token'
        data = {'response_type': 'device_code', 'client_id': PM_CLIENT_ID}
        res = _http_post_json(url, data=data)
        device_code = res['device_code']
        user_code = res['user_code']
        interval = max(int(res.get('interval', 5)), 1)
        device_ttl = int(res.get('expires_in', 600))
        verification_url = res.get('verification_uri', 'https://www.premiumize.me/device')

        dialog = xbmcgui.DialogProgress()
        dialog.create(dialog_title, f'Visit: {verification_url}\nEnter Code: {user_code}')

        poll_data = {'grant_type': 'device_code', 'client_id': PM_CLIENT_ID, 'code': device_code}
        start = time.time()
        token = None
        while not dialog.iscanceled() and (time.time() - start) < device_ttl:
            time.sleep(interval)
            pct = min(100, int((time.time() - start) / device_ttl * 100))
            dialog.update(
                pct,
                f'Visit: [B]{verification_url}[/B]\nEnter Code: [B]{user_code}[/B]\n\n'
                f'Waiting for confirmation on your phone or browser...'
            )
            try:
                poll_res = _http_post_json(url, data=poll_data)
                if 'access_token' in poll_res:
                    token = poll_res['access_token']
                    break
            except urllib.error.HTTPError as exc:
                if exc.code in (400, 404):
                    continue
                break
            except Exception:
                continue
        dialog.close()

        if not token:
            xbmcgui.Dialog().ok(dialog_title, 'Authorization cancelled or timed out.')
            return None

        username = ''
        try:
            account_info = _http_get_json(
                'https://www.premiumize.me/api/account/info',
                headers={'Authorization': f'Bearer {token}'}
            )
            username = str(account_info.get('customer_id', ''))
        except Exception:
            pass

        updated = fanout_premiumize(token, username)
        msg = f'Premiumize authorized successfully for [B]{username or "User"}[/B]!\n\nCredentials fanned out to:\n• ' + '\n• '.join(updated)
        xbmcgui.Dialog().ok(dialog_title, msg)
        return {'token': token, 'username': username, 'updated': updated}
    except Exception as exc:
        _log(f'PM auth error: {exc}')
        xbmcgui.Dialog().ok(dialog_title, f'Authorization failed: {exc}')
        return None


def auth_alldebrid(dialog_title='AllDebrid Authorization'):
    """Interactive AllDebrid Pin Flow with Fan-Out."""
    if not KODI_AVAILABLE:
        return None
    try:
        url = f'https://api.alldebrid.com/v4/pin/get?agent={AD_AGENT}'
        res = _http_get_json(url)
        data = res.get('data', {})
        pin = data['pin']
        check_url = data['check_url']
        device_ttl = int(data.get('expires_in', 600))
        verification_url = f'https://alldebrid.com/pin?pin={pin}'

        dialog = xbmcgui.DialogProgress()
        dialog.create(dialog_title, f'Visit: {verification_url}\nEnter PIN: {pin}')

        start = time.time()
        apikey = None
        while not dialog.iscanceled() and (time.time() - start) < device_ttl:
            time.sleep(5)
            pct = min(100, int((time.time() - start) / device_ttl * 100))
            dialog.update(
                pct,
                f'Visit: [B]{verification_url}[/B]\nPIN: [B]{pin}[/B]\n\n'
                f'Waiting for confirmation on your phone or browser...'
            )
            try:
                poll_res = _http_get_json(check_url)
                poll_data = poll_res.get('data', {})
                if poll_data.get('activated') and poll_data.get('apikey'):
                    apikey = poll_data['apikey']
                    break
            except urllib.error.HTTPError as exc:
                if exc.code in (400, 404):
                    continue
                break
            except Exception:
                continue
        dialog.close()

        if not apikey:
            xbmcgui.Dialog().ok(dialog_title, 'Authorization cancelled or timed out.')
            return None

        username = ''
        try:
            user_info = _http_get_json(
                f'https://api.alldebrid.com/v4/user?agent={AD_AGENT}',
                headers={'Authorization': f'Bearer {apikey}'}
            )
            username = user_info.get('data', {}).get('user', {}).get('username', '')
        except Exception:
            pass

        updated = fanout_alldebrid(apikey, username)
        msg = f'AllDebrid authorized successfully for [B]{username or "User"}[/B]!\n\nCredentials fanned out to:\n• ' + '\n• '.join(updated)
        xbmcgui.Dialog().ok(dialog_title, msg)
        return {'token': apikey, 'username': username, 'updated': updated}
    except Exception as exc:
        _log(f'AllDebrid auth error: {exc}')
        xbmcgui.Dialog().ok(dialog_title, f'Authorization failed: {exc}')
        return None


def auth_trakt(dialog_title='Trakt Authorization'):
    """Interactive Trakt OAuth Device Code Flow with Fan-Out."""
    if not KODI_AVAILABLE:
        return None
    try:
        url = 'https://api.trakt.tv/oauth/device/code'
        headers = {'Content-Type': 'application/json', 'trakt-api-key': STARWAVE_TRAKT_CLIENT_ID, 'trakt-api-version': '2'}
        data = {'client_id': STARWAVE_TRAKT_CLIENT_ID}
        res = _http_post_json(url, data=data, headers=headers)
        device_code = res['device_code']
        user_code = res['user_code']
        interval = max(int(res.get('interval', 5)), 1)
        device_ttl = int(res.get('expires_in', 600))
        verification_url = res.get('verification_url', 'https://trakt.tv/activate')

        dialog = xbmcgui.DialogProgress()
        dialog.create(dialog_title, f'Visit: {verification_url}\nEnter Code: {user_code}')

        poll_url = 'https://api.trakt.tv/oauth/device/token'
        poll_data = {
            'code': device_code,
            'client_id': STARWAVE_TRAKT_CLIENT_ID,
            'client_secret': STARWAVE_TRAKT_CLIENT_SECRET
        }
        start = time.time()
        token_info = None
        while not dialog.iscanceled() and (time.time() - start) < device_ttl:
            time.sleep(interval)
            pct = min(100, int((time.time() - start) / device_ttl * 100))
            dialog.update(
                pct,
                f'Visit: [B]{verification_url}[/B]\nEnter Code: [B]{user_code}[/B]\n\n'
                f'Waiting for confirmation on your phone or browser...'
            )
            try:
                poll_res = _http_post_json(poll_url, data=poll_data, headers=headers)
                if 'access_token' in poll_res:
                    token_info = poll_res
                    break
            except urllib.error.HTTPError as exc:
                if exc.code in (400, 404):
                    continue
                break
            except Exception:
                continue
        dialog.close()

        if not token_info:
            xbmcgui.Dialog().ok(dialog_title, 'Authorization cancelled or timed out.')
            return None

        access_token = token_info['access_token']
        refresh_token = token_info.get('refresh_token', '')
        created_at = token_info.get('created_at', int(time.time()))
        token_ttl = token_info.get('expires_in', 90 * 86400)
        expires_at = created_at + token_ttl

        username = ''
        try:
            user_headers = {
                'Content-Type': 'application/json',
                'trakt-api-key': STARWAVE_TRAKT_CLIENT_ID,
                'trakt-api-version': '2',
                'Authorization': f'Bearer {access_token}'
            }
            user_info = _http_get_json('https://api.trakt.tv/users/me', headers=user_headers)
            username = user_info.get('user', {}).get('username', '')
        except Exception:
            pass

        updated = fanout_trakt(
            access_token, refresh_token, expires_at,
            STARWAVE_TRAKT_CLIENT_ID, STARWAVE_TRAKT_CLIENT_SECRET, username
        )
        msg = f'Trakt authorized successfully for [B]{username or "User"}[/B]!\n\nCredentials fanned out to:\n• ' + '\n• '.join(updated)
        xbmcgui.Dialog().ok(dialog_title, msg)
        return {'token': access_token, 'username': username, 'updated': updated}
    except Exception as exc:
        _log(f'Trakt auth error: {exc}')
        xbmcgui.Dialog().ok(dialog_title, f'Authorization failed: {exc}')
        return None
