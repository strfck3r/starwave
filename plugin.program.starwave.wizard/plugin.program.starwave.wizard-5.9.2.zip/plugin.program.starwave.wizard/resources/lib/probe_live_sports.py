#!/usr/bin/env python3
"""
scripts/probe-live-sports.py - StarWave Canonical Sports Engine & QC Auditor

Decoupled resolver (2026-08-28): DISCOVERY is separated from RESOLUTION.

- Discovery / canonical truth = ESPN's public scoreboard API. Only games whose
  ``status.type.state == "in"`` are live, which kills the false positives that
  the old RoxieStreams harvest produced (0/9 precision in the 08-28 sweep).
- Resolution = The Crew's StreamEast (SE) + BuffStreams (BS) recipe, which yields
  the ``chatgpt.hereisman.net`` playlists that measured 100% playable at 720p.

The two providers are reimplemented cleanly here (ported from The Crew's
schedule/streamer modules, SE + BS paths only). ESPN games are matched to
schedule entries by the entry's HREF SLUG, which carries both team names in
full, and only by the entry's lossy display TITLE when there is no usable slug.
A live ESPN game with no schedule match is still emitted as a card with no
stream, so visibility is never lost.

The legacy RoxieStreams harvest survives behind ``--source roxie`` for reference;
``--source espn`` (the default) is the live path. The canonical-card and M3U
output contracts are unchanged so downstream Kodi / Arctic Fuse 3 consumers do
not break.
"""

import argparse
import base64
import datetime
import html
import json
import os
import random
import re
import sys
import time
import unicodedata
import urllib.request
from urllib.parse import urljoin, urlparse
from typing import Any, Dict, FrozenSet, List, Optional, Tuple, Union

# --- StarWave import shim: vendored add-on module imports stream_qc directly ---
import stream_qc

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

# --- Legacy RoxieStreams (kept behind --source roxie) --------------------------
ROXIE_BASE_INDEX = "https://raw.githubusercontent.com/posadka/xmls2/refs/heads/main/roxie_bases.xml"
DEFAULT_ROXIE_BASE = "https://roxiestreams.su"

# --- ESPN scoreboard (discovery / canonical truth) -----------------------------
# A Chrome UA gets a 403 from this endpoint; a plain curl-style UA is accepted.
ESPN_SCOREBOARD = "https://site.api.espn.com/apis/site/v2/sports/{path}/scoreboard"
ESPN_UA = "curl/8.4.0"

# --- StreamEast / BuffStreams (resolution) -------------------------------------
# Base URLs live in a small pointer file so they survive domain rotation. The
# body of the pointer is a quoted string; the first "..." capture is the base.
SE_POINTER = "https://raw.githubusercontent.com/posadka/xmls2/refs/heads/main/streameast.xml"
SE_DEFAULT_BASE = "https://thestreameast.top"
# BuffStreams moved twice on 2026-08-29 and the old constants failed SILENTLY, which is
# why the health side-channel below exists. The upstream pointer was renamed
# `buffstreams.xml` -> `buff.xml`, so the old pointer 404s and `resolve_provider_base`
# fell back to the default; and the default `buffstreams.app` had itself been SEIZED - it
# answers 200 with a 925-byte "THIS DOMAIN HAS BEEN SEIZED" page for every path, so the
# fetch "succeeded", parsed to zero entries, and the bare `if bs_html:` swallowed it. A
# device on the old constants therefore ran with no backup provider at all and said
# nothing anywhere. Both halves are repointed here; verified end to end 2026-08-29 against
# three live MLB games (mlbstreams -> 10 entries, nflstreams -> 24, ncaastreams -> 2).
BS_POINTER = "https://raw.githubusercontent.com/posadka/xmls2/refs/heads/main/buff.xml"
BS_DEFAULT_BASE = "https://mybuffstreams.plus"

# ESPN scoreboard path + SE/BS schedule slugs + display label, per sport.
# Only `mlb` is verified end-to-end (2026-08-28 sweep). The other slugs follow
# the same `<sport>streams` convention StreamEast uses and are best-effort.
SPORT_CONFIG: Dict[str, Dict[str, str]] = {
    "mlb":    {"espn": "baseball/mlb",              "se": "mlbstreams",    "bs": "mlbstreams",    "label": "MLB"},
    "nfl":    {"espn": "football/nfl",              "se": "nflstreams",    "bs": "nflstreams",    "label": "NFL"},
    "cfb":    {"espn": "football/college-football", "se": "ncaastreams",   "bs": "ncaastreams",   "label": "CFB"},
    "nba":    {"espn": "basketball/nba",            "se": "nbastreams",    "bs": "nbastreams",    "label": "NBA"},
    "wnba":   {"espn": "basketball/wnba",           "se": "wnbastreams",   "bs": "wnbastreams",   "label": "WNBA"},
    "nhl":    {"espn": "hockey/nhl",                "se": "nhlstreams",    "bs": "nhlstreams",    "label": "NHL"},
    "ufc":    {"espn": "mma/ufc",                   "se": "mmastreams",    "bs": "mmastreams",    "label": "UFC"},
    "soccer": {"espn": "soccer/usa.1",              "se": "soccerstreams", "bs": "soccerstreams", "label": "SOCCER"},
    "boxing": {"espn": "",                          "se": "boxingstreams", "bs": "boxingstreams2", "label": "BOXING"},
}


FALLBACK_SPORT_ICON = "special://skin/extras/icons/trophy.png"


def get_sport_icon(sport: str) -> str:
    """Return canonical icon URI for a sport league."""
    s = sport.upper()
    if "NFL" in s:
        return "special://skin/extras/icons/sw/nfl.png"
    elif "NBA" in s or "WNBA" in s:
        return "special://skin/extras/icons/sw/nba.png"
    elif "MLB" in s or "BASEBALL" in s:
        return "special://skin/extras/icons/sw/mlb.png"
    elif "NHL" in s or "HOCKEY" in s:
        return "special://skin/extras/icons/sw/nhl.png"
    elif "UFC" in s or "MMA" in s or "FIGHT" in s:
        return "special://skin/extras/icons/sw/ufc.png"
    elif "BOX" in s:
        return "special://skin/extras/icons/boxing.png"
    elif "SOCCER" in s or "FIFA" in s or "EPL" in s or "FOOTBALL" in s:
        return "special://skin/extras/icons/film.png"
    elif "MOTOR" in s or "F1" in s or "NASCAR" in s:
        return "special://skin/extras/icons/film.png"
    return FALLBACK_SPORT_ICON


def format_game_art(game: Dict[str, Any]) -> Dict[str, str]:
    """Return art dictionary for a game ListItem.

    Uses ESPN team logo URLs when available (per-game, skin-independent).
    Falls back to special://skin/extras/icons/trophy.png (verified in Arctic Fuse 3).
    clearlogo is omitted so Info_Title renders the matchup text rather than
    overriding it with a home logo. fanart is omitted to avoid full-bleed logo blowing up.
    """
    teams = game.get("teams", [])
    home_logo = ""
    away_logo = ""
    for t in teams:
        logo = t.get("logo", "") or ""
        if t.get("homeAway") == "home" and logo:
            home_logo = logo
        elif t.get("homeAway") == "away" and logo:
            away_logo = logo
        elif logo and not home_logo:
            home_logo = logo

    primary_logo = home_logo or away_logo or FALLBACK_SPORT_ICON

    return {
        "icon": primary_logo,
        "thumb": primary_logo,
        "landscape": primary_logo,
        "poster": primary_logo,
    }


def is_final_stretch(game: Dict[str, Any]) -> bool:
    """Check if a live game is in its final stretch.

    A game in its final stretch stops being hero-eligible:
    - MLB / Baseball: ninth inning or later (9th, 10th, etc., or Extra innings)
    - NFL / CFB / Football: fourth quarter with <= 2:00 remaining, or Overtime (OT)
    - NHL / Hockey: third period or later (3rd, OT, SO / Shootout)
    - NBA / WNBA / Basketball: fourth quarter with <= 2:00 remaining, or Overtime (OT)
    - Post-game / final / ended
    """
    sport = (game.get("sport") or "").lower()
    detail = (game.get("status_detail") or "").strip()
    if not detail:
        return False
    detail_lower = detail.lower()

    if "final" in detail_lower or "end of game" in detail_lower:
        return True

    # MLB / Baseball: 9th inning or later, or extra innings
    if sport in ("mlb", "baseball"):
        if re.search(r"\b(9th|1[0-9]th|[2-9][0-9]th|extra|extras)\b", detail_lower):
            return True
        m = re.search(r"\b(?:top|bot|mid|end)\s*([0-9]+)", detail_lower)
        if m and int(m.group(1)) >= 9:
            return True
        return False

    # Football (NFL / CFB): 4th quarter with <= 2:00, or OT
    if sport in ("nfl", "cfb", "football"):
        if "ot" in detail_lower or "overtime" in detail_lower:
            return True
        if "4th" in detail_lower or "4th qtr" in detail_lower or "4th quarter" in detail_lower:
            m = re.search(r"([0-9]+):([0-9]{2})", detail)
            if m:
                mins = int(m.group(1))
                secs = int(m.group(2))
                if mins < 2 or (mins == 2 and secs == 0):
                    return True
            elif "end" in detail_lower:
                return True
        return False

    # Hockey (NHL): 3rd period, OT, shootout
    if sport in ("nhl", "hockey"):
        if "3rd" in detail_lower or "ot" in detail_lower or "so" in detail_lower or "shootout" in detail_lower:
            return True
        return False

    # Basketball (NBA / WNBA): 4th quarter with <= 2:00, or OT
    if sport in ("nba", "wnba", "basketball"):
        if "ot" in detail_lower or "overtime" in detail_lower:
            return True
        if "4th" in detail_lower or "4th qtr" in detail_lower:
            m = re.search(r"([0-9]+):([0-9]{2})", detail)
            if m:
                mins = int(m.group(1))
                secs = int(m.group(2))
                if mins < 2 or (mins == 2 and secs == 0):
                    return True
        return False

    return False


def select_hero_game(games: List[Dict[str, Any]],
                     favourites: Optional[List[str]] = None) -> Optional[Dict[str, Any]]:
    """Select the hero game from a list of games according to the approved rules.

    Guards:
    1. Hero = the game that STARTED FIRST (earliest `date`), among eligible games.
    2. A game in its final stretch stops being hero-eligible (unless all candidates are in final stretch).
    3. If favourites are specified, favourite live games take precedence.
    """
    if not games:
        return None

    fav_set = set(str(f) for f in (favourites or []))

    def _is_fav(g: Dict[str, Any]) -> bool:
        if not fav_set:
            return False
        for t in g.get("teams", []):
            if str(t.get("id", "")) in fav_set:
                return True
        return False

    fav_games = [g for g in games if _is_fav(g)]
    pool = fav_games if fav_games else games

    eligible = [g for g in pool if not is_final_stretch(g)]
    candidates = eligible if eligible else pool

    return min(candidates, key=lambda g: g.get("date") or "9999")


def order_sports_games(games: List[Dict[str, Any]],
                       previous_order: Optional[List[str]] = None,
                       favourites: Optional[List[str]] = None) -> List[Dict[str, Any]]:
    """Order games for the Sports Hub with hero in slot 0.

    Rules:
    - Order is FIXED ON ENTRY, never reshuffled on refresh - scores and chips update
      in place, cards never move while someone is looking at them.
    - On fresh entry (previous_order is None/empty): hero is chosen via select_hero_game
      and placed at index 0, followed by remaining live games ordered by start time,
      followed by upcoming games.
    - On refresh (previous_order provided): existing games retain their exact index slots.
    """
    if not games:
        return []

    def _game_key(g: Dict[str, Any]) -> str:
        return str(g.get("id") or f"{g.get('sport')}_{g.get('name')}")

    if previous_order:
        game_map = {_game_key(g): g for g in games}
        ordered = []
        seen_keys = set()
        for key in previous_order:
            if key in game_map:
                ordered.append(game_map[key])
                seen_keys.add(key)
        for g in games:
            k = _game_key(g)
            if k not in seen_keys:
                ordered.append(g)
                seen_keys.add(k)
        return ordered

    live_games = [g for g in games if g.get("state") == "in"]
    other_games = [g for g in games if g.get("state") != "in"]

    hero = select_hero_game(live_games, favourites=favourites) if live_games else None
    if not hero and games:
        hero = select_hero_game(games, favourites=favourites)

    hero_key = _game_key(hero) if hero else None
    remaining_live = [g for g in live_games if _game_key(g) != hero_key]
    remaining_live.sort(key=lambda g: g.get("date", "9999"))

    other_games.sort(key=lambda g: g.get("date", "9999"))

    ordered = []
    if hero:
        ordered.append(hero)
    ordered.extend(remaining_live)
    ordered.extend(other_games)
    return ordered


def format_hero_plot(game: Dict[str, Any],
                     is_fav: bool = False,
                     quality: Optional[str] = None,
                     servers: Optional[int] = None,
                     source: Optional[str] = None,
                     resolved_time: Optional[str] = None,
                     probed: bool = False) -> str:
    """Format the rich Hero Card plot string for Arctic Fuse Spotlight."""
    sport = (game.get("sport") or "mlb").upper()
    teams = game.get("teams", [])
    if len(teams) >= 2:
        away_t = next((t for t in teams if t.get("homeAway") == "away"), teams[0])
        home_t = next((t for t in teams if t.get("homeAway") == "home"), teams[1])
    elif len(teams) == 1:
        away_t = teams[0]
        home_t = {"displayName": "TBD", "score": "", "abbreviation": "TBD"}
    else:
        away_t = {"displayName": "Away", "score": "", "abbreviation": "AWY"}
        home_t = {"displayName": "Home", "score": "", "abbreviation": "HME"}

    away_name = away_t.get("displayName") or away_t.get("shortDisplayName") or "Away"
    home_name = home_t.get("displayName") or home_t.get("shortDisplayName") or "Home"
    away_abbr = away_t.get("abbreviation") or (away_name.split()[-1][:3].upper() if away_name else "AWY")
    home_abbr = home_t.get("abbreviation") or (home_name.split()[-1][:3].upper() if home_name else "HME")
    away_score = str(away_t.get("score", "") or "")
    home_score = str(home_t.get("score", "") or "")
    detail = game.get("status_detail", "")
    is_live = (game.get("state") == "in")
    broadcast = (game.get("broadcast") or "").strip()

    lines = []

    # 1. Optional "My teams" marker (pink pill)
    # Hex ffb50385 matches Arctic Fuse ColorBanner_season_finale fallback;
    # plugin [COLOR=] tags cannot evaluate skin $VAR variables directly.
    if is_fav:
        lines.append("[COLOR=ffb50385][ MY TEAMS ][/COLOR]")

    # 2. League line, small caps, muted
    lines.append(f"[COLOR=panel_fg_50]{sport}[/COLOR]")

    # 3. Score with period detail muted beside it (duplicate full matchup title dropped; title control renders it)
    if is_live and (away_score or home_score):
        score_part = f"[B]{away_abbr} {away_score or '0'} - {home_abbr} {home_score or '0'}[/B]"
        if detail:
            score_part += f"   [COLOR=panel_fg_50]{detail}[/COLOR]"
        lines.append(score_part)
    elif detail:
        lines.append(f"[COLOR=panel_fg_50]{detail}[/COLOR]")

    # 4. Chip row: Live now (accent) / start time, broadcast network (if present), quality chip, server count
    # Hex ff03b585 matches Arctic Fuse ColorWatchedProgress fallback.
    chips = []
    if is_live:
        chips.append("[COLOR=ff03b585]● Live now[/COLOR]")
    else:
        chips.append(f"[COLOR=panel_fg_50]{detail or 'Upcoming'}[/COLOR]")

    if broadcast:
        chips.append(f"[COLOR=panel_fg_50][ {broadcast} ][/COLOR]")

    if quality:
        quality_chip = quality
    elif probed or source is not None or servers is not None:
        quality_chip = "quality unavailable"
    else:
        quality_chip = "not measured yet"
    chips.append(f"[COLOR=panel_fg_50][ {quality_chip} ][/COLOR]")
    if servers is not None and servers > 0:
        srv_label = f"{servers} servers" if servers != 1 else "1 server"
        chips.append(f"[COLOR=panel_fg_50][ {srv_label} ][/COLOR]")
    lines.append("   ".join(chips))

    # 5. Source footer line (only when resolved/measured)
    if source:
        res_time = resolved_time or "Resolved just now"
        lines.append(f"[COLOR=panel_fg_50]Source: {source}          {res_time}[/COLOR]")

    return "[CR]".join(lines)


def format_tile_label(game: Dict[str, Any], quality: Optional[str] = None) -> str:
    """Format the 2-line Tile label for the wall grid."""
    sport = (game.get("sport") or "mlb").upper()
    teams = game.get("teams", [])
    if len(teams) >= 2:
        away_t = next((t for t in teams if t.get("homeAway") == "away"), teams[0])
        home_t = next((t for t in teams if t.get("homeAway") == "home"), teams[1])
    elif len(teams) == 1:
        away_t = teams[0]
        home_t = {"displayName": "TBD", "score": "", "abbreviation": "TBD"}
    else:
        away_t = {"displayName": "Away", "score": "", "abbreviation": "AWY"}
        home_t = {"displayName": "Home", "score": "", "abbreviation": "HME"}

    away_name = away_t.get("shortDisplayName") or away_t.get("name") or away_t.get("displayName") or away_t.get("abbreviation") or "Away"
    home_name = home_t.get("shortDisplayName") or home_t.get("name") or home_t.get("displayName") or home_t.get("abbreviation") or "Home"
    away_abbr = away_t.get("abbreviation") or (away_name.split()[-1][:3].upper() if away_name else "AWY")
    home_abbr = home_t.get("abbreviation") or (home_name.split()[-1][:3].upper() if home_name else "HME")
    away_score = str(away_t.get("score", "") or "")
    home_score = str(home_t.get("score", "") or "")
    detail = game.get("status_detail", "")
    is_live = (game.get("state") == "in")

    # Line 1: Short matchup name, bold (prevents wrapping onto line 2)
    sep = " vs " if sport == "BOXING" else " @ "
    line1 = f"[B]{away_name}{sep}{home_name}[/B]"

    # Line 2: Score + period for live, status/sport for upcoming, plus measured quality if present
    if is_live:
        if away_score and home_score:
            parts = [f"{away_abbr} {away_score} - {home_abbr} {home_score}"]
            if detail:
                parts.append(detail)
            if quality:
                parts.append(quality)
            line2 = f"[COLOR=panel_fg_50]{' · '.join(parts)}[/COLOR]"
        elif detail:
            parts = [detail]
            if quality:
                parts.append(quality)
            line2 = f"[COLOR=panel_fg_50]{' · '.join(parts)}[/COLOR]"
        else:
            parts = [sport]
            if quality:
                parts.append(quality)
            line2 = f"[COLOR=panel_fg_50]{' · '.join(parts)}[/COLOR]"
    else:
        parts = [detail or sport]
        if quality:
            parts.append(quality)
        line2 = f"[COLOR=panel_fg_50]{' · '.join(parts)}[/COLOR]"

    return f"{line1}[CR]{line2}"


def _http_get_text(url: str, headers: Dict[str, str], timeout: Union[int, float]) -> Optional[str]:
    """GET a URL and return decoded text, or None on any failure."""
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.read().decode("utf-8", errors="ignore")
    except Exception:
        return None


# =============================================================================
# ESPN discovery
# =============================================================================

def fetch_schedule_as_scoreboard(sport: str, timeout: Union[int, float] = 10) -> Dict[str, Any]:
    """Synthesize an ESPN scoreboard payload for sports with no official ESPN endpoint."""
    entries = fetch_schedule(sport, timeout=timeout)
    events = []
    seen = set()
    for entry in entries:
        teams_str = entry.get("teams", "").strip()
        if not teams_str or teams_str.lower() in seen:
            continue
        seen.add(teams_str.lower())
        parts = re.split(r"\s+(?:vs\.?|v\.?|at|@)\s+", teams_str, flags=re.I)
        if len(parts) >= 2:
            f1, f2 = parts[0].strip(), parts[1].strip()
        else:
            f1, f2 = teams_str, "Opponent"

        event_id = "event-" + re.sub(r"[^a-z0-9]+", "-", teams_str.lower()).strip("-")
        provider = entry.get("provider", "SE")
        provider_name = "StreamEast" if provider == "SE" else ("BuffStreams" if provider == "BS" else provider)

        is_live = entry.get("is_live", False)
        ts = (entry.get("timestamp") or "").strip()
        if is_live or "live" in ts.lower():
            state = "in"
            short_detail = ts if ts else "Live Now"
            event_date = datetime.datetime.now(datetime.timezone.utc).isoformat()
        elif ts and not re.search(r'(yesterday|final|ended)', ts, re.I):
            state = "pre"
            short_detail = ts
            event_date = "9999"
        else:
            state = "post"
            short_detail = "Final"
            event_date = "0000"

        events.append({
            "id": event_id,
            "date": event_date,
            "name": teams_str,
            "shortName": f"{f1} vs {f2}",
            "status": {
                "type": {
                    "state": state,
                    "shortDetail": short_detail,
                }
            },
            "competitions": [{
                "id": event_id,
                "broadcasts": [{"market": "national", "names": [provider_name]}],
                "competitors": [
                    {
                        "id": event_id + "-1",
                        "homeAway": "away",
                        "score": "",
                        "team": {
                            "id": event_id + "-1",
                            "displayName": f1,
                            "shortDisplayName": f1,
                            "location": f1,
                            "abbreviation": f1.split()[-1][:4].upper() if f1 else "F1",
                            "logo": "special://skin/extras/icons/boxing.png"
                        }
                    },
                    {
                        "id": event_id + "-2",
                        "homeAway": "home",
                        "score": "",
                        "team": {
                            "id": event_id + "-2",
                            "displayName": f2,
                            "shortDisplayName": f2,
                            "location": f2,
                            "abbreviation": f2.split()[-1][:4].upper() if f2 else "F2",
                            "logo": "special://skin/extras/icons/boxing.png"
                        }
                    }
                ]
            }]
        })
    return {"events": events}


def fetch_espn_scoreboard(sport: str, timeout: Union[int, float] = 10) -> Dict[str, Any]:
    """Fetch the raw ESPN scoreboard JSON for a configured sport (or {})."""
    cfg = SPORT_CONFIG.get(sport)
    if not cfg:
        return {}
    if not cfg.get("espn"):
        return fetch_schedule_as_scoreboard(sport, timeout=timeout)
    url = ESPN_SCOREBOARD.format(path=cfg["espn"])
    text = _http_get_text(url, {"User-Agent": ESPN_UA, "Accept": "application/json"}, timeout)
    if not text:
        return {}
    try:
        return json.loads(text)
    except Exception:
        return {}


def parse_espn_events(data: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Flatten an ESPN scoreboard payload into simple game dicts.

    Each game carries `name`, `shortName`, `state` (pre/in/post), `id`, `date`,
    `status_detail`, `broadcast`, and a `teams` list; every team carries `id`,
    `displayName`, `shortDisplayName`, `location`, `abbreviation`, `logo`,
    `homeAway`, `score`, and `nickname` (the LAST word of its displayName, which
    is the piece that survives the city/nickname ambiguity when matching schedules).

    `location` is the school or city ESPN files the team under ("USC",
    "San Jose State", "Washington"). College sources name teams by SCHOOL where
    pro sources name them by nickname, so the school has to be carried through
    or every college game is unmatchable (see `team_match_keys`).
    """
    games: List[Dict[str, Any]] = []
    for ev in data.get("events", []) or []:
        status_type = (ev.get("status") or {}).get("type") or {}
        state = status_type.get("state")
        short_detail = status_type.get("shortDetail", "") or ""
        comps = ev.get("competitions") or []
        competitors = (comps[0].get("competitors") if comps else []) or []
        teams = []
        for c in competitors:
            t = c.get("team") or {}
            display = t.get("displayName", "") or ""
            score_val = c.get("score")
            score_str = str(score_val) if score_val is not None else ""
            logos_list = t.get("logos") or []
            logo = t.get("logo", "") or (logos_list[0].get("href", "") if logos_list else "")
            teams.append({
                "id": str(t.get("id", "") or ""),
                "displayName": display,
                "shortDisplayName": t.get("shortDisplayName", "") or "",
                "location": t.get("location", "") or "",
                "abbreviation": t.get("abbreviation", "") or "",
                "logo": logo,
                "homeAway": c.get("homeAway", "") or "",
                "score": score_str,
                "nickname": (display.split()[-1] if display.split() else ""),
            })

        broadcasts_raw = comps[0].get("broadcasts") if comps else []
        nat_names = []
        other_names = []
        for b in (broadcasts_raw or []):
            mkt = (b.get("market") or "").lower()
            for n in b.get("names", []):
                if n and n not in nat_names and n not in other_names:
                    if mkt == "national":
                        nat_names.append(n)
                    else:
                        other_names.append(n)
        network_names = nat_names if nat_names else other_names
        broadcast_str = ", ".join(network_names) if network_names else ""

        games.append({
            "id": str(ev.get("id", "") or ""),
            "date": ev.get("date", "") or "",
            "name": ev.get("name", "") or "",
            "shortName": ev.get("shortName", "") or "",
            "state": state,
            "status_detail": short_detail,
            "broadcast": broadcast_str,
            "teams": teams,
        })
    return games


def espn_live_games(games: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Canonical live card list = only games whose state == 'in'."""
    return [g for g in games if g.get("state") == "in"]


def espn_upcoming_games(games: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Games that have not started yet, soonest first.

    These arrive in the SAME scoreboard payload the live sweep already fetches and were
    simply discarded, so surfacing them costs no extra request. That matters: an NFL
    category the night before kickoff used to say "no live games right now" while the
    device was holding tomorrow's fixture in memory.

    Sorted by kickoff so the next game to start is first, which is what a hub row wants.
    """
    pre = [g for g in games if g.get("state") == "pre"]
    return sorted(pre, key=lambda g: g.get("date") or "")


def format_kickoff(game: Dict[str, Any], now: Optional[datetime.datetime] = None) -> str:
    """Kickoff as a short local-time phrase: 'Tonight 8:20 PM', 'Tomorrow 1:00 PM',
    'Sat 3:30 PM'.

    ESPN publishes `date` as UTC ISO 8601. It is converted to the DEVICE's local zone,
    because a Shield in Boston and a Deck in another timezone must each show the time
    their owner would actually turn the TV on at. Falls back to ESPN's own
    `status_detail` string if the date is missing or unparseable - a wrong-looking but
    real ESPN phrase beats an empty tile.
    """
    raw = (game.get("date") or "").strip()
    if not raw:
        return game.get("status_detail", "") or ""
    try:
        # fromisoformat did not accept a trailing 'Z' before 3.11, and the device is on
        # 3.11 while the harness runs newer. Normalise rather than depend on the version.
        iso = raw[:-1] + "+00:00" if raw.endswith("Z") else raw
        when = datetime.datetime.fromisoformat(iso)
        if when.tzinfo is None:
            when = when.replace(tzinfo=datetime.timezone.utc)
        local = when.astimezone()
    except Exception:  # noqa: BLE001 - a bad date must not lose the whole row
        return game.get("status_detail", "") or ""

    ref = now or datetime.datetime.now(local.tzinfo)
    clock = local.strftime("%I:%M %p").lstrip("0")
    days = (local.date() - ref.date()).days
    if days == 0:
        return "Tonight %s" % clock if local.hour >= 17 else "Today %s" % clock
    if days == 1:
        return "Tomorrow %s" % clock
    if 2 <= days <= 6:
        return "%s %s" % (local.strftime("%a"), clock)
    return "%s %s" % (local.strftime("%a %b %-d"), clock)


# =============================================================================
# Title matching (ESPN game <-> schedule entry)
# =============================================================================

def _normalize(s: str) -> str:
    """Lowercase, fold accents to ASCII, and collapse every non-alphanumeric run
    to a single space.

    The accent fold is load-bearing for college sources. ESPN writes
    "San Jose State" with an acute accent on the e; StreamEast writes
    "San Jose St." without one. Stripping `[^a-z0-9]+` on its own turned the
    accented "Jose" into the token "jos", which never equals "jose", so every
    accented school failed to match outright. NFKD splits an
    accented character into its ASCII base plus a combining mark, so dropping
    the combining marks leaves the plain letter behind. HTML entities are
    unescaped first for the same reason: a schedule's "Alabama A&amp;M" then
    normalises exactly as ESPN's "Alabama A&M" does.
    """
    text = html.unescape(s or "")
    decomposed = unicodedata.normalize("NFKD", text)
    folded = "".join(c for c in decomposed if not unicodedata.combining(c))
    return re.sub(r"[^a-z0-9]+", " ", folded.lower()).strip()


def espn_nicknames(game: Dict[str, Any]) -> List[str]:
    """The two team nicknames (last word of each displayName)."""
    return [t["nickname"] for t in game.get("teams", []) if t.get("nickname")]


def _last_n_tokens(display: str, n: int) -> str:
    """Normalised last `n` tokens of a display name, e.g. ('Boston Red Sox', 2)
    -> 'red sox'."""
    toks = _normalize(display).split()
    return " ".join(toks[-n:]) if toks else ""


# The mirror image of _SCHOOL_SUFFIXES, on the LEFT. A directional or regional
# word in front of a school name makes a DIFFERENT school: Michigan and Western
# Michigan, Texas and North Texas, Carolina and South Carolina, Tennessee and
# Middle Tennessee are all separate FBS programmes that play on the same
# Saturday and land on the same mixed-league schedule page. A key that does not
# itself begin with one of these must not match inside a name that does.
_SCHOOL_MODIFIERS: FrozenSet[str] = frozenset({
    "north", "south", "east", "west",
    "northern", "southern", "eastern", "western",
    "central", "middle",
})

# Single-token keys shorter than this are dropped, with NO exception - the
# primary key included. It keeps two-letter tokens out of the key sets, where
# they are a cheap accidental hit in an unrelated title: cities ("LA", "SF",
# "SD") and, the case that actually bit, the club suffixes "SC", "FC" and "CF".
# An MLS game between "St. Louis City SC" and "Inter Miami CF" reduced to the
# primary keys "sc" and "cf", and those two tokens both appear in the entirely
# unrelated "SC Braga vs CF Estrela" sitting on the same mixed-league schedule
# page - a click on one game playing another. Three-letter and longer
# abbreviations ("USC", "SJSU") are kept.
#
# A team whose primary key would be dropped is escalated to two tokens by
# `game_team_keys` ("city sc", "miami cf") rather than left unmatchable. If even
# the escalation is still a single short token the team ends up with no key at
# all and the game matches nothing - which loses a match but can never route a
# click to the wrong game, and that is the direction this whole module errs in.
_MIN_SINGLE_TOKEN_KEY = 3


def game_team_keys(game: Dict[str, Any]) -> List[str]:
    """The single most discriminating key per team - one string each, in team
    order. This is the PRIMARY key that `team_match_keys` widens around.

    Normally the nickname (last word) is enough. But two teams can share a
    nickname - "Boston Red Sox" and "Chicago White Sox" both end in "Sox",
    "LAFC" and "Austin FC" both in "FC" - and a bare "sox" then cross-links a
    Red-vs-White game to any title merely containing "sox". When the two
    nicknames collide (identical, or one a substring of the other) we escalate
    BOTH sides to their last two tokens ("red sox" / "white sox") so they stay
    distinguishable, and the bare nickname is then never offered as a key at
    all.

    A nickname shorter than `_MIN_SINGLE_TOKEN_KEY` is escalated the same way
    even when the two do NOT collide. Club suffixes are the case that matters:
    "St. Louis City SC", "Inter Miami CF" and "Charlotte FC" reduce to "sc",
    "cf" and "fc", which are not pairwise identical or substrings of each other
    and so sail through the collision test while being far too generic to name
    a club. Only the offending side is escalated - the other team keeps exactly
    the key it had, because shortening the search on a key that was never
    ambiguous buys nothing and only loses matches.
    """
    teams = [t for t in game.get("teams", []) if t.get("displayName")]
    if len(teams) < 2:
        return []
    d0, d1 = teams[0]["displayName"], teams[1]["displayName"]
    a, b = _last_n_tokens(d0, 1), _last_n_tokens(d1, 1)
    if a and b and (a == b or a in b or b in a):
        return [_last_n_tokens(d0, 2), _last_n_tokens(d1, 2)]
    return [_last_n_tokens(disp, 2) if len(nick) < _MIN_SINGLE_TOKEN_KEY else nick
            for disp, nick in ((d0, a), (d1, b))]


# School-name suffixes the two sources spell differently: ESPN writes
# "San Jose State", StreamEast writes "San Jose St.". Every entry maps a
# suffix token to the ALTERNATE SPELLINGS OF THAT TOKEN - never to nothing.
# Rewriting is a substitution, never a deletion, so "Ohio State" can become
# "Ohio St" but can never become bare "Ohio" and cross-link to Ohio Bobcats.
_SCHOOL_SUFFIXES: Dict[str, Tuple[str, ...]] = {
    "state": ("state", "st"),
    "st": ("state", "st"),
    "university": ("university", "univ"),
    "univ": ("university", "univ"),
}


def _suffix_variants(key: str) -> List[str]:
    """Alternate spellings of a key whose LAST token is a school suffix.

    Only a TRAILING suffix is rewritten, and only when at least one token
    precedes it. That is exactly what keeps "St. Louis Cardinals" intact: its
    "st" is a LEADING token, so nothing is rewritten and it can never turn into
    "State Louis". Blind token rewriting would.
    """
    toks = key.split()
    if len(toks) < 2:
        return []
    alts = _SCHOOL_SUFFIXES.get(toks[-1])
    if not alts:
        return []
    return [" ".join(toks[:-1] + [alt]) for alt in alts]


def _location_is_identity(team: Dict[str, Any]) -> bool:
    """True when ESPN's own fields say this team is named by SCHOOL, so its
    `location` is a usable standalone match key.

    A pro team's `shortDisplayName` is a trailing run of its `displayName`
    ("Washington Nationals" -> "Nationals", "Boston Red Sox" -> "Red Sox"), so
    its `location` is a bare city. Cities must NOT become keys: the schedule
    pages mix leagues (a college page carries MLB, MLS and boxing rows), and
    "Miami" or "Washington" names a different team in each of them.

    A college team's `shortDisplayName` is the school and is NOT a trailing run
    ("USC Trojans" -> "USC", "San Jose State Spartans" -> "San Jose St"), and
    there the location IS the identity.
    """
    disp = _normalize(team.get("displayName", "")).split()
    short = _normalize(team.get("shortDisplayName", "")).split()
    if not disp or not short:
        return False
    return disp[-len(short):] != short


def team_match_keys(team: Dict[str, Any], primary: str) -> List[str]:
    """Every acceptable way ONE team may be named in a schedule title.

    `primary` is the key `game_team_keys` computed - the nickname, or the
    two-token escalation when the nicknames collide or one of them is too short
    to identify a club. It is held to the SAME minimum length as every other
    key: it used to be exempt (`allow_short=True`), and since it is the key that
    always matches, that exemption was the whole two-letter cross-link bug. The
    rest widen how a team may be NAMED - school, abbreviation, short name, full
    name, and school-suffix respellings of each. Widening the keys never relaxes
    the rule that BOTH teams must be named; see `schedule_matches_game`.
    """
    keys: List[str] = []

    def add(raw: str) -> None:
        key = _normalize(raw)
        if not key:
            return
        if len(key.split()) == 1 and len(key) < _MIN_SINGLE_TOKEN_KEY:
            return
        for candidate in [key] + _suffix_variants(key):
            if candidate not in keys:
                keys.append(candidate)

    add(primary)
    if _location_is_identity(team):
        add(team.get("location", ""))
    add(team.get("shortDisplayName", ""))
    add(team.get("abbreviation", ""))
    add(team.get("displayName", ""))
    return keys


def game_team_key_sets(game: Dict[str, Any]) -> List[List[str]]:
    """One candidate-key list per team, in team order, or [] if unusable."""
    teams = [t for t in game.get("teams", []) if t.get("displayName")]
    primaries = [k for k in game_team_keys(game) if k]
    if len(teams) < 2 or len(primaries) < 2:
        return []
    return [team_match_keys(teams[i], primaries[i]) for i in range(2)]


def _phrase_spans(title_toks: List[str], phrase: str) -> List[Tuple[int, int]]:
    """Every contiguous token span in `title_toks` that equals `phrase`.

    Token equality gives word-boundary matching for free, so "sox" never
    matches inside a longer token and "red sox" must appear adjacent.

    Two extra rejections, one for each edge of the span. They are NOT a general
    "a school is never mistaken for its neighbour" rule - an earlier version of
    this docstring claimed that and it is false in both directions. Each guard
    covers exactly one enumerated word list and nothing else:

    - RIGHT: a key that does not itself end in a token of `_SCHOOL_SUFFIXES`
      ("state", "st", "university", "univ") is refused when the very next title
      token IS one. So "Ohio" does not match inside "Ohio State". It does
      NOTHING for "Georgia" inside "Georgia Tech" or "Texas" inside "Texas
      Tech", because "tech" is not in that list - and adding it would be the
      same escalating word-list game that this module has now stopped playing.
    - LEFT: a key that does not itself begin with a token of
      `_SCHOOL_MODIFIERS` (the compass points plus "central"/"middle") is
      refused when the token immediately BEFORE it IS one. So "Michigan" does
      not match inside "Western Michigan". It does NOTHING for "Louisiana"
      inside "Southeastern Louisiana", because "southeastern" is not in that
      list either.

    A team whose own name starts with a modifier keeps matching itself, because
    the guard only fires when the KEY lacks the modifier the title has: "western
    michigan" begins with "western", so nothing is rejected, and it matches
    "Western Michigan" while plain "michigan" cannot.

    THE SLUG PATH IS NOW THE PRIMARY DEFENCE against all of this, and it needs
    neither list: see `slug_matches_game`. These guards remain because the
    title path is still what decides an entry whose href carries no usable slug
    (a generic boxing/MMA event page), and there they are better than nothing.
    """
    phrase_toks = phrase.split()
    if not phrase_toks:
        return []
    width = len(phrase_toks)
    key_ends_in_suffix = phrase_toks[-1] in _SCHOOL_SUFFIXES
    key_starts_with_modifier = phrase_toks[0] in _SCHOOL_MODIFIERS
    spans: List[Tuple[int, int]] = []
    for i in range(len(title_toks) - width + 1):
        if title_toks[i:i + width] != phrase_toks:
            continue
        nxt = title_toks[i + width] if i + width < len(title_toks) else ""
        if not key_ends_in_suffix and nxt in _SCHOOL_SUFFIXES:
            continue
        prev = title_toks[i - 1] if i > 0 else ""
        if not key_starts_with_modifier and prev in _SCHOOL_MODIFIERS:
            continue
        spans.append((i, i + width))
    return spans


def _phrase_in_tokens(norm_title: str, phrase: str) -> bool:
    """True iff `phrase` appears as a contiguous token run in `norm_title`."""
    return bool(_phrase_spans(norm_title.split(), phrase))


# =============================================================================
# Slug matching (ESPN game <-> schedule entry href) - THE PRIMARY PATH
# =============================================================================

# A schedule entry's href carries both team names IN FULL, in its second-to-last
# path segment:
#
#     https://thestreameast.top/cfb/san-jose-state-spartans-usc-trojans/43527488
#                                   `------------- the slug ---------'
#
# while the display title on the same row is "USC vs San Jose St." - a lossy
# abbreviation that drops one nickname and shortens the other school. Matching on
# that title is what forced the hand-maintained word lists above, and three
# consecutive review rounds each found a new collision created by the previous
# round's fix: "sc"/"cf"/"fc" hitting unrelated European clubs, then "city sc"
# being a contiguous run inside "Orlando City SC", then "Georgia" inside "Georgia
# Tech", "Texas" inside "Texas Tech", "Louisiana" inside "Southeastern
# Louisiana". None of those collisions exists between FULL names, so the fix is
# to match on the full names the slug already carries rather than to keep
# enumerating the abbreviations the title does not.
#
# It also fixes the click path structurally. `play_sport` rebuilds a game on
# click as `{'displayName': ...}` only - no `location`, `abbreviation` or
# `shortDisplayName` - so the college title path, which needs those, could never
# match a single college game on a real device. The slug rule needs only
# `displayName`, which the click path does carry.

# Fewer tokens than this and the segment is a CATEGORY, not a pairing: SE serves
# generic event pages as `/stream/boxing/<event>-live-stream` and
# `/stream/mlb/<event>-live-stream`, whose second-to-last segment is the bare
# "boxing" or "mlb". Those pages are not about a specific game and must never
# satisfy the matcher; entries carrying one fall back to the title path, which is
# the only way a boxing or MMA card is matchable at all.
_MIN_SLUG_TOKENS = 3


def slug_from_href(href: str) -> str:
    """The normalised team slug of a schedule href, or '' when it has none.

    Extracted ONCE, at parse time (`fetch_schedule`), never per comparison.

    Deliberately defensive: BuffStreams' href shape is UNVERIFIED - its pointer
    file 404s and its default domain has been seized, so it returned zero
    entries in every fetch available while this was written. Anything that is
    missing, too short, hyphen-free or a bare category yields '' and the entry
    falls back to the title matcher. That fallback is load-bearing, not
    decorative: if BS turns out to publish a different href shape, BS entries
    degrade to exactly the behaviour they had before this function existed.
    """
    try:
        parts = [p for p in urlparse(href or "").path.split("/") if p]
    except Exception:
        return ""
    if len(parts) < 2:
        return ""
    segment = parts[-2]
    if "-" not in segment:
        return ""
    toks = _normalize(segment).split()
    if len(toks) < _MIN_SLUG_TOKENS:
        return ""
    return " ".join(toks)


def _slug_is_usable(slug: str) -> bool:
    """True when `slug` can decide a match on its own."""
    return bool(slug) and len(slug.split()) >= _MIN_SLUG_TOKENS


def _slug_token_forms(toks: List[str], shorten: bool = True) -> List[str]:
    """The spellings ONE ESPN NAME may take, each as a SEPARATOR-FREE string.

    WHICH FIELD THE SHORTENING VARIANTS APPLY TO: `displayName` ONLY. Every
    example below is a `displayName`, and `_team_covers_block` calls this with
    `shorten=False` for `location`, so a location is only ever spelled
    verbatim. That is not a stylistic choice, it is the fix for a measured
    defect: with the variants applied to `location` too, ESPN's "North Carolina
    A&T" had its location shortened by the drop-initials rule to
    `northcarolina` and tiled `abilene-christian-wildcats-north-carolina` - a
    game about North Carolina - and "Saint Francis (IN)" shortened to
    `saintfrancis` and tiled a Saint Francis Red Flash slug. A shortened
    location is a school name with its disambiguator filed off, which is
    precisely the accidental identity this whole rewrite exists to remove.
    Measured over the 1,295 real ESPN teams of CFB/CBB/MLB/NFL/NBA/NHL/MLS/EPL,
    the shortening cost 5,924 same-league wrong pairs on truncated slugs
    (6,694 with it, 770 without); college took all of that damage - CFB went
    from 4,820 to 12, CBB from 1,118 to 2. None of the three variants was ever
    justified by a location; each was observed on a `displayName` against a
    live StreamEast row.

    Applied to the ESPN name only, NEVER to the slug block. The variants below
    all SHORTEN a name, and shortening the block instead opens a hazard in the
    other direction: the block "miami oh" of a truncated `miami-oh-<opponent>`
    slug would shorten to "miami" and be covered by the Miami Hurricanes'
    location, sending a Miami (FL) click to a Miami (OH) game. Every difference
    actually observed between the two sources has ESPN carrying the extra
    tokens, so one-directional is both sufficient and strictly safer.

    Joining the tokens is what absorbs the punctuation the two sources disagree
    about: ESPN's "Hawai'i Rainbow Warriors" normalises to the tokens
    ("hawai", "i", "rainbow", "warriors") and joins to "hawaiirainbowwarriors",
    which is exactly what the slug tokens ("hawaii", "rainbow", "warriors")
    join to. That spelling is produced whatever `shorten` says - it is not a
    shortening, it is the same tokens with different punctuation. Three further
    spellings are generated ONLY when `shorten` is true, because the sources
    really do differ on them, each verified against a live StreamEast row:

    - initials dropped - ESPN "Stephen F. Austin Lumberjacks" vs the slug
      `stephen-austin-lumberjacks`.
    - one trailing token of at most two letters dropped - ESPN "Houston Dynamo
      FC", "Minnesota United FC" and "Atlanta United FC" against the slugs
      `houston-dynamo`, `minnesota-united` and `atlanta-united`. This is a
      length test, not a list of club suffixes, and it can only ever shorten a
      name that must still cover its whole block exactly.
    - a leading "the" dropped - ESPN "The Citadel Bulldogs" against the slug
      `citadel-bulldogs-wofford-terriers`, live on 2026-08-29. That is an
      English article, not domain knowledge about schools, and it is the only
      word named anywhere in this function.

    None of the three is a substitution table that has to grow: they are a
    length test, a length test and an article. The domain word lists that kept
    growing (`_SCHOOL_SUFFIXES`, `_SCHOOL_MODIFIERS`) are not needed here at
    all, because full names do not collide the way abbreviations do.
    """
    out: List[str] = []

    def add(ts: List[str]) -> None:
        joined = "".join(ts)
        if joined and joined not in out:
            out.append(joined)

    add(toks)
    if not shorten:
        return out
    add([t for t in toks if len(t) > 1])
    if len(toks) > 1 and len(toks[-1]) <= 2:
        add(toks[:-1])
    if len(toks) > 1 and toks[0] == "the":
        add(toks[1:])
    return out


def _slug_name_forms(text: str, shorten: bool = True) -> FrozenSet[str]:
    """Every separator-free spelling one ESPN name may take inside a slug.

    `shorten=False` returns the VERBATIM spellings only - the normalised tokens
    joined, and the same with "&" written out. It is what `location` gets; see
    `_slug_token_forms` for why.
    """
    base = _normalize(text)
    if not base:
        return frozenset()
    forms = set(_slug_token_forms(base.split(), shorten=shorten))
    # "&" written out: ESPN's "Alabama A&M Bulldogs" against the live slug
    # `alabama-a-and-m-bulldogs`. _normalize drops the ampersand to a space, so
    # this variant has to be produced from the raw text. It is a re-spelling,
    # not a shortening - "alabamaaandm" is LONGER than "alabamaam" - so it is
    # produced on the verbatim path too.
    amp = _normalize(re.sub(r"&", " and ", html.unescape(text or ""))).split()
    if amp:
        forms.update(_slug_token_forms(amp, shorten=shorten))
    return frozenset(forms)


def _team_covers_block(team: Dict[str, Any], block: List[str]) -> bool:
    """True iff this team's name accounts for the WHOLE of `block`.

    `displayName` may cover a block of any length, in any of the spellings
    `_slug_name_forms` generates - ESPN's "Athletics" is a legitimate one-token
    team name, and the live slug `baltimore-orioles-athletics` needs it.

    `location` may cover a block of TWO OR MORE tokens, VERBATIM ONLY. Two
    separate limits, for two separate reasons:

    - It is accepted at all because StreamEast truncates one side of some slugs
      to the school alone (`western-carolina-catamounts-eastern-kentucky`,
      `monmouth-hawks-tennessee-tech`), and only the location can cover
      "eastern kentucky".
    - Two tokens minimum, because a bare "georgia", "texas", "michigan" or
      "washington" covering a one-token block is the accidental identity this
      whole rewrite exists to remove.
    - Verbatim, because the shortening variants turn a disambiguated school
      into an ambiguous one: "North Carolina A&T" -> `northcarolina`, "Saint
      Francis (IN)" -> `saintfrancis`. Those are not spelling differences
      between the two sources, they are different schools. `shorten=False` is
      the whole fix; the reasoning and the measured counts are in
      `_slug_token_forms`.

    `shortDisplayName` and `abbreviation` are DELIBERATELY not used, and the
    same collision argument is why: `shortDisplayName` is the city or the
    school with everything distinguishing removed ("Miami", "Orlando", "N
    Carolina A&T"), and `abbreviation` is two or three letters. Neither can
    identify a team on its own, so adding either would reintroduce by a
    different door exactly the ambiguity `shorten=False` just closed. They stay
    out.

    KNOWN RECALL GAP, deliberately not fixed (review advisory 2, 2026-08-29):
    on the CLICK path a truncated slug cannot match, because covering its
    truncated side needs `location` and `play_sport` rebuilds the clicked game
    from plugin:// query parameters that carry `displayName` only. That is a
    MISSED match, never a wrong one - the click resolves nothing and logs
    reason=no_match rather than routing to another game. Listing (which builds
    games from the full ESPN payload, locations included) is unaffected.
    """
    joined = "".join(block)
    if not joined:
        return False
    if joined in _slug_name_forms(team.get("displayName", "")):
        return True
    if len(block) >= 2 and joined in _slug_name_forms(team.get("location", ""),
                                                     shorten=False):
        return True
    return False


def slug_matches_game(slug: str, game: Dict[str, Any]) -> bool:
    """True iff the two teams of `game` TILE the slug exactly.

    The slug is split at every position into two blocks, and a match needs one
    team to account for the whole left block and the other for the whole right
    block. Both blocks non-empty, together covering every token, neither
    overlapping the other.

    FULL COVERAGE is what makes this unable to misroute, and it is strictly
    stronger than "both names appear over disjoint spans". Disjoint-but-partial
    would still let a `location` match a fragment: "Georgia" occupies token 0 of
    `georgia-tech-yellow-jackets-clemson-tigers` and "Clemson Tigers" occupies
    tokens 4-5, disjointly, so a Georgia-vs-Clemson game would match a Georgia
    TECH game. Requiring the pair to tile the slug makes that impossible -
    Georgia would have to account for "georgia" while Clemson accounted for
    "tech yellow jackets clemson tigers", which it does not. The same argument
    kills every reported misroute:

    - "Sporting Kansas City" is not a prefix or a suffix block of
      `orlando-city-sc-new-york-city-fc`, so no split works. The old title rule
      matched because "city sc" is a contiguous RUN inside it.
    - "Michigan Wolverines" cannot cover "western michigan" or "western michigan
      broncos", and "michigan" alone is a fragment, not a block.
    - "Alabama Crimson Tide" cannot cover any block of
      `alabama-a-and-m-bulldogs-howard-bison`.

    WHAT THIS GUARANTEES, AND WHAT IT RESTS ON. A misroute needs the WRONG pair
    of teams to tile the slug end to end with nothing left over. Tiling is a
    real constraint and it is what kills every misroute listed above - but it
    is NOT an absolute, and an earlier version of this docstring wrongly stated
    it as one ("the slug would have to be about them"). The guarantee is
    exactly as strong as the set of spellings `_slug_name_forms` will accept
    for a name, because any variant that SHORTENS a name lets a longer name
    tile a block belonging to a shorter one.

    That was not hypothetical, it was measured. Sweep, 2026-08-29: 1,295 real
    ESPN teams across CFB/CBB/MLB/NFL/NBA/NHL/MLS/EPL, every same-league pair,
    2.71M slug shapes - the full-name slug plus the three TRUNCATED shapes
    (school+name, name+school, school+school) StreamEast is known to publish.

    - FULL-NAME slugs: ZERO wrong pairs, before and after. That is the strong
      result, and it is what the click path and every SE row actually uses.
    - TRUNCATED shapes, with the variants applied to `location`: 6,694 wrong
      pairs. "North Carolina A&T" shortened to `northcarolina` and tiled
      `abilene-christian-wildcats-north-carolina`. Confining the variants to
      `displayName` takes that to 770 - CFB 4,820 -> 12, CBB 1,118 -> 2.
    - Of the 770 that REMAIN, 756 are teams whose `location` is verbatim
      identical - New York Rangers and Islanders, Los Angeles Rams and
      Chargers - and 12 are college slugs whose two schools concatenate
      ambiguously (`north-carolina-central-arkansas` is North Carolina Central
      + Arkansas or North Carolina + Central Arkansas; both readings are real
      teams). Neither is made by a variant, and neither count moved: ESPN's own
      data cannot tell those apart, so nothing here can.
    - The last 2 ARE a variant, and are the honest cost of the trailing-two-
      letter rule: ESPN's malformed "Oklahoma Panhandle OK PANHANDLE ST" ends
      in a two-letter token, so dropping it frees "st" to start "st lawrence".
      Two slugs out of 2.71M, on one row of junk data, against three live
      StreamEast rows the rule exists to match. Left as is; revisit if a real
      name ever collides this way.

    So the guarantee is: FULL-NAME TILING, exact and measured; plus shortening
    admitted only on the one field where a real source disagreement was
    observed. On a truncated slug it degrades to "the pair that tiles it", which
    is ambiguous exactly where the two names are. Widen the variants, or extend
    them to another field, and it weakens in proportion - measure before doing
    either.
    """
    teams = [t for t in game.get("teams", []) if t.get("displayName")]
    if len(teams) < 2 or not _slug_is_usable(slug):
        return False
    toks = slug.split()
    for cut in range(1, len(toks)):
        left, right = toks[:cut], toks[cut:]
        for a, b in ((0, 1), (1, 0)):
            if _team_covers_block(teams[a], left) and _team_covers_block(teams[b], right):
                return True
    return False


def entry_matches_game(entry: Dict[str, str], game: Dict[str, Any]) -> bool:
    """Match one SCHEDULE ENTRY against one ESPN game - the call sites use this.

    Prefers the slug `fetch_schedule` stored on the entry, and re-derives it
    from the href when the entry predates that (a hand-built dict, or an entry
    from an older caller).
    """
    slug = entry.get("slug")
    if not slug:
        slug = slug_from_href(entry.get("href", ""))
    return schedule_matches_game(entry.get("teams", ""), game, slug=slug)


def schedule_matches_game(schedule_title: str, game: Dict[str, Any],
                          slug: str = "") -> bool:
    """Decide one schedule entry against one ESPN game.

    SLUG FIRST, AND ALONE. When a usable `slug` is supplied it is the whole
    decision: a slug that does not match is a NO, and the title is never
    consulted. Falling through to the title on a slug miss would reintroduce
    every collision the slug exists to remove, because the title is the lossy
    string - the fall-through, not the title matcher, is the hazard. An
    UNUSABLE slug (missing, or a bare category segment such as "boxing") is
    treated as no slug at all and takes the title path below, which is the only
    way a generic boxing or MMA event page is matchable.

    The title path, unchanged: BOTH teams named in the title, by DIFFERENT
    keys, over DISJOINT token spans.

    ESPN gives "Miami Marlins at Washington Nationals"; StreamEast gives
    "Washington Nationals vs Miami Marlins" - order and the at/vs joiner differ,
    so we match on team keys rather than on the string. Each team contributes a
    SET of acceptable keys (`team_match_keys`) because pro sources name teams by
    nickname while college sources name them by school.

    Three properties keep a widened key set from cross-linking two games:

    1. BOTH teams must be named. Widening never touches this - a title naming
       one team of the pair is still rejected.
    2. A key must appear as a CONTIGUOUS TOKEN RUN, so a shared word can never
       bridge two teams and no key matches inside a longer token.
    3. The two teams must be named by DIFFERENT keys over DISJOINT spans. A key
       that identifies both teams equally identifies neither (two Los Angeles
       clubs cannot both be satisfied by "los angeles"), and one run of tokens
       cannot be counted twice.
    """
    if _slug_is_usable(slug):
        return slug_matches_game(slug, game)

    key_sets = game_team_key_sets(game)
    if len(key_sets) < 2:
        return False
    title_toks = _normalize(schedule_title).split()
    if not title_toks:
        return False

    hits: List[List[Tuple[str, Tuple[int, int]]]] = []
    for keys in key_sets:
        found = [(key, span) for key in keys
                 for span in _phrase_spans(title_toks, key)]
        if not found:
            return False
        hits.append(found)

    for key_a, (start_a, end_a) in hits[0]:
        for key_b, (start_b, end_b) in hits[1]:
            if key_a == key_b:
                continue
            if end_a <= start_b or end_b <= start_a:
                return True
    return False


# =============================================================================
# StreamEast / BuffStreams - schedule (Stage A)
# =============================================================================

def resolve_provider_base_checked(pointer_url: str, default_base: str,
                                  timeout: Union[int, float] = 8) -> Tuple[str, bool]:
    """`resolve_provider_base`, plus whether the POINTER is what answered.

    The bool is the half that was missing: falling back to the compiled-in default is
    indistinguishable from a healthy resolve by return value alone, and that is exactly
    how a renamed pointer file hid for days. Comparing the result against `default_base`
    cannot recover it either, since a live pointer may legitimately name the default.
    """
    text = _http_get_text(pointer_url, {"User-Agent": UA}, timeout)
    if text:
        m = re.search(r'"([^"]+)"', text)
        if m and m.group(1).startswith("http"):
            return m.group(1).rstrip("/"), True
    return default_base.rstrip("/"), False


def resolve_provider_base(pointer_url: str, default_base: str, timeout: Union[int, float] = 8) -> str:
    """Resolve a provider's current base URL from its pointer file.

    The pointer body is a quoted string; the first "..." capture is the base.
    Falls back to `default_base` on any failure.
    """
    return resolve_provider_base_checked(pointer_url, default_base, timeout)[0]


# StreamEast rows, matched PER ITEM rather than with one lazy regex across the page.
# Two things went wrong with the single-regex version and this shape fixes both:
#   1. It required class="..." to sit IMMEDIATELY after `<li `. The site now emits
#      `<li data-league="mlb" class="f1-podium--item match-card ">`, so every row missed and
#      the provider silently contributed zero entries while looking healthy.
#   2. A page carries more f1-podium--item elements than it has games (39 vs 9 on
#      mlbstreams, measured 2026-09-08). With `(?s)` and lazy quantifiers a single regex
#      can run past the end of one item and stitch together fields from two different
#      games. Slicing the page at item boundaries first makes that structurally impossible.
_SE_ITEM_OPEN = re.compile(r'<li\b[^>]*class="[^"]*f1-podium--item[^"]*"[^>]*>', re.I)
_SE_HREF = re.compile(r'<a[^>]+href="([^"]+)"', re.I | re.S)
_SE_RANK = re.compile(r'f1-podium--rank[^>]*>([^<]+)</span>', re.I | re.S)
_SE_TEAMS = re.compile(r'd-md-inline[^>]*>\s*([^<]+?)\s*</span>', re.I | re.S)
_SE_TIME = re.compile(r'data[^>]*>([^<]*)', re.I | re.S)
_SE_MATCHUP = re.compile(r'\bvs\b|\bat\b|@', re.I)


def parse_streameast_schedule(html_text: str) -> List[Dict[str, str]]:
    """Parse a StreamEast schedule page into {href, league, teams, timestamp}."""
    starts = [m.start() for m in _SE_ITEM_OPEN.finditer(html_text or "")]
    entries: List[Dict[str, str]] = []
    for i, start in enumerate(starts):
        chunk = html_text[start:starts[i + 1] if i + 1 < len(starts) else len(html_text)]
        href = _SE_HREF.search(chunk)
        teams = _SE_TEAMS.search(chunk)
        # A podium item with no link or no teams span is not a game row - the pages carry
        # decorative ones. Skipping them here is what keeps the count honest.
        if not href or not teams:
            continue
        # A schedule page carries far more podium items than games: 39 vs 9 on mlbstreams
        # and 31 vs 1 on nflstreams, measured 2026-09-08. The surplus are single-team nav
        # links ("Ravens", "Dodgers"). They must not survive, because the resolver matches
        # on team names and a lone "Ravens" could be matched against "Ravens at Colts" and
        # resolve to a team hub page instead of the game. A real row names BOTH sides.
        if not _SE_MATCHUP.search(teams.group(1)):
            continue
        rank = _SE_RANK.search(chunk)
        stamp = _SE_TIME.search(chunk)
        is_live = bool(re.search(r'\bbtn-live\b|\bLIVE\b', chunk))
        entries.append({
            "provider": "SE",
            "href": href.group(1).strip(),
            "league": rank.group(1).strip() if rank else "",
            "teams": teams.group(1).strip(),
            "timestamp": stamp.group(1).strip() if stamp else ("Live Now" if is_live else ""),
            "is_live": is_live,
        })
    return entries


def parse_buffstreams_schedule(html_text: str) -> List[Dict[str, str]]:
    """Parse a BuffStreams schedule page into {href, league, teams, timestamp}."""
    matches = re.findall(
        r'(?s)<a[^>]+class="competition"[^>]+title="([^"]+)"[^>]+href="([^"]+)".*?'
        r'(?:<b>([^<]+)</b>|<time[^>]+datetime="([^"]+)"[^>]*>)',
        html_text,
    )
    entries = []
    for teams, href, live_status, dt_str in matches:
        title = teams.replace("Buffstreams ", "").strip()
        is_live = bool(live_status and "live" in live_status.lower())
        entries.append({
            "provider": "BS",
            "href": href.strip(),
            "league": "",
            "teams": title,
            "timestamp": (live_status or dt_str or "").strip(),
            "is_live": is_live,
        })
    return entries


# Per-provider health of the most recent `fetch_schedule` call. A side channel on
# purpose: `fetch_schedule` returns a flat list of entries and several callers depend on
# that exact shape, so the signature must not grow a second return value.
_LAST_SCHEDULE_HEALTH: Dict[str, Dict[str, Any]] = {}


def last_schedule_health() -> Dict[str, Dict[str, Any]]:
    """Health of each provider as of the last `fetch_schedule` call.

    Shape: {"SE": {"entries": int, "ok": bool, "base": str, "reason": str}, "BS": {...}}.
    `reason` is one of `ok`, `pointer_failed`, `fetch_failed`, `no_entries`, reported
    root-cause-first: a provider whose pointer never resolved reads `pointer_failed` even
    though the symptom further down was zero entries, because the pointer is the thing to
    go and fix. `ok` means only that this provider contributed entries.

    A copy, not the live dict, so a caller cannot mutate the record it is reading.
    """
    return {k: dict(v) for k, v in _LAST_SCHEDULE_HEALTH.items()}


def _log_host(url: str) -> str:
    """Host only, for logging. Mirrors `_stream_host` in the wizard's default.py: a full
    href or a resolved stream URL carries the scraped headers this repo treats as a
    credential, and these lines end up in kodi.log. `.hostname` rather than `.netloc` so
    any `user:pass@` userinfo is structurally impossible to leak.
    """
    try:
        return urlparse(url).hostname or "unknown-host"
    except Exception:
        return "unknown-host"


def fetch_schedule(sport: str, timeout: Union[int, float] = 10) -> List[Dict[str, str]]:
    """Fetch and parse both the SE and BS schedules for a sport.

    Returns schedule entries with an absolute `href` and the `slug` derived
    from it - computed here, once per entry, rather than on every comparison.
    Bases come from the pointer files, so domain rotation does not break
    discovery.

    A provider that is dead is recorded in `last_schedule_health()` and logged, never
    swallowed. The return type is unchanged - callers get the flat entry list, and one
    dead provider never costs them the other one's entries.
    """
    global _LAST_SCHEDULE_HEALTH
    cfg = SPORT_CONFIG.get(sport)
    if not cfg:
        _LAST_SCHEDULE_HEALTH = {}
        return []

    entries: List[Dict[str, str]] = []
    health: Dict[str, Dict[str, Any]] = {}

    for provider, pointer, default_base, slug_key, parser in (
        ("SE", SE_POINTER, SE_DEFAULT_BASE, "se", parse_streameast_schedule),
        ("BS", BS_POINTER, BS_DEFAULT_BASE, "bs", parse_buffstreams_schedule),
    ):
        base, from_pointer = resolve_provider_base_checked(pointer, default_base, timeout)
        page = _http_get_text(f"{base}/{cfg[slug_key]}", {"User-Agent": UA}, timeout)
        found = 0
        if page:
            for e in parser(page):
                e["href"] = urljoin(base + "/", e["href"])
                e["slug"] = slug_from_href(e["href"])
                entries.append(e)
                found += 1

        if not from_pointer:
            reason = "pointer_failed"
        elif not page:
            reason = "fetch_failed"
        elif found == 0:
            reason = "no_entries"
        else:
            reason = "ok"

        health[provider] = {
            "entries": found,
            "ok": found > 0,
            "base": base,
            "reason": reason,
        }
        if reason != "ok":
            print(f"[WARN] schedule provider {provider} degraded for {sport}: {reason} "
                  f"(host={_log_host(base)}, entries={found})", file=sys.stderr)

    _LAST_SCHEDULE_HEALTH = health
    return entries


# =============================================================================
# StreamEast / BuffStreams - resolution (Stage B)
# =============================================================================

IFRAME_VAR = {"SE": "wp_player", "BS": "cx-iframe"}


def split_piped(piped: str) -> Tuple[str, Dict[str, str]]:
    """Split a `url|Header=val&Header2=val2` string into (url, headers)."""
    if "|" not in piped:
        return piped, {}
    url, _, tail = piped.partition("|")
    headers: Dict[str, str] = {}
    for part in tail.split("&"):
        if "=" in part:
            k, v = part.split("=", 1)
            headers[k.strip()] = v.strip()
    return url, headers


def resolve_stage_b(href: str, timeout: Union[int, float] = 8, provider: str = "SE") -> Optional[str]:
    """Resolve one game page (href) to a playable piped URL, or None.

    Chooses the first server when several are offered (headless - no dialog),
    follows the JS iframe template (`wp_player` for SE, `cx-iframe` for BS),
    then extracts the source from either an `atob('...')` blob or a
    `const source = "..."` assignment (single or double quotes on both).
    """
    headers = {"User-Agent": UA, "Referer": href}
    page = _http_get_text(href, headers, timeout)
    if page is None:
        return None

    servers = re.findall(r'(?s)id="stream-btn-(\d+)"[^>]*>\s*([^<]+?)\s*</div>', page)
    var = IFRAME_VAR.get(provider, "wp_player")
    tmpl = re.search(
        r"document\.getElementById\('%s'\)\.src\s*=\s*'([^']+)'\s*\+\s*streamId(?:\s*\+\s*'([^']*)')?"
        % re.escape(var),
        page,
    )
    if servers and tmpl:
        stream_id = servers[0][0]
        prefix = tmpl.group(1)
        suffix = tmpl.group(2) or ""
        iframe_url = prefix + stream_id + suffix
    else:
        m = re.search(r'(?is)<iframe[^>]+src=["\']([^"\']+)', page)
        if not m:
            return None
        iframe_url = m.group(1)

    # Qualify the iframe URL: protocol-relative (//host/...) and root-relative
    # (/embed/...) srcs must be resolved against the page origin before fetch.
    if iframe_url.startswith("//"):
        iframe_url = "https:" + iframe_url
    elif iframe_url.startswith("/"):
        page_parsed = urlparse(href)
        iframe_url = f"{page_parsed.scheme}://{page_parsed.netloc}{iframe_url}"

    iframe_html = _http_get_text(iframe_url, {"User-Agent": UA, "Referer": href}, timeout)
    if iframe_html is None:
        return None

    parsed = urlparse(iframe_url)
    origin = f"{parsed.scheme}://{parsed.netloc}"
    referer = origin + "/"

    # Try atob first; if it is present but yields nothing usable, FALL THROUGH
    # to const source rather than failing (the string "atob" can appear in a
    # comment or dead branch while the real URL is a const source assignment).
    source = None
    m = re.search(r"""atob\(\s*['"]([^'"]+)""", iframe_html)
    if m:
        try:
            decoded = base64.b64decode(m.group(1)).decode("utf-8", "ignore").strip()
            if decoded:
                source = decoded
        except Exception:
            source = None
    if not source:
        m = re.search(r"""const\s+source\s*=\s*['"]([^'"]+)""", iframe_html)
        if m:
            source = m.group(1)
    if not source:
        return None

    return f"{source}|User-Agent={UA}&Referer={referer}&Origin={origin}"


# =============================================================================
# Decoupled orchestration
# =============================================================================

def run_decoupled_audit(
    sport: str,
    workers: int = 10,
    probe_timeout: int = 6,
    fetch_timeout: int = 10,
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], List[Dict[str, Any]], Dict[str, Any]]:
    """ESPN discovery + SE/BS resolution for one sport.

    Returns (cards, resolved_records, live_games, stats).
    """
    label = SPORT_CONFIG.get(sport, {}).get("label", sport.upper())

    scoreboard = fetch_espn_scoreboard(sport, timeout=fetch_timeout)
    all_games = parse_espn_events(scoreboard)
    live = espn_live_games(all_games)

    schedule = fetch_schedule(sport, timeout=fetch_timeout)

    # Match each live game to every schedule entry that names both teams - by
    # the entry's href slug where it has one, by its display title where it
    # does not.
    match_jobs: List[Tuple[Dict[str, Any], Dict[str, str]]] = []
    for game in live:
        for entry in schedule:
            if entry_matches_game(entry, game):
                match_jobs.append((game, entry))

    def _resolve_one(job: Tuple[Dict[str, Any], Dict[str, str]]) -> Optional[Dict[str, Any]]:
        game, entry = job
        piped = resolve_stage_b(entry["href"], timeout=probe_timeout, provider=entry["provider"])
        if not piped:
            return None
        base_url, hdrs = split_piped(piped)
        alive, max_h, reason, variants = stream_qc.probe_hls_stream(
            base_url,
            user_agent=hdrs.get("User-Agent", UA),
            headers=hdrs,
            timeout=probe_timeout,
        )
        return {
            "sport": label,
            "title": game["name"],
            "stream_url": piped,
            "alive": alive,
            "max_resolution": max_h,
            "status": reason,
            "variants": [f"{w}x{h}" for w, h in variants],
            "page_url": entry["href"],
            "provider": entry["provider"],
            "ua": hdrs.get("User-Agent", UA),
            "referer": hdrs.get("Referer", ""),
            "origin": hdrs.get("Origin", ""),
        }

    resolved_records: List[Dict[str, Any]] = []
    if match_jobs:
        try:
            import concurrent.futures
            has_concurrent = True
        except ImportError:
            has_concurrent = False

        if has_concurrent and workers > 1:
            with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
                for rec in executor.map(_resolve_one, match_jobs):
                    if rec is not None:
                        resolved_records.append(rec)
        else:
            for job in match_jobs:
                rec = _resolve_one(job)
                if rec is not None:
                    resolved_records.append(rec)

    active = [r for r in resolved_records if r.get("alive") and r.get("stream_url")]
    cards = build_decoupled_cards(live, active, label)

    stats = {
        "sport": label,
        "espn_events_total": len(all_games),
        "espn_live_games": len(live),
        "schedule_entries": len(schedule),
        "match_jobs": len(match_jobs),
        "resolved_streams": len(active),
        "canonical_cards": len(cards),
        "cards_with_stream": sum(1 for c in cards if c.get("primary_stream")),
        "cards_no_stream": sum(1 for c in cards if not c.get("primary_stream")),
        "resolution_breakdown": {
            "1080p": sum(1 for r in active if r.get("max_resolution") and r["max_resolution"] >= 1080),
            "720p": sum(1 for r in active if r.get("max_resolution") and 720 <= r["max_resolution"] < 1080),
            "sub_720p": sum(1 for r in active if r.get("max_resolution") and r["max_resolution"] < 720),
        },
        "scraped_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    return cards, active, live, stats


def _card_id(sport: str, title: str) -> str:
    clean_slug = re.sub(r"[^a-zA-Z0-9_]", "", title.lower().replace(" ", "_"))
    return f"sw_sports_{sport.lower()}_{clean_slug[:48]}"


def build_decoupled_cards(
    live_games: List[Dict[str, Any]],
    active_records: List[Dict[str, Any]],
    sport_label: str,
) -> List[Dict[str, Any]]:
    """Build 1-game-1-card list, appending a no-stream card for every live ESPN
    game that no schedule entry resolved. Visibility over silence."""
    cards = build_canonical_sports_cards(active_records)
    matched_titles = {c["title"] for c in cards}

    for game in live_games:
        title = game.get("name", "").strip()
        if not title or title in matched_titles:
            continue
        cards.append({
            "id": _card_id(sport_label, title),
            "sport": sport_label.upper(),
            "title": title,
            "card_label": f"[{sport_label.upper()}] {title}",
            "primary_stream": None,
            "backup_stream": None,
            "resolution": None,
            "status": "live, no stream resolved",
            "variants": [],
            "icon": get_sport_icon(sport_label),
            "stream_count": 0,
            "page_url": "",
            "ua": None,
            "referer": None,
            "origin": None,
        })
        matched_titles.add(title)

    cards.sort(key=lambda c: (c["sport"], c["title"]))
    return cards


# =============================================================================
# Legacy RoxieStreams harvest (--source roxie only)
# =============================================================================

def get_base_url(timeout: int = 8) -> str:
    """Fetch current dynamic base URL for RoxieStreams."""
    try:
        req = urllib.request.Request(ROXIE_BASE_INDEX, headers={"User-Agent": UA})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            content = resp.read().decode("utf-8").strip().strip('"\n\r')
            if content.startswith("http"):
                return content
    except Exception:
        pass
    return DEFAULT_ROXIE_BASE


def harvest_scheduled_events(base_url: str, sports: Optional[List[str]] = None, timeout: int = 10) -> List[Dict[str, Any]]:
    """Harvest scheduled live match events across selected sports leagues."""
    target_sports = sports or ["mlb", "soccer", "fighting", "nba", "nfl", "motorsports", "nhl"]
    events: List[Dict[str, Any]] = []

    for s in target_sports:
        url = f"{base_url}/{s}"
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                html = resp.read().decode("utf-8", errors="ignore")
            matches = re.findall(r'<a[^>]+href=[\"\'](/[^\"\']+)[\"\'][^>]*>(.*?)</a>', html, re.S)
            for href, text in matches:
                clean_text = re.sub(r"<[^>]+>", " ", text).strip()
                if any(k in href for k in ["streams", "watch", "live", "game", "fight"]) and len(clean_text) > 3:
                    full_href = urljoin(base_url, href)
                    events.append({
                        "sport": s.upper(),
                        "title": clean_text,
                        "page_url": full_href,
                    })
        except Exception as e:
            print(f"[WARN] Error fetching {s} from {url}: {e}", file=sys.stderr)

    seen = set()
    unique = []
    for ev in events:
        if ev["page_url"] not in seen:
            seen.add(ev["page_url"])
            unique.append(ev)
    return unique


def resolve_event_streams(page_url: str, timeout: int = 8) -> List[str]:
    """Resolve raw HLS master stream URLs from event landing page."""
    origin = f"{urlparse(page_url).scheme}://{urlparse(page_url).netloc}"
    referer = origin + "/"
    headers = {"User-Agent": UA, "Referer": referer}
    try:
        req = urllib.request.Request(page_url, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            page_data = resp.read().decode("utf-8", errors="ignore")
    except Exception:
        return []

    m3u8_list = []
    if "getRandomStream" in page_data:
        stream_calls = set(re.findall(r"getRandomStream\(\s*'([^']+)'\s*,\s*'([^']+)'\s*\)", page_data))
        fetch_m = re.search(r"fetch\('([^']+)", page_data)
        domains = ["shadow-ran.online"]
        if fetch_m:
            try:
                domain_url = urljoin(origin, fetch_m.group(1))
                d_req = urllib.request.Request(domain_url, headers=headers)
                with urllib.request.urlopen(d_req, timeout=4) as d_resp:
                    d_text = d_resp.read().decode("utf-8", errors="ignore")
                    fetched = [d.strip() for d in d_text.splitlines() if d.strip()]
                    if fetched:
                        domains = fetched
            except Exception:
                pass
        for stream_path, subdomain in stream_calls:
            d = random.choice(domains)
            m3u8_list.append(f"https://{subdomain}.{d}/{stream_path}")

    clappr = re.findall(r"showPlayer\([^,]+,\s*['\"]([^'\"]+\.m3u8)", page_data)
    if clappr:
        m3u8_list.extend(clappr)

    if not m3u8_list:
        m3u8_list = re.findall(r"https?://[^\s\'\"<>]+\.m3u8", page_data)

    return list(dict.fromkeys(m3u8_list))


def run_live_sports_audit(
    events: List[Dict[str, Any]],
    workers: int = 10,
    probe_timeout: int = 6,
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], Dict[str, Any]]:
    """Audit all harvested match events concurrently (legacy roxie path)."""
    probe_headers = {"Referer": "https://roxiestreams.su/", "Origin": "https://roxiestreams.su", "User-Agent": UA}
    active_records = []
    inactive_records = []

    def _process_event(ev: Dict[str, Any]) -> List[Dict[str, Any]]:
        streams = resolve_event_streams(ev["page_url"])
        if not streams:
            return [{
                **ev,
                "stream_url": None,
                "alive": False,
                "max_resolution": None,
                "status": "No active stream endpoint on match page (pre-match / offline)",
                "variants": [],
            }]
        records = []
        for s_url in streams:
            alive, max_h, reason, variants = stream_qc.probe_hls_stream(
                s_url,
                user_agent=UA,
                headers=probe_headers,
                timeout=probe_timeout,
            )
            records.append({
                **ev,
                "stream_url": s_url,
                "alive": alive,
                "max_resolution": max_h,
                "status": reason,
                "variants": [f"{w}x{h}" for w, h in variants],
            })
        return records

    all_records = []
    try:
        import concurrent.futures
        has_concurrent = True
    except ImportError:
        has_concurrent = False

    if has_concurrent and workers > 1:
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
            futures = [executor.submit(_process_event, ev) for ev in events]
            for f in concurrent.futures.as_completed(futures):
                all_records.extend(f.result())
    else:
        for ev in events:
            all_records.extend(_process_event(ev))

    for r in all_records:
        if r["alive"]:
            active_records.append(r)
        else:
            inactive_records.append(r)

    stats = {
        "total_events": len(events),
        "total_targets_probed": len(all_records),
        "active_live_streams": len(active_records),
        "inactive_events": len(inactive_records),
        "resolution_breakdown": {
            "1080p": sum(1 for r in active_records if r.get("max_resolution") and r["max_resolution"] >= 1080),
            "720p": sum(1 for r in active_records if r.get("max_resolution") and 720 <= r["max_resolution"] < 1080),
            "sub_720p": sum(1 for r in active_records if r.get("max_resolution") and r["max_resolution"] < 720),
        },
        "scraped_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }

    return active_records, inactive_records, stats


# =============================================================================
# Shared card + M3U builders (output contract)
# =============================================================================

def build_canonical_sports_cards(active_records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Build StarWave Canonical Sports Game Cards (1 Game = 1 Card).
    Groups streams per game fixture, ranks by resolution (1080p > 720p),
    and caches 1 primary stream + 1 backup link.
    """
    games_map: Dict[Tuple[str, str], List[Dict[str, Any]]] = {}

    for r in active_records:
        if not r.get("alive") or not r.get("stream_url"):
            continue
        key = (r["sport"].upper(), r["title"].strip())
        if key not in games_map:
            games_map[key] = []
        games_map[key].append(r)

    cards = []
    for (sport, title), streams in games_map.items():
        # Sort streams by resolution descending: 1080p first, then 720p
        streams.sort(
            key=lambda s: (
                s.get("max_resolution") or 0,
                1 if s.get("status") == "OK" else 0
            ),
            reverse=True
        )

        primary = streams[0]
        backup = streams[1] if len(streams) > 1 else None

        clean_slug = re.sub(r"[^a-zA-Z0-9_]", "", title.lower().replace(" ", "_"))
        game_id = f"sw_sports_{sport.lower()}_{clean_slug[:48]}"
        res_val = primary.get("max_resolution") or 720
        res_label = f"{res_val}p"

        cards.append({
            "id": game_id,
            "sport": sport,
            "title": title,
            "card_label": f"[{sport}] {title}",
            "primary_stream": primary["stream_url"],
            "backup_stream": backup["stream_url"] if backup else None,
            "resolution": res_label,
            "status": primary.get("status", "Verified Live"),
            "variants": primary.get("variants", []),
            "icon": get_sport_icon(sport),
            "stream_count": len(streams),
            "page_url": primary.get("page_url", ""),
            "ua": primary.get("ua"),
            "referer": primary.get("referer"),
            "origin": primary.get("origin"),
        })

    cards.sort(key=lambda c: (c["sport"], c["title"]))
    return cards


def generate_canonical_sports_m3u(canonical_cards: List[Dict[str, Any]], title: str = "StarWave Canonical Sports") -> str:
    """Generate clean M3U8 playlist for Canonical Sports Hub.

    No-stream cards (a live game with no resolved playlist) are skipped - a
    playlist entry with no URL is invalid. Headers are specified ONCE, in
    KODIPROP (User-Agent + Referer + Origin), and the manifest line carries the
    CLEAN base URL with the `|Header=...` pipe suffix stripped, so the pipe and
    the KODIPROP header set agree instead of double-specifying. Per-card
    UA/Referer/Origin are used when present, else the legacy roxie defaults.
    """
    lines = [f'#EXTM3U name="{title}"']

    idx = 0
    for card in canonical_cards:
        if not card.get("primary_stream"):
            continue
        idx += 1
        chno = 9100 + idx
        sport = card["sport"]
        name = card["title"]
        logo = card["icon"]
        cid = card["id"]
        group = f"Live Sports ({sport})"
        ua = card.get("ua") or UA
        referer = card.get("referer") or "https://roxiestreams.su/"
        origin = card.get("origin") or referer.rstrip("/")
        # Manifest line must be a clean URL; drop any piped header suffix.
        manifest_url = card["primary_stream"].split("|", 1)[0]

        lines.append(f'#EXTINF:-1 tvg-id="{cid}" tvg-name="{name}" tvg-chno="{chno}" tvg-logo="{logo}" group-title="{group}",[{sport}] {name} ({card["resolution"]})')
        lines.append(f"#EXTVLCOPT:http-user-agent={ua}")
        lines.append(f'#EXTVLCOPT:http-referrer={referer}')
        lines.append('#KODIPROP:inputstream.adaptive.manifest_type=hls')
        lines.append(f'#KODIPROP:inputstream.adaptive.stream_headers=User-Agent={ua}&Referer={referer}&Origin={origin}')
        if card.get("backup_stream"):
            lines.append(f'#EXT-X-BACKUP-URL:{card["backup_stream"].split("|", 1)[0]}')
        lines.append(manifest_url)

    return "\n".join(lines) + "\n"


# =============================================================================
# CLI
# =============================================================================

def _run_espn(args) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], List[Dict[str, Any]], Dict[str, Any]]:
    sports = list(SPORT_CONFIG.keys()) if args.sport == "all" else [args.sport]
    all_cards: List[Dict[str, Any]] = []
    all_active: List[Dict[str, Any]] = []
    all_live: List[Dict[str, Any]] = []
    per_sport_stats: List[Dict[str, Any]] = []
    for sp in sports:
        cards, active, live, stats = run_decoupled_audit(
            sp, workers=args.workers, probe_timeout=args.timeout
        )
        all_cards.extend(cards)
        all_active.extend(active)
        all_live.extend(live)
        per_sport_stats.append(stats)
        print(f"[{stats['sport']}] live={stats['espn_live_games']} "
              f"schedule={stats['schedule_entries']} resolved={stats['resolved_streams']} "
              f"cards={stats['canonical_cards']} (no-stream={stats['cards_no_stream']})")
    agg = {
        "source": "espn+se+bs",
        "sports": [s["sport"] for s in per_sport_stats],
        "espn_live_games": sum(s["espn_live_games"] for s in per_sport_stats),
        "resolved_streams": sum(s["resolved_streams"] for s in per_sport_stats),
        "canonical_cards": len(all_cards),
        "cards_no_stream": sum(1 for c in all_cards if not c.get("primary_stream")),
        "per_sport": per_sport_stats,
        "scraped_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    all_cards.sort(key=lambda c: (c["sport"], c["title"]))
    return all_cards, all_active, all_live, agg


def main():
    parser = argparse.ArgumentParser(description="StarWave Canonical Sports Engine & QC Auditor")
    parser.add_argument("--source", choices=["espn", "roxie"], default="espn",
                        help="Discovery source: espn (default, ESPN+SE+BS) or roxie (legacy)")
    parser.add_argument("--sport", choices=list(SPORT_CONFIG.keys()) + ["all"], default="mlb",
                        help="Sport to probe (ESPN source only; default: mlb)")
    parser.add_argument("--workers", type=int, default=12, help="Concurrent worker threads (default: 12)")
    parser.add_argument("--timeout", type=int, default=6, help="Stream probe timeout in seconds (default: 6)")
    parser.add_argument("--output-json", default="docs/iptv/canonical_sports.json", help="Path to write canonical sports JSON")
    parser.add_argument("--output-m3u", default="docs/iptv/crew_sports.m3u8", help="Path to write canonical sports M3U8")
    parser.add_argument("--output-qc", default="docs/iptv/live_events_qc.json", help="Path to write QC JSON audit")
    args = parser.parse_args()

    start_t = time.time()

    if args.source == "roxie":
        base_url = get_base_url()
        print(f"=== Scraping StarWave Live Sports Events from {base_url} (legacy roxie) ===")
        events = harvest_scheduled_events(base_url)
        print(f"Harvested {len(events)} scheduled match fixtures.")
        active, inactive, stats = run_live_sports_audit(events, workers=args.workers, probe_timeout=args.timeout)
        canonical_cards = build_canonical_sports_cards(active)
        stats["total_canonical_games"] = len(canonical_cards)
    else:
        print(f"=== ESPN discovery + StreamEast/BuffStreams resolution (sport={args.sport}) ===")
        canonical_cards, active, live, stats = _run_espn(args)
        inactive = []

    elapsed = round(time.time() - start_t, 2)
    stats["elapsed_seconds"] = elapsed

    print(f"\n--- Live Event Audit Summary ({elapsed}s) ---")
    print(f"Canonical Game Cards:   {len(canonical_cards)} (1 Game = 1 Card)")

    if canonical_cards:
        print("\n--- CANONICAL GAME CARDS (1 GAME = 1 CARD) ---")
        for c in canonical_cards:
            if c.get("primary_stream"):
                backup_note = " [1 Backup link cached]" if c.get("backup_stream") else ""
                print(f"  ✓ [{c['sport']}] {c['title']} -> {c['resolution']} ({c['status']}){backup_note}")
                print(f"    Primary: {c['primary_stream']}")
                if c.get("backup_stream"):
                    print(f"    Backup:  {c['backup_stream']}")
            else:
                print(f"  ⊙ [{c['sport']}] {c['title']} -> {c['status']}")

    os.makedirs(os.path.dirname(args.output_qc), exist_ok=True)
    with open(args.output_qc, "w", encoding="utf-8") as f:
        json.dump({
            "stats": stats,
            "active_streams": active,
            "inactive_events": inactive,
        }, f, indent=2)
    print(f"\nWrote full live event report to: {args.output_qc}")

    with open(args.output_json, "w", encoding="utf-8") as f:
        json.dump({
            "generated_at": stats["scraped_at"],
            "total_games": len(canonical_cards),
            "stats": stats,
            "games": canonical_cards,
        }, f, indent=2)
    print(f"Wrote canonical sports dataset to: {args.output_json}")

    m3u_content = generate_canonical_sports_m3u(canonical_cards)
    with open(args.output_m3u, "w", encoding="utf-8") as f:
        f.write(m3u_content)
    print(f"Wrote canonical sports M3U playlist to: {args.output_m3u}")


if __name__ == "__main__":
    main()
