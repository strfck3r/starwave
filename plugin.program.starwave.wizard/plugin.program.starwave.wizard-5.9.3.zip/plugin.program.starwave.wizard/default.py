# -*- coding: utf-8 -*-
"""StarWave Wizard -  installs builds and switches layouts on this Kodi."""

import os
import re
import sys
import json
import shutil
import time
import io
import gzip
import sqlite3
import pathlib
import tempfile
import importlib.util
import xml.etree.ElementTree as ET
from urllib.parse import urlencode, parse_qsl, quote, urlparse
from urllib.request import Request, urlopen, build_opener, HTTPRedirectHandler
from urllib.error import HTTPError

import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon('plugin.program.starwave.wizard')
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ICON = ADDON.getAddonInfo('icon')
VERSION = ADDON.getAddonInfo('version')
KODI_AVAILABLE = True
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1

BASE_URL = 'https://strfck3r.github.io/starwave/'
MANIFEST_URL = BASE_URL + 'builds.json'

# --- personal builds ------------------------------------------------------------------
# A personal build is this device packaged with its logins intact, kept as a release asset
# in the *private* repository. Kodi cannot authenticate, so the public manifest above can
# never carry one; the wizard talks to the GitHub API directly with a token the owner enters
# on each device. Nothing here works, or is offered, without that token.
GITHUB_API = 'https://api.github.com'
GITHUB_UPLOADS = 'https://uploads.github.com'
GITHUB_CLIENT_ID = 'Ov23liNLjh6VqGHab0XU'
DEFAULT_REPO = 'strfck3r/starwave-personal'
BUILDS_REPO = 'strfck3r/starwave-builds'
# Personal builds are found by tag rather than listed anywhere, so publishing one needs no
# manifest edit and leaks nothing into the public repository.
PERSONAL_TAG = 'personal-'

# Used when the manifest cannot be fetched, so a broken or missing manifest never leaves
# someone with no way to install. 'latest' resolves to the newest release carrying the asset.
FALLBACK_BUILD = {
    'id': 'starwave',
    'name': 'StarWave',
    'url': 'https://github.com/strfck3r/starwave/releases/latest/download/StarWave-V1-kodi.zip',
    'repo': BUILDS_REPO,
    'tag': 'v4',
    'description': 'The StarWave build: skin, home menu, widgets and add-ons.',
}

HOME = xbmcvfs.translatePath('special://home/')
PACKAGES = os.path.join(HOME, 'addons', 'packages')
TEMP_DIR = xbmcvfs.translatePath('special://temp/')
TEMP_ZIP = os.path.join(TEMP_DIR, 'starwave-build.zip')
GUISETTINGS = os.path.join(HOME, 'userdata', 'guisettings.xml')
ADDONS_DB = os.path.join(HOME, 'userdata', 'Database', 'Addons33.db')

# The build is assembled on an NVIDIA Shield, so these two ship as android-aarch64 binaries.
# They cannot load anywhere else, and installing them would replace whatever the host Kodi
# already has. Everything else in the build is Python, skin XML or images and is portable.
ANDROID_ONLY = ('inputstream.adaptive', 'vfs.libarchive')

# Add-ons we update ourselves because Kodi demonstrably will not. Deliberately short:
# these are the ones whose staleness actually breaks playback.
SELF_UPDATE = (
    'plugin.video.umbrella',
    'plugin.video.thecrew',
    'plugin.video.seren',
    'plugin.video.gears',
    'script.module.cocoscrapers',
    'script.module.resolveurl',
)

# Update mode leaves these alone when they already exist on the device. They hold the user's
# own state -  Kodi's system/player/media/skin settings and their sources, favourites, logins
# and profiles -  none of which an update should reset.
USER_FILES = (
    'userdata/guisettings.xml',
    'userdata/sources.xml',
    'userdata/favourites.xml',
    'userdata/passwords.xml',
    'userdata/profiles.xml',
)

# The add-on database is never extracted in update mode: the device's copy also registers
# add-ons the user installed themselves, which the build's copy knows nothing about. New
# build add-ons are merged into it instead (see merge_installed).
ADDONS_DB_MEMBER = 'userdata/Database/Addons33.db'

# Settings that describe one machine rather than one build: the audio chain, the display,
# and this device's identity. Deliberately the same list scripts/capture-build.py strips for
# a clean build, so a capture and an on-device reset can never disagree.
DEVICE_PREFIXES = ('audiooutput.',)
DEVICE_EXACT = {
    'videoscreen.resolution', 'pictures.displayresolution',
    'videoplayer.adjustrefreshrate', 'videoplayer.usemediacodecsurface',
    'window.width', 'window.height', 'services.deviceuuid',
}

# --- capture -------------------------------------------------------------------------
# Everything below mirrors scripts/capture-build.py, which does the same job from a Mac over
# adb. Running it here needs no adb at all, which is the point: a Steam Deck or a relative's
# box can package itself.
CAPTURE_EXCLUDE_DIRS = (
    'temp',
    'userdata/Thumbnails',
    'addons/packages',
    'userdata/addon_data/script.module.autocompletion',   # cached *search queries*
    'userdata/addon_data/plugin.program.starwave.wizard',  # this device's GitHub token
    'userdata/addon_data/plugin.video.themoviedb.helper/blur_v3',
    'userdata/addon_data/plugin.video.themoviedb.helper/crop_v2',
    'userdata/addon_data/plugin.video.themoviedb.helper/pickle',
    'userdata/addon_data/plugin.video.themoviedb.helper/qrcode',
    'userdata/addon_data/plugin.video.themoviedb.helper/log_tagger',
    'userdata/addon_data/plugin.video.themoviedb.helper/database_07',
    'userdata/addon_data/plugin.video.themoviedb.helper/database',
    'userdata/addon_data/plugin.video.themoviedb.helper/cache',
    'userdata/addon_data/plugin.video.youtube/1c991a64b8fb40a79256738381405f22',
    'userdata/addon_data/plugin.video.youtube/25117b8458454216a73b6ac2247dbf28',
)
CAPTURE_EXCLUDE_FILES = ('userdata/Database/Textures13.db',)
# Cache stores under addon_data hold whatever the add-on fetched while signed in. The YouTube
# add-on's requests_cache.sqlite was found carrying the owner's account name in a published
# build - same class as the Google API key that leaked out of autocompletion's cached search
# queries. Excluded by NAME rather than by add-on, so a new add-on with a cache is covered
# without anyone remembering to add it.
# Also excludes orphan temp files from interrupted atomic writes (*.starwave-tmp) so crashes
# between mkstemp and rename never leak incomplete or stale temp files into captured builds.
CAPTURE_EXCLUDE_CACHE = (
    'cache.sqlite', 'data_cache.sqlite', 'requests_cache.sqlite',
    'cache.db', 'requests_cache.db', 'traktSync.db', 'traktsync.db',
    'traktcache.db', 'watched.db', 'bookmarks.db', 'history.sqlite',
    'watch_later.sqlite', 'bookmarks.sqlite', 'feeds.sqlite', 'search.sqlite',
    'search.db', 'favourites.db', 'personal_lists.db', 'random_widgets.db',
    'navigator.db', 'mdblist.db', 'simkl.db', 'metacache.db', 'maincache.db',
    'debridcache.db', 'torrentCache.db', 'torentAssist.db', 'premiumize.db',
    'ItemQueries.db', 'ItemDetails.db', 'ItemContainer.db', 'SearchHistory.db',
    'malSync.db', 'simKLSync.db', 'library.db', 'tvevening_playlist.db',
    'favorites.db',
    '*.starwave-tmp',
)
CAPTURE_EXCLUDE_SUFFIX = ('.log', '.pyc', '.bak', '.xml.old', '.DS_Store', '_qr.png', '.db.md5', '.starwave-tmp')
CAPTURE_EXCLUDE_NAME = ('__pycache__',)

# Credential-shaped setting ids. A published build is world-readable, so these never travel.
CRED_RE = re.compile(r'(token|secret|client[._]?id|password|api[._]?key|refresh|account[._]?id|'
                     r'user(name)?|auth|session|cookie|premiumize|realdebrid|real_debrid|'
                     r'alldebrid|offcloud|torbox|easydebrid|trakt|simkl)', re.I)
CRED_KEEP = {'true', 'false', '', '0', '1', 'none', 'empty_setting', 'default'}
GEARS_DB_REL = 'userdata/addon_data/plugin.video.gears/databases/settings.db'
GEARS_CREDS = ('rd.client_id', 'rd.secret', 'rd.token', 'rd.refresh', 'rd.account_id',
               'rd.enabled', 'pm.token', 'pm.account_id', 'pm.enabled', 'ad.token',
               'oc.token', 'ed.token', 'tb.token', 'trakt.token', 'simkl.token', 'tmdb.token')

# Layouts are skins plus their menu/widget configuration. They are deliberately independent
# of builds: no Kodi setting, add-on setting or saved login lives in either skin's data, so
# switching between them never disturbs credentials or preferences.
FALLBACK_LAYOUTS = [
    {
        'id': 'arcticfuse',
        'name': 'Arctic Fuse',
        'skin': 'skin.arctic.fuse.3',
        'config': BASE_URL + 'layouts/arctic-fuse-config.zip',
        'description': 'Arctic Fuse 3, configured against your Trakt lists and add-ons.',
    },
    {
        'id': 'starwave',
        'name': 'StarWave',
        'skin': 'skin.NTVaura',
        'description': 'The original StarWave layout.',
    },
]


def is_android():
    return xbmc.getCondVisibility('System.Platform.Android')


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), level)


def notify(msg, ms=4000):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, ICON, ms)


def build_url(**kwargs):
    return '%s?%s' % (sys.argv[0], urlencode(kwargs))


def _atomic_write_text(path, text):
    """Atomically write text (utf-8) to path via a temp file and rename.

    Writing settings files directly with open(path, 'w') truncates the target
    immediately. If a power loss or full disk occurs during that window, an
    empty or partial file remains, and nothing ever re-seeds an existing file.
    The device would then lose its Live TV guide configuration permanently
    and silently.

    This helper writes to a temporary file in the same directory, flushes,
    fsyncs, closes it, preserves existing target file permissions, and then
    atomically replaces the destination file using os.replace.
    Runs on Python 3.11 on device.
    """
    target_exists = os.path.exists(path)
    target_mode = None
    if target_exists:
        with open(path, 'r+', encoding='utf-8'):
            pass
        try:
            target_mode = os.stat(path).st_mode
        except OSError:
            target_mode = None

    parent_dir = os.path.dirname(path) or '.'
    fd, tmp = tempfile.mkstemp(
        dir=parent_dir,
        prefix=os.path.basename(path) + '.',
        suffix='.starwave-tmp',
    )
    try:
        try:
            f = os.fdopen(fd, 'w', encoding='utf-8')
        except Exception:
            try:
                os.close(fd)
            except OSError:
                pass
            raise

        with f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())

        if target_exists:
            if target_mode is not None:
                try:
                    os.chmod(tmp, target_mode & 0o7777)
                except OSError:
                    pass
        else:
            umask = 0o022
            try:
                with open('/proc/self/status', 'r', encoding='utf-8') as sf:
                    for line in sf:
                        if line.startswith('Umask:'):
                            parts = line.split(':', 1)
                            if len(parts) > 1:
                                umask = int(parts[1].strip(), 8)
                            break
            except Exception:
                umask = 0o022
            try:
                os.chmod(tmp, 0o666 & ~umask)
            except OSError:
                pass

        os.replace(tmp, path)

        try:
            dfd = os.open(parent_dir, os.O_RDONLY)
            try:
                os.fsync(dfd)
            finally:
                os.close(dfd)
        except OSError:
            pass
    except Exception:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass
        raise



def add_item(label, description, folder=False, **params):
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': ICON, 'thumb': ICON})
    li.setInfo('video', {'title': label, 'plot': description})
    xbmcplugin.addDirectoryItem(HANDLE, build_url(**params), li, folder)


def fetch(url, timeout=20):
    req = Request(url, headers={'User-Agent': 'StarWave-Wizard'})
    return urlopen(req, timeout=timeout).read()


def get_manifest():
    """Builds and layouts, published alongside the repository.

    Keeping this in a manifest means a new build or layout needs only a new file and a
    manifest line -  no wizard update on any device.
    """
    try:
        data = json.loads(fetch(MANIFEST_URL).decode('utf-8'))
        builds = [b for b in data.get('builds', [])
                  if b.get('name') and (b.get('url') or (b.get('repo') and b.get('tag')))]
        layouts = [l for l in data.get('layouts', []) if l.get('skin') and l.get('name')]
        return (builds or [FALLBACK_BUILD]), (layouts or FALLBACK_LAYOUTS)
    except Exception as exc:  # noqa: BLE001
        log('could not read the build manifest (%s); using built-in defaults' % exc,
            xbmc.LOGWARNING)
        return [FALLBACK_BUILD], FALLBACK_LAYOUTS


# ------------------------------------------------------------------- personal builds


def setting(key, default=''):
    """Read a wizard setting. Deliberately a fresh Addon() every time -  the module-level
    ADDON caches values from when the plugin started, so a token entered a moment ago in the
    settings dialog would not be seen."""
    try:
        return xbmcaddon.Addon().getSetting(key).strip() or default
    except Exception:  # noqa: BLE001
        return default


def gh_token():
    return setting('gh_token')


# Personal builds used to share the public repo; they now live in their own always-private one
# so opening the public repo for add-on updates can never expose them. A device that still has
# the old public repo saved would look for personal builds where there are none, so migrate it.
OLD_PUBLIC_REPO = 'strfck3r/starwave'


def gh_repo():
    repo = setting('gh_repo', DEFAULT_REPO).strip('/')
    return DEFAULT_REPO if repo == OLD_PUBLIC_REPO else repo


class _NoRedirect(HTTPRedirectHandler):
    """Hand a redirect response back instead of following it.

    GitHub answers an authenticated asset download with a 302 to a signed S3 URL. urllib
    would follow it with our Authorization header still attached, and S3 rejects a request
    carrying two auth mechanisms outright. We follow it ourselves, without the header.
    """

    def http_error_302(self, req, fp, code, msg, headers):
        return fp

    http_error_301 = http_error_303 = http_error_307 = http_error_308 = http_error_302


def _gh_error(exc):
    """GitHub's own message, translated into something worth showing a person."""
    try:
        detail = json.loads(exc.read().decode('utf-8')).get('message', '')
    except Exception:  # noqa: BLE001
        detail = ''
    if exc.code == 401:
        return ('GitHub rejected the token (401). It has probably expired -  fine-grained '
                'tokens are issued for a fixed period -  or it was pasted incompletely.')
    if exc.code == 403:
        return ('GitHub refused the request (403). The token needs "Contents: Read and '
                'write" on this repository. %s' % detail).strip()
    if exc.code == 404:
        return ('Not found (404). Either the repository name is wrong, or the token was not '
                'granted access to it -  a fine-grained token cannot see repositories it was '
                'not selected for, and GitHub reports that as 404 rather than 403.')
    return ('GitHub returned %s %s. %s' % (exc.code, exc.reason, detail)).strip()


def _gh_request(url, token, accept, data=None, content_type=None, method=None):
    req = Request(url, data=data, method=method)
    req.add_header('Authorization', 'Bearer %s' % token)
    req.add_header('Accept', accept)
    req.add_header('X-GitHub-Api-Version', '2022-11-28')
    req.add_header('User-Agent', 'StarWave-Wizard')
    if content_type:
        req.add_header('Content-Type', content_type)
    return req


def gh_json(path, token, data=None, method=None, timeout=30):
    """Call the GitHub REST API. Returns the decoded body, or None for 404.

    404 is a normal answer here -  it is how "no release with that tag yet" arrives -  so it
    is not raised. Everything else that fails raises IOError with a readable message.
    """
    url = path if path.startswith('http') else GITHUB_API + path
    body = json.dumps(data).encode('utf-8') if data is not None else None
    req = _gh_request(url, token, 'application/vnd.github+json', body,
                      'application/json' if body else None, method)
    try:
        resp = urlopen(req, timeout=timeout)
        raw = resp.read()
    except HTTPError as exc:
        if exc.code == 404:
            return None
        raise IOError(_gh_error(exc))
    return json.loads(raw.decode('utf-8')) if raw else {}


def gh_asset_response(url, token):
    """Open a release asset in the private repo, following the signed redirect by hand."""
    resp = build_opener(_NoRedirect).open(
        _gh_request(url, token, 'application/octet-stream'), timeout=30)
    code = getattr(resp, 'status', None) or resp.getcode()
    if code in (301, 302, 303, 307, 308):
        location = resp.getheader('Location')
        resp.close()
        if not location:
            raise IOError('GitHub redirected the download without saying where to')
        resp = urlopen(Request(location, headers={'User-Agent': 'StarWave-Wizard'}),
                       timeout=30)
    elif code >= 400:
        raise IOError('GitHub returned %s for the build download' % code)
    return resp


def personal_builds():
    """Builds in the private repo this token can see. Never raises -  a dead token or no
    network must not stop the public builds from being installable."""
    token = gh_token()
    if not token:
        return []
    try:
        releases = gh_json('/repos/%s/releases?per_page=100' % gh_repo(), token) or []
    except Exception as exc:  # noqa: BLE001
        log('could not list personal builds: %s' % exc, xbmc.LOGWARNING)
        return []

    out = []
    for rel in releases:
        tag = rel.get('tag_name', '')
        if not tag.startswith(PERSONAL_TAG):
            continue
        asset = next((a for a in rel.get('assets', ()) if a.get('name', '').endswith('.zip')),
                     None)
        if not asset:
            continue
        out.append({
            'id': tag,
            'name': rel.get('name') or tag[len(PERSONAL_TAG):].upper(),
            'url': asset['url'],          # API url, not browser_download_url: needs the token
            'personal': True,
            'description': 'Your own build, %.0f MB, saved from another of your devices on '
                           '%s. It carries your logins, so nothing has to be signed in '
                           'again.' % (asset.get('size', 0) / 1048576.0,
                                       (asset.get('updated_at') or '')[:10]),
        })
    return out


def shared_build_url(repo, tag, token):
    """Resolve a release tagged `tag` in `repo` to its zip asset's API URL.

    Never raises: missing token, network errors, 404, missing tag, or no zip asset
    all log a warning and return None.
    """
    if not token:
        log('cannot resolve shared build %s/%s without a GitHub token' % (repo, tag),
            xbmc.LOGWARNING)
        return None
    try:
        rel = gh_json('/repos/%s/releases/tags/%s' % (repo, quote(tag)), token)
        if not rel:
            log('no release found for %s/%s' % (repo, tag), xbmc.LOGWARNING)
            return None
        asset = next((a for a in rel.get('assets', ()) if a.get('name', '').endswith('.zip')),
                     None)
        if not asset:
            log('no zip asset found in release %s/%s' % (repo, tag), xbmc.LOGWARNING)
            return None
        return asset.get('url')
    except Exception as exc:  # noqa: BLE001
        log('could not resolve shared build %s/%s: %s' % (repo, tag, exc), xbmc.LOGWARNING)
        return None


def all_builds():
    """Public builds from the manifest, plus any personal build this device's token can see."""
    manifest_builds, _ = get_manifest()
    token = gh_token()
    resolved = []
    for b in manifest_builds:
        entry = dict(b)
        repo = entry.get('repo')
        tag = entry.get('tag')
        if repo and tag:
            asset_url = shared_build_url(repo, tag, token) if token else None
            if asset_url:
                entry['url'] = asset_url
                entry['auth'] = True
                resolved.append(entry)
            elif entry.get('url'):
                resolved.append(entry)
        elif entry.get('url'):
            resolved.append(entry)
    return resolved + personal_builds()


def _release_for_tag(repo, token, tag, title):
    rel = gh_json('/repos/%s/releases/tags/%s' % (repo, quote(tag)), token)
    if rel:
        return rel
    return gh_json('/repos/%s/releases' % repo, token, data={
        'tag_name': tag,
        'name': title,
        'body': 'Personal StarWave build, uploaded by the StarWave Wizard. Carries saved '
                'logins - this repository must stay private.',
        # Never the newest *release*: releases/latest/download/ has to keep resolving to the
        # public build, because that URL is compiled into older wizards as their fallback.
        'prerelease': True,
    })


class _ProgressFile:
    """Feeds a file to http.client in blocks while driving the progress dialog."""

    def __init__(self, path, dialog, label):
        self.fh = open(path, 'rb')
        self.total = os.path.getsize(path)
        self.sent = 0
        self.pct = -1
        self.dialog = dialog
        self.label = label

    def read(self, size=-1):
        if self.dialog.iscanceled():
            raise IOError('cancelled')
        chunk = self.fh.read(size)
        self.sent += len(chunk)
        pct = int(self.sent * 100 / self.total) if self.total else 0
        if pct != self.pct:
            self.pct = pct
            self.dialog.update(pct, '%s\n%s of %s'
                               % (self.label, human_size(self.sent), human_size(self.total)))
        return chunk

    def close(self):
        try:
            self.fh.close()
        except OSError:
            pass


def upload_asset(repo, token, release, path, asset_name, dialog):
    """Put path on the release as asset_name, replacing any asset already using that name."""
    for a in release.get('assets', ()):
        if a.get('name') == asset_name:
            log('replacing the existing %s asset' % asset_name)
            gh_json('/repos/%s/releases/assets/%s' % (repo, a['id']), token, method='DELETE')

    size = os.path.getsize(path)
    url = '%s/repos/%s/releases/%s/assets?name=%s' % (GITHUB_UPLOADS, repo, release['id'],
                                                      quote(asset_name))
    body = _ProgressFile(path, dialog, 'Uploading %s' % asset_name)
    req = _gh_request(url, token, 'application/vnd.github+json', body, 'application/zip')
    # urllib refuses to send a file object without this, and http.client needs it to know
    # when the body ends.
    req.add_header('Content-Length', str(size))
    try:
        raw = urlopen(req, timeout=1800).read()
    except HTTPError as exc:
        raise IOError(_gh_error(exc))
    finally:
        body.close()

    asset = json.loads(raw.decode('utf-8')) if raw else {}
    if asset.get('size') != size:
        raise IOError('GitHub stored %s bytes of the %s sent -  the upload did not complete'
                      % (asset.get('size'), size))
    return asset


# A GitHub personal access token always carries one of these prefixes. Checking it is not
# security, it is the difference between "that is your repository name, not your token" and a
# 401 twenty seconds later with nothing to explain it.
TOKEN_PREFIXES = ('github_pat_', 'ghp_', 'gho_', 'ghu_', 'ghs_', 'ghr_')

TOKEN_HELP = (
    'PERSONAL BUILDS\n\n'
    'A personal build is this device packaged up with its logins intact, so your other '
    'devices can install it and be signed in already.\n\n'
    'A published build can never carry logins - the StarWave repository has to be readable '
    'by anyone, which is exactly why it holds no credentials. Your own builds go somewhere '
    'else: a private GitHub repository that belongs to you. Create an empty private repo -\n'
    'call it anything, for example  yourname/starwave-personal - and point this at it.\n\n'
    'This device is currently set to:  %s\n\n'
    'Kodi cannot sign in to GitHub on its own, so it needs a token.\n\n'
    'HOW TO GET ONE\n\n'
    '1.  On a computer or phone, sign in to github.com\n'
    '2.  Settings > Developer settings > Personal access tokens > Fine-grained tokens\n'
    '3.  Generate new token\n'
    '4.  Repository access:  Only select repositories  >  pick YOUR private repo\n'
    '        (the one this device is set to, shown above)\n'
    '5.  Permissions:  Contents  =  Read and write\n'
    '6.  Generate, then copy it straight away - GitHub never shows it again\n\n'
    'The token is one long line starting with "github_pat_".\n\n'
    'WHERE IT GOES\n\n'
    'Back here: My GitHub token > Enter my GitHub token. There is a second setting for the '
    'repository name - that is not where the token goes, and this screen will tell you if '
    'the two get swapped.\n\n'
    'The token stays on this device. It is never included in any build, and it never leaves '
    'this Kodi except to talk to GitHub.'
)


def human_size(nbytes):
    """Format byte count for progress dialogs: whole bytes below 1024, one decimal above."""
    if nbytes < 1024:
        return '%d B' % nbytes
    if nbytes < 1024 * 1024:
        return '%.1f KB' % (nbytes / 1024.0)
    if nbytes < 1024 * 1024 * 1024:
        return '%.1f MB' % (nbytes / 1048576.0)
    return '%.1f GB' % (nbytes / 1073741824.0)


def _mask(token):
    """Enough of a token to recognise it by, never enough to use."""
    if len(token) < 16:
        return '*' * len(token)
    return '%s...%s' % (token[:11], token[-4:])


def _looks_like_repo(text):
    """owner/name typed into the token box -  the single easiest mistake to make here."""
    return ('/' in text and len(text) < 80
            and not text.lower().startswith(TOKEN_PREFIXES))


def _save_token(value):
    xbmcaddon.Addon().setSetting('gh_token', value)


def _can_write(repo, token):
    """Can this token actually write here? Returns (ok, why not).

    Not answerable from the repository's own `permissions` object: that describes the *user's*
    access, and it reports push=true for a token holding only Contents: Read. Measured on a
    real read-only token, which then 403'd on the very next call. The only honest test is to
    try one. A draft release creates no tag, is invisible without push access, and is removed
    again immediately.
    """
    rel = None
    try:
        rel = gh_json('/repos/%s/releases' % repo, token, data={
            'tag_name': 'starwave-wizard-write-check',
            'name': 'StarWave Wizard write check',
            'body': 'Created to confirm this device\'s token can write. Deleted immediately.',
            'draft': True,
        })
        return True, ''
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)
    finally:
        if rel and rel.get('id'):
            try:
                gh_json('/repos/%s/releases/%s' % (repo, rel['id']), token, method='DELETE')
            except Exception as exc:  # noqa: BLE001
                log('could not remove the write-check draft: %s' % exc, xbmc.LOGWARNING)


def _check_token(token, repo):
    """Ask GitHub who we are. Returns (ok, headline, detail)."""
    try:
        info = gh_json('/repos/%s' % repo, token)
    except Exception as exc:  # noqa: BLE001
        return False, 'GitHub would not accept that.', str(exc)
    if info is None:
        return False, 'GitHub cannot see %s with this token.' % repo, (
            'Either the name is wrong, or the token was not granted access to it. A '
            'fine-grained token only sees the repositories picked when it was made.')

    if not info.get('private'):
        return True, 'Connected to %s.' % repo, (
            '[COLOR red]%s is PUBLIC right now.[/COLOR] A personal build carries your logins - '
            'do not upload one until it is private again.' % repo)

    # Reading needs Contents: Read; uploading needs Contents: Read and write. Saying
    # "connected" on the strength of a read is how a 403 once arrived after a 400 MB package
    # rather than before it.
    writable, why = _can_write(repo, token)
    if not writable:
        # GitHub's own wording goes to the log rather than the screen - it is long, and the
        # fix is the same whatever it says.
        log('write check refused: %s' % why, xbmc.LOGWARNING)
        return False, 'Read-only access to %s.' % repo, (
            'It can read the repository but not write to it.\n\nOn github.com, edit this '
            'token and set Permissions > Contents to [B]Read and write[/B].')

    mine = personal_builds()
    return True, 'Connected to %s, with write access.' % repo, (
        '%d personal build(s) waiting for this device.' % len(mine) if mine
        else 'No personal build uploaded yet. Use Back up my settings.')


def _enter_token():
    """Prompt for a token, sanity-check what was typed, save it, then test it."""
    dlg = xbmcgui.Dialog()
    typed = dlg.input('Paste your GitHub token (starts with github_pat_)', '',
                      xbmcgui.INPUT_ALPHANUM).strip()
    # Kodi returns '' both for "cancelled" and for "cleared the box", so empty can only mean
    # leave things alone. Removing a token has its own entry on the menu.
    if not typed:
        return notify('Nothing entered - no change')

    # The wrong-box mistake, caught before it becomes a 404 with no explanation.
    if _looks_like_repo(typed):
        if dlg.yesno(
                ADDON_NAME,
                'That looks like a repository name, not a token.\n\n'
                'A token is one long line starting with "github_pat_".\n\n'
                'Set "%s" as the repository instead?' % typed,
                nolabel='No, retype the token', yeslabel='Yes, set repository'):
            xbmcaddon.Addon().setSetting('gh_repo', typed.strip('/'))
            dlg.ok(ADDON_NAME, 'Repository set to %s.\n\nNow the token.' % typed.strip('/'))
        return _enter_token()

    if not typed.lower().startswith(TOKEN_PREFIXES):
        if not dlg.yesno(
                ADDON_NAME,
                'That does not look like a GitHub token.\n\nThey start with "github_pat_", '
                'or "ghp_" for the older classic kind.\n\nSave it anyway?',
                nolabel='Try again', yeslabel='Save anyway'):
            return _enter_token()

    _save_token(typed)
    ok, headline, detail = _check_token(typed, gh_repo())
    if ok:
        return dlg.ok(ADDON_NAME, 'Saved %s\n\n%s\nPersonal builds are on.\n\n%s'
                      % (_mask(typed), headline, detail))
    dlg.ok(ADDON_NAME, '[COLOR red]%s[/COLOR]\n\n%s' % (headline, detail))
    if dlg.yesno(ADDON_NAME, 'Change the repository? It is currently %s.' % gh_repo(),
                 nolabel='Leave it', yeslabel='Change'):
        _enter_repo()


def _enter_repo():
    dlg = xbmcgui.Dialog()
    typed = dlg.input('Repository, written as owner/name', gh_repo(),
                      xbmcgui.INPUT_ALPHANUM).strip().strip('/')
    if not typed:
        return notify('Nothing entered - no change')
    if '/' not in typed or typed.startswith(TOKEN_PREFIXES):
        return dlg.ok(ADDON_NAME,
                      'A repository is written as owner/name -  for example '
                      'yourname/starwave-personal. "%s" is not, so nothing was changed.' % typed)
    xbmcaddon.Addon().setSetting('gh_repo', typed)
    ok, headline, detail = _check_token(gh_token(), typed) if gh_token() else (
        True, 'Repository set to %s.' % typed, 'Enter a token next to switch personal builds on.')
    dlg.ok(ADDON_NAME, '%s\n\n%s' % (headline, detail))


def auth_github_device():
    """Interactive GitHub Device Flow with QR Code display and automatic token saving."""
    dialog_title = 'GitHub Device Authorization'
    try:
        url = 'https://github.com/login/device/code'
        data = {'client_id': GITHUB_CLIENT_ID, 'scope': 'repo'}
        headers = {'Accept': 'application/json', 'User-Agent': 'StarWave-Wizard'}

        req = Request(url, data=urlencode(data).encode('utf-8'), headers=headers)
        with urlopen(req, timeout=10) as resp:
            res = json.loads(resp.read().decode('utf-8'))

        device_code = res.get('device_code')
        user_code = res.get('user_code')
        verification_uri = res.get('verification_uri', 'https://github.com/login/device')
        interval = max(int(res.get('interval', 5)), 1)
        expires_in = int(res.get('expires_in', 900))

        if not device_code or not user_code:
            xbmcgui.Dialog().ok(dialog_title, 'Could not start GitHub device authorization.')
            return False

        af = _get_account_fanout()
        qr_img = af.make_qr_file(verification_uri, tag='github')
        line1 = '1. Scan QR code or visit: [B]%s[/B]' % verification_uri
        line2 = '2. Enter Code: [B][COLOR gold]%s[/COLOR][/B]' % user_code
        line3 = 'Waiting for authorization on GitHub...'

        dialog = af.QRCodeProgressDialog(dialog_title, line1, line2, line3, qr_img)

        poll_url = 'https://github.com/login/oauth/access_token'
        poll_data = {
            'client_id': GITHUB_CLIENT_ID,
            'device_code': device_code,
            'grant_type': 'urn:ietf:params:oauth:grant-type:device_code'
        }

        start = time.time()
        access_token = None

        while not dialog.iscanceled() and (time.time() - start) < expires_in:
            if af._wait_dialog(dialog, interval):
                break
            elapsed = int(time.time() - start)
            remaining = max(0, expires_in - elapsed)
            pct = min(100, int(elapsed / expires_in * 100))
            dialog.update(
                pct,
                line1=line1,
                line2=line2,
                line3='Waiting for GitHub confirmation... (%ds remaining)' % remaining,
                image=qr_img,
            )

            try:
                poll_req = Request(poll_url, data=urlencode(poll_data).encode('utf-8'), headers=headers)
                with urlopen(poll_req, timeout=5) as poll_resp:
                    pres = json.loads(poll_resp.read().decode('utf-8'))

                if 'access_token' in pres:
                    access_token = pres['access_token']
                    break
                err = pres.get('error')
                if err == 'authorization_pending':
                    continue
                elif err == 'slow_down':
                    interval += 5
                    continue
                elif err in ('expired_token', 'access_denied'):
                    log('GitHub device auth failed: %s' % err, xbmc.LOGWARNING)
                    break
            except Exception as exc:
                log('GitHub polling error: %s' % exc, xbmc.LOGWARNING)
                continue

        dialog.close()

        if not access_token:
            if not dialog.iscanceled():
                xbmcgui.Dialog().ok(dialog_title, 'GitHub authorization was cancelled or timed out.')
            return False

        username = ''
        try:
            u_req = Request('https://api.github.com/user', headers={
                'Authorization': 'Bearer %s' % access_token,
                'Accept': 'application/vnd.github+json',
                'User-Agent': 'StarWave-Wizard'
            })
            with urlopen(u_req, timeout=20) as u_resp:
                u_data = json.loads(u_resp.read().decode('utf-8'))
                username = u_data.get('login', '')
        except Exception:
            pass

        _save_token(access_token)
        user_msg = ' as [B]@%s[/B]' % username if username else ''
        xbmcgui.Dialog().ok(
            dialog_title,
            'GitHub Connected successfully%s!\n\n'
            'Protected builds are now unlocked on this device.' % user_msg
        )
        return True
    except Exception as exc:
        log('GitHub auth error: %s' % exc, xbmc.LOGERROR)
        xbmcgui.Dialog().ok(dialog_title, 'GitHub authorization failed:\n\n%s' % exc)
        return False


def do_token():
    """The guided token screen with Device Flow QR / TV login and manual token entry."""
    dlg = xbmcgui.Dialog()
    token = gh_token()

    if not token:
        choice = dlg.select('StarWave GitHub Authentication', [
            'Sign in with GitHub (Scan QR / Code on Phone)',
            'Enter GitHub token manually (Paste)',
            'How do I get a token or access?',
            'What is GitHub sign-in for?',
        ])
        if choice == 0:
            return auth_github_device()
        if choice == 1:
            return _enter_token()
        if choice in (2, 3):
            dlg.textviewer(ADDON_NAME, TOKEN_HELP % gh_repo())
            if dlg.yesno(ADDON_NAME, 'Sign in with GitHub now?',
                         nolabel='Not now', yeslabel='Sign in'):
                return auth_github_device()
        return

    choice = dlg.select('GitHub Account Connected (%s)' % _mask(token), [
        'Check connection with GitHub',
        'Re-authorize with GitHub (Scan QR / Code)',
        'Replace token manually (%s)' % _mask(token),
        'Disconnect GitHub account',
        'What is this for?',
    ])
    if choice == 0:
        dlg.notification(ADDON_NAME, 'Checking with GitHub', ICON, 2000)
        ok, headline, detail = _check_token(token, gh_repo())
        dlg.ok(ADDON_NAME, '%s\n\n%s' % (
            headline if ok else '[COLOR red]%s[/COLOR]' % headline, detail))
    elif choice == 1:
        auth_github_device()
    elif choice == 2:
        _enter_token()
    elif choice == 3:
        if dlg.yesno(ADDON_NAME,
                     'Disconnect your GitHub account from this device?\n\n'
                     'Protected builds will switch off. Nothing installed changes.',
                     nolabel='Keep it', yeslabel='Disconnect'):
            _save_token('')
            dlg.ok(ADDON_NAME, 'GitHub account disconnected.')
    elif choice == 4:
        dlg.textviewer(ADDON_NAME, TOKEN_HELP % gh_repo())


# ----------------------------------------------------------------------------- menus


def menu():
    # Trustworthy version readout: taken straight from the build's own version.txt plus the
    # wizard's live disk version. Shown first so "which build am I on?" is answered on open.
    b_ver = build_version() or 'StarWave'
    w_ver = addon_disk_version(ADDON_ID) or ADDON.getAddonInfo('version')
    w_clean = ('v' + w_ver.lstrip('v')) if w_ver else ''
    status_label = '%s \u00b7 Wizard %s' % (b_ver, w_clean) if w_clean else b_ver

    # 1. Device Status
    add_item(
        status_label,
        'What is installed here, when it landed, and what this device is signed into.\n\n'
        'Build, skin, wizard versions and account statuses.',
        action='version',
    )
    # 2. 1. Sign in once (Debrid & Trakt)
    add_item(
        '1. Sign in once (Debrid & Trakt)',
        'Authorize Real-Debrid, Premiumize, AllDebrid, or Trakt once in this wizard, then push your '
        'credentials to all installed add-ons (Umbrella, Seren, The Crew, The Gears, Otaku, '
        'TMDb Helper).\n\nNo stored credentials in builds, no manual entry across 10 add-on menus.',
        folder=True, action='accounts',
    )
    # 3. 2. Refresh Widgets & Reload Skin
    add_item(
        '2. Refresh Widgets & Reload Skin',
        'Forces Arctic Fuse and Kodi to reload all home screen widgets with your newly authorized accounts immediately.',
        action='refresh_skin',
    )
    # 4. 3. Check for updates & refresh repositories
    add_item(
        '3. Check for updates & refresh repositories',
        'Forces Kodi to check all repositories immediately for new add-on versions and updates.',
        action='refresh_repos',
    )
    # 5. 4. Unlock Private Builds (GitHub)
    token = gh_token()
    gh_status = '[COLOR green]Unlocked[/COLOR]' if token else '[COLOR gold]Sign-in Required[/COLOR]'
    add_item(
        '4. Unlock Private Builds \u00b7 %s' % gh_status,
        'Authenticate with GitHub via phone QR / TV code or personal token.\n\n'
        'Unlocks access to download StarWave builds from the private builds repository.',
        action='token',
    )
    # 6. 5. Build Maintenance (Install / Fresh Wipe)
    add_item(
        '5. Build Maintenance (Install / Fresh Wipe)',
        'Choose which StarWave build to put on this device, keep existing settings, or factory reset Kodi.',
        folder=True, action='builds',
    )
    add_item('What this installs', 'Details of what each option changes.', action='info')
    xbmcplugin.endOfDirectory(HANDLE)


def _get_account_fanout():
    try:
        from resources.lib import account_fanout
        return account_fanout
    except ImportError:
        pass
    for cand in (
        os.path.join(os.path.dirname(__file__), 'resources', 'lib'),
        os.path.join(HOME, 'addons', ADDON_ID, 'resources', 'lib'),
    ):
        if os.path.isdir(cand) and cand not in sys.path:
            sys.path.insert(0, cand)
    import account_fanout
    return account_fanout


def accounts_menu():
    af = _get_account_fanout()
    status = af.get_account_status()
    rd_stat = '[COLOR green]Active[/COLOR]' if status['realdebrid']['active'] else '[COLOR gold]Not Authorized[/COLOR]'
    pm_stat = '[COLOR green]Active[/COLOR]' if status['premiumize']['active'] else '[COLOR gold]Not Authorized[/COLOR]'
    ad_stat = '[COLOR green]Active[/COLOR]' if status['alldebrid']['active'] else '[COLOR gold]Not Authorized[/COLOR]'
    tr_stat = '[COLOR green]Active[/COLOR]' if status['trakt']['active'] else '[COLOR gold]Not Authorized[/COLOR]'
    yt_stat = '[COLOR green]Active[/COLOR]' if status.get('youtube', {}).get('active') else '[COLOR gold]Not Configured[/COLOR]'

    try:
        target_summary = af.get_targets_summary()
    except Exception:
        targets = af.get_enabled_targets() if hasattr(af, 'get_enabled_targets') else []
        target_summary = ', '.join(targets) if targets else 'None selected'
    add_item(
        'Configure Fan-Out Target Add-ons (%s)' % target_summary,
        'Choose which installed video add-ons receive your credentials during one-click sign-in.',
        action='fanout_targets',
    )
    add_item(
        'Trakt \u00b7 %s' % tr_stat,
        'Authorize Trakt via phone QR code or 8-character device code.\n\n'
        'Fans out credentials to enabled target add-ons (%s).' % target_summary,
        action='auth_trakt',
    )
    add_item(
        'Real-Debrid \u00b7 %s' % rd_stat,
        'Authorize Real-Debrid via phone QR code or 8-character device code.\n\n'
        'Fans out credentials to enabled target add-ons (%s).' % target_summary,
        action='auth_rd',
    )
    add_item(
        'Premiumize \u00b7 %s' % pm_stat,
        'Authorize Premiumize via phone QR code or PIN code.\n\n'
        'Fans out credentials to enabled target add-ons (%s).' % target_summary,
        action='auth_pm',
    )
    add_item(
        'AllDebrid \u00b7 %s' % ad_stat,
        'Authorize AllDebrid via phone QR code or PIN.\n\n'
        'Fans out credentials to enabled target add-ons (%s).' % target_summary,
        action='auth_ad',
    )
    add_item(
        'YouTube \u00b7 %s' % yt_stat,
        'Configure personal YouTube API key or OAuth credentials.\n\n'
        'StarWave trailers in Movies use TMDb by default with zero key required. A personal key is only needed for custom YouTube searches.',
        action='auth_youtube',
    )
    add_item(
        'Account Status & Connected Add-ons',
        'View the current sign-in status across all installed add-ons on this device.',
        action='accounts_status',
    )
    add_item(
        'Refresh Widgets & Reload Skin',
        'Forces Arctic Fuse and Kodi to reload all home screen widgets with your newly authorized accounts immediately.',
        action='refresh_skin',
    )
    add_item(
        'Clear / Revoke Saved Logins',
        'Selectively revoke and clear Real-Debrid, Premiumize, AllDebrid, Trakt, YouTube, or GitHub tokens, or wipe all logins.',
        action='clear_logins',
    )
    xbmcplugin.endOfDirectory(HANDLE)


def auth_youtube():
    """Configure personal YouTube API credentials or display info."""
    af = _get_account_fanout()
    status = af.get_account_status()
    current_key = _safe_get_addon_setting('plugin.video.youtube', 'youtube.api.key')

    options = [
        'Enter Custom YouTube Data API v3 Key',
        'Enter YouTube Client ID & Secret (Optional)',
        'Clear YouTube API Key & Credentials',
        'YouTube & Trailer Information',
    ]
    choice = xbmcgui.Dialog().select('YouTube Configuration', options)
    if choice < 0:
        return

    if choice == 0:
        key = xbmcgui.Dialog().input('Enter YouTube Data API v3 Key:', defaultt=current_key)
        if key:
            af.fanout_youtube(api_key=key.strip())
            xbmcgui.Dialog().notification(ADDON_NAME, 'YouTube API Key saved', ICON, 3000)
            xbmc.executebuiltin('Container.Refresh')
    elif choice == 1:
        current_id = _safe_get_addon_setting('plugin.video.youtube', 'youtube.api.id')
        cid = xbmcgui.Dialog().input('Enter YouTube Client ID:', defaultt=current_id)
        if cid:
            current_sec = _safe_get_addon_setting('plugin.video.youtube', 'youtube.api.secret')
            csec = xbmcgui.Dialog().input('Enter YouTube Client Secret:', defaultt=current_sec)
            af.fanout_youtube(client_id=cid.strip(), client_secret=csec.strip() if csec else '')
            xbmcgui.Dialog().notification(ADDON_NAME, 'YouTube OAuth Credentials saved', ICON, 3000)
            xbmc.executebuiltin('Container.Refresh')
    elif choice == 2:
        if xbmcgui.Dialog().yesno(ADDON_NAME, 'Clear YouTube API key and credentials from YouTube add-on?'):
            af.clear_youtube_credentials()
            xbmcgui.Dialog().notification(ADDON_NAME, 'YouTube credentials cleared', ICON, 3000)
            xbmc.executebuiltin('Container.Refresh')
    elif choice == 3:
        msg = (
            'TRAILER PLAYBACK IN STARWAVE:\n\n'
            '• StarWave movie and show trailers resolve directly through TMDb metadata with zero setup required.\n'
            '• You do NOT need a Google Cloud account or YouTube API key to play movie trailers.\n\n'
            'CUSTOM YOUTUBE SEARCHES & ADD-ON FEATURES:\n\n'
            '• If you use the standalone YouTube add-on for custom search queries, Google Cloud requires a YouTube Data API v3 key.\n'
            '• You can paste your personal key here to enable custom search inside plugin.video.youtube.'
        )
        xbmcgui.Dialog().textviewer('YouTube & Trailer Info', msg)


def show_accounts_status():
    af = _get_account_fanout()
    status = af.get_account_status()
    lines = ['[B]StarWave Sign-In Status[/B]', '']
    for service, label in (('realdebrid', 'Real-Debrid'), ('premiumize', 'Premiumize'),
                           ('alldebrid', 'AllDebrid'), ('trakt', 'Trakt'), ('youtube', 'YouTube')):
        st = status[service]
        if st['active']:
            lines.append('[B]%s:[/B] Connected as %s' % (label, st['username'] or 'Active'))
            lines.append('  Configured in: %s' % (', '.join(st['addons']) or 'None'))
        else:
            lines.append('[B]%s:[/B] Not Authorized' if service != 'youtube' else '[B]%s:[/B] Not Configured (TMDb Trailers Active)' % label)
        lines.append('')
    xbmcgui.Dialog().textviewer(ADDON_NAME, '\n'.join(lines))


def show_clear_logins_dialog():
    """Interactive selector to revoke specific accounts or wipe all logins."""
    af = _get_account_fanout()
    status = af.get_account_status()
    current_gh_token = gh_token()

    rd_stat = '[COLOR gold]Connected[/COLOR] (%s)' % ', '.join(status['realdebrid']['addons']) if status['realdebrid']['active'] else '[COLOR gray]Not Connected[/COLOR]'
    pm_stat = '[COLOR gold]Connected[/COLOR] (%s)' % ', '.join(status['premiumize']['addons']) if status['premiumize']['active'] else '[COLOR gray]Not Connected[/COLOR]'
    ad_stat = '[COLOR gold]Connected[/COLOR] (%s)' % ', '.join(status['alldebrid']['addons']) if status['alldebrid']['active'] else '[COLOR gray]Not Connected[/COLOR]'
    tr_stat = '[COLOR gold]Connected[/COLOR] (%s)' % ', '.join(status['trakt']['addons']) if status['trakt']['active'] else '[COLOR gray]Not Connected[/COLOR]'
    yt_stat = '[COLOR gold]Configured[/COLOR]' if status.get('youtube', {}).get('active') else '[COLOR gray]Not Set[/COLOR]'
    gh_stat = '[COLOR gold]Authorized[/COLOR]' if current_gh_token else '[COLOR gray]Not Set[/COLOR]'

    options = [
        'Real-Debrid · %s' % rd_stat,
        'Premiumize · %s' % pm_stat,
        'AllDebrid · %s' % ad_stat,
        'Trakt · %s' % tr_stat,
        'YouTube API Key · %s' % yt_stat,
        'GitHub Build Unlock Token · %s' % gh_stat,
        '[COLOR red]Wipe All Saved Logins (Blanket Clean)[/COLOR]',
    ]

    choice = xbmcgui.Dialog().select('Select Account to Revoke & Clear', options)
    if choice < 0:
        return

    if choice == 0:  # Real-Debrid
        if not status['realdebrid']['active']:
            xbmcgui.Dialog().notification(ADDON_NAME, 'Real-Debrid is not connected.', ICON, 3000)
            return
        if xbmcgui.Dialog().yesno(
            ADDON_NAME,
            'Revoke and clear Real-Debrid from all connected add-ons?\n\n'
            'Add-ons: Umbrella, Seren, ResolveURL, The Gears, Otaku\n\n'
            'Trakt and other accounts will remain connected.',
            nolabel='Cancel', yeslabel='Revoke Real-Debrid'
        ):
            cleared = af.clear_realdebrid_credentials()
            xbmcgui.Dialog().ok(ADDON_NAME, 'Real-Debrid cleared across:\n• ' + '\n• '.join(cleared))
            xbmc.executebuiltin('Container.Refresh')

    elif choice == 1:  # Premiumize
        if not status['premiumize']['active']:
            xbmcgui.Dialog().notification(ADDON_NAME, 'Premiumize is not connected.', ICON, 3000)
            return
        if xbmcgui.Dialog().yesno(
            ADDON_NAME,
            'Revoke and clear Premiumize from all connected add-ons?\n\n'
            'Add-ons: Umbrella, Seren, ResolveURL, The Gears, Otaku\n\n'
            'Other accounts will remain connected.',
            nolabel='Cancel', yeslabel='Revoke Premiumize'
        ):
            cleared = af.clear_premiumize_credentials()
            xbmcgui.Dialog().ok(ADDON_NAME, 'Premiumize cleared across:\n• ' + '\n• '.join(cleared))
            xbmc.executebuiltin('Container.Refresh')

    elif choice == 2:  # AllDebrid
        if not status['alldebrid']['active']:
            xbmcgui.Dialog().notification(ADDON_NAME, 'AllDebrid is not connected.', ICON, 3000)
            return
        if xbmcgui.Dialog().yesno(
            ADDON_NAME,
            'Revoke and clear AllDebrid from all connected add-ons?\n\n'
            'Add-ons: Umbrella, Seren, ResolveURL, The Gears, Otaku\n\n'
            'Other accounts will remain connected.',
            nolabel='Cancel', yeslabel='Revoke AllDebrid'
        ):
            cleared = af.clear_alldebrid_credentials()
            xbmcgui.Dialog().ok(ADDON_NAME, 'AllDebrid cleared across:\n• ' + '\n• '.join(cleared))
            xbmc.executebuiltin('Container.Refresh')

    elif choice == 3:  # Trakt
        if not status['trakt']['active']:
            xbmcgui.Dialog().notification(ADDON_NAME, 'Trakt is not connected.', ICON, 3000)
            return
        if xbmcgui.Dialog().yesno(
            ADDON_NAME,
            'Revoke and clear Trakt from all connected add-ons?\n\n'
            'Add-ons: TMDb Helper, Umbrella, Seren, The Gears, The Crew\n\n'
            'Debrid accounts will remain connected.',
            nolabel='Cancel', yeslabel='Revoke Trakt'
        ):
            cleared = af.clear_trakt_credentials()
            xbmcgui.Dialog().ok(ADDON_NAME, 'Trakt cleared across:\n• ' + '\n• '.join(cleared))
            xbmc.executebuiltin('Container.Refresh')

    elif choice == 4:  # YouTube
        if not status.get('youtube', {}).get('active'):
            xbmcgui.Dialog().notification(ADDON_NAME, 'YouTube API key is not configured.', ICON, 3000)
            return
        if xbmcgui.Dialog().yesno(
            ADDON_NAME,
            'Clear YouTube API key and credentials from YouTube add-on?',
            nolabel='Cancel', yeslabel='Clear Key'
        ):
            cleared = af.clear_youtube_credentials()
            xbmcgui.Dialog().ok(ADDON_NAME, 'YouTube credentials cleared.')
            xbmc.executebuiltin('Container.Refresh')

    elif choice == 5:  # GitHub
        if not current_gh_token:
            xbmcgui.Dialog().notification(ADDON_NAME, 'GitHub token is not set.', ICON, 3000)
            return
        if xbmcgui.Dialog().yesno(ADDON_NAME, 'Clear saved GitHub Build Unlock token?', nolabel='Cancel', yeslabel='Clear Token'):
            _save_token('')
            xbmcgui.Dialog().ok(ADDON_NAME, 'GitHub token removed from StarWave Wizard.')
            xbmc.executebuiltin('Container.Refresh')

    elif choice == 6:  # Wipe All
        if xbmcgui.Dialog().yesno(
            ADDON_NAME,
            'Clear and revoke ALL saved logins across all providers?\n\n'
            'This will wipe Real-Debrid, Premiumize, AllDebrid, Trakt, YouTube, and GitHub.',
            nolabel='Cancel', yeslabel='Wipe All'
        ):
            cleared = af.clear_all_credentials()
            _save_token('')
            xbmcgui.Dialog().ok(ADDON_NAME, 'All logins cleared across:\n• ' + '\n• '.join(cleared))
            xbmc.executebuiltin('Container.Refresh')



def builds_menu():
    builds = all_builds()
    if not builds:
        add_item(
            '1. Unlock Builds (Sign in with GitHub)',
            'StarWave builds are stored in a private repository and require a one-time GitHub sign-in.\n\n'
            'Select this option to scan the QR code and unlock builds on this device.',
            action='token',
        )
        return xbmcplugin.endOfDirectory(HANDLE)
    if len(builds) == 1:
        # With a single build there is nothing to choose between, and burying Update behind
        # a folder made it look as though a clean wipe was the only option.
        return build_menu(builds[0]['id'])
    for b in builds:
        add_item(b['name'], b.get('description', ''), folder=True,
                 action='build', id=b['id'])
    xbmcplugin.endOfDirectory(HANDLE)


def build_menu(build_id):
    b = next((x for x in all_builds() if x['id'] == build_id), None)
    if not b:
        return xbmcplugin.endOfDirectory(HANDLE)
    add_item(
        'Update (keep my settings)',
        'Brings %s up to date: skin, menus, widgets and add-ons.\n\n'
        'Your Kodi settings, sources, favourites and every add-on login and configuration '
        'are kept. Nothing has to be signed in again.' % b['name'],
        action='update', id=build_id,
    )
    add_item(
        'Fresh Install (wipe to defaults)',
        'Wipes this device back to exactly %s - add-ons you added yourself, all settings, saved '
        'logins and your GitHub token are removed, leaving nothing extra.\n\nUse for a first '
        'install, to start clean, or before handing the device to someone else. To keep your '
        'setup, use Update instead.' % b['name'],
        action='install', id=build_id,
    )
    add_item(
        'View Error Report & Diagnostics',
        'Displays recent Python exceptions, crashes, socket errors, and diagnostic events captured on this device.',
        action='view_error_log',
    )
    xbmcplugin.endOfDirectory(HANDLE)


def layouts_menu():
    _, layouts = get_manifest()
    current = xbmc.getSkinDir()
    for l in layouts:
        active = ' [COLOR limegreen](current)[/COLOR]' if l['skin'] == current else ''
        add_item(l['name'] + active, l.get('description', ''),
                 action='layout', id=l['id'])
    xbmcplugin.endOfDirectory(HANDLE)


def show_info():
    xbmcgui.Dialog().textviewer(
        ADDON_NAME,
        'StarWave - a Kodi 21 "Omega" build.\n\n'
        'INSTALL OR UPDATE A BUILD\n\n'
        'Update:\n'
        'Keeps your Kodi settings, sources, favourites and all add-on settings, '
        'including saved Trakt, Real-Debrid, Premiumize, and AllDebrid logins. Add-ons you installed '
        'yourself stay installed and enabled.\n\n'
        'Fresh Install:\n'
        'Replaces all of that with the clean build defaults. No credentials or viewing '
        'histories are included in any build - sign in afterwards via "Sign in once (Debrid & Trakt)".\n\n'
        'SIGN IN ONCE (DEBRID & TRAKT)\n\n'
        'Centralized authentication hub: sign into Real-Debrid, Premiumize, AllDebrid, or Trakt once via '
        'phone QR code scan, and the wizard automatically fans out your credentials to all selected add-ons '
        '(Umbrella, Seren, The Crew/ResolveURL, The Gears, Otaku, TMDb Helper).\n\n'
        'SWITCH LAYOUT\n\n'
        'Changes only the skin and its menu (Arctic Fuse 3 or StarWave Aura). Credentials and settings '
        'are untouched, because no skin stores them. Switching back and forth is free and repeatable.\n\n'
        'FRESH WIPE (FACTORY RESET)\n\n'
        'Resets Kodi back to default Estuary while keeping your File Manager sources and the StarWave Wizard '
        'so you can start clean anytime.\n\n'
        'AFTERWARDS\n\n'
        'Kodi closes so it cannot write its old settings back over the new ones. Reopen '
        'Kodi to finish.',
    )


def do_version():
    """The authoritative 'which build am I on?' screen.

    Four rows in a fixed order - build, wizard, skin, and active logins
   - dated with date, time and timezone by the shared format_row().
    """
    ver = build_version()
    if not ver:
        return xbmcgui.Dialog().ok(
            ADDON_NAME,
            'No StarWave build is installed on this device - there is no version to report.')
    rows = device_rows()
    body = 'This device is on:\n\n[B]%s[/B]\n%s\n' % (rows[0], '\n'.join(rows[1:]))
    body += ('\nThe build version is read from version.txt. Skin and wizard '
             'carry their own versions and update independently.')
    show_message(body)


# ----------------------------------------------------------------------------- shared


def _cleanup_temp():
    try:
        if os.path.exists(TEMP_ZIP):
            os.remove(TEMP_ZIP)
    except OSError as exc:
        log('could not remove temp zip: %s' % exc, xbmc.LOGWARNING)


def download(url, dest, dialog, what='the build', token=None):
    """Stream url to dest, driving the progress dialog. Returns False if cancelled.

    token is set only for a personal build, whose asset lives in the private repo and is
    reachable solely through the authenticated API.
    """
    if token:
        resp = gh_asset_response(url, token)
    else:
        resp = urlopen(Request(url, headers={'User-Agent': 'StarWave-Wizard'}), timeout=30)
    total = resp.getheader('content-length')
    total = int(total) if total and total.isdigit() else 0
    got = 0

    with open(dest, 'wb') as fh:
        while True:
            if dialog.iscanceled():
                return False
            chunk = resp.read(1024 * 256)
            if not chunk:
                break
            fh.write(chunk)
            got += len(chunk)
            if total:
                dialog.update(int(got * 100 / total),
                              'Downloading %s\n%s of %s'
                              % (what, human_size(got), human_size(total)))
            else:
                dialog.update(0, 'Downloading %s\n%s' % (what, human_size(got)))

    if total and got < total:
        raise IOError('download truncated: got %d of %d bytes' % (got, total))
    return True


def _skip_addon(name, skip_ids):
    return any(name.startswith('addons/%s/' % a) for a in skip_ids)


def _preserved(name, dest):
    """True when update mode must leave this zip member alone."""
    if name == ADDONS_DB_MEMBER:
        return True
    if not os.path.exists(os.path.join(dest, name.replace('/', os.sep))):
        # Nothing on the device to protect -  ship the build's copy so the file is at
        # least present (a missing settings.xml would break the add-on).
        return False
    if name in USER_FILES:
        return True
    parts = name.split('/')
    if not (len(parts) > 2 and parts[0] == 'userdata' and parts[1] == 'addon_data'):
        return False
    # userdata/addon_data/<id>/settings.xml -  the user's own add-on configuration.
    if len(parts) == 4 and parts[3] == 'settings.xml':
        return True
    # Some add-ons keep settings in a database instead -  The Gears holds its debrid logins
    # in addon_data/plugin.video.gears/databases/settings.db. Every .db under addon_data is
    # user state (settings, caches, watched history).
    if parts[-1].endswith('.db'):
        return True
    # Layout menus the user has customised: skinshortcuts writes *.DATA.xml and .properties,
    # skinvariables writes nodes/<skinid>/*.json. Overwriting either would silently discard
    # a rearranged home screen.
    if parts[2] == 'script.skinvariables' and parts[-1].endswith('.json'):
        return True
    if parts[2] == 'script.skinshortcuts' and parts[-1].endswith(('.DATA.xml', '.properties')):
        return True
    return False


def extract(zip_path, dest, dialog, skip_ids=(), preserve=False, only_missing=False):
    """Extract into dest. Returns False if cancelled.

    preserve=True (update mode) skips members carrying user state -  see _preserved.
    only_missing=True writes a member only when it is not already on disk, which is how a
    layout's configuration is applied without discarding one the user has customised.
    """
    import zipfile

    with zipfile.ZipFile(zip_path) as zf:
        members = [m for m in zf.infolist() if not _skip_addon(m.filename, skip_ids)]
        if preserve:
            members = [m for m in members if not _preserved(m.filename, dest)]
        if only_missing:
            members = [m for m in members
                       if not os.path.exists(os.path.join(dest, m.filename.replace('/', os.sep)))]
        count = len(members)
        for i, member in enumerate(members):
            if dialog.iscanceled():
                return False
            zf.extract(member, dest)
            if i % 25 == 0 or i == count - 1:
                dialog.update(int(i * 100 / max(count, 1)),
                              'Installing\n%d of %d files' % (i + 1, count))
    return True


def build_addon_ids(zip_path, skip_ids=()):
    """Top-level add-on ids the build zip carries."""
    import zipfile

    ids = set()
    with zipfile.ZipFile(zip_path) as zf:
        for name in zf.namelist():
            parts = name.split('/')
            if len(parts) > 1 and parts[0] == 'addons' and parts[1] and parts[1] != 'packages':
                ids.add(parts[1])
    return sorted(ids - set(skip_ids))


def merge_installed(addon_ids):
    """Register the build's add-ons in the device's own add-on database.

    Update mode keeps the device's Addons33.db so add-ons the user installed themselves stay
    registered. Any build add-on it does not know yet is inserted enabled; the metadata rows
    for every build add-on are dropped so Kodi re-reads each addon.xml at the next start - 
    that is what picks up same-version content changes.
    """
    if not addon_ids or not os.path.exists(ADDONS_DB):
        return
    import sqlite3
    now = time.strftime('%Y-%m-%d %H:%M:%S')
    try:
        con = sqlite3.connect(ADDONS_DB)
        for addon_id in addon_ids:
            con.execute(
                'INSERT INTO installed (addonID, enabled, installDate) '
                'SELECT ?, 1, ? WHERE NOT EXISTS '
                '(SELECT 1 FROM installed WHERE addonID = ?)',
                (addon_id, now, addon_id),
            )
            con.execute('DELETE FROM addons WHERE addonID = ?', (addon_id,))
        con.commit()
        con.close()
        log('merged %d build add-ons into the add-on database' % len(addon_ids))
    except Exception as exc:  # noqa: BLE001
        log('could not merge the add-on database: %s' % exc, xbmc.LOGWARNING)


def drop_from_db(addon_ids):
    """Remove add-ons from the add-on database.

    On a platform where their binaries cannot load, leaving those rows in tells Kodi to load
    them anyway.
    """
    if not addon_ids or not os.path.exists(ADDONS_DB):
        return
    import sqlite3
    try:
        con = sqlite3.connect(ADDONS_DB)
        for addon_id in addon_ids:
            for row in list(con.execute('SELECT id FROM addons WHERE addonID = ?', (addon_id,))):
                con.execute('DELETE FROM addonlinkrepo WHERE idAddon = ?', (row[0],))
            for table in ('addons', 'installed', 'update_rules', 'package'):
                con.execute('DELETE FROM %s WHERE addonID = ?' % table, (addon_id,))
        con.commit()
        con.close()
        log('dropped from add-on database: %s' % ', '.join(addon_ids))
    except Exception as exc:  # noqa: BLE001
        log('could not patch the add-on database: %s' % exc, xbmc.LOGWARNING)


def build_addon_data_ids(zip_path):
    """Add-on ids for which the build ships userdata/addon_data. A build can carry data for an
    add-on whose folder lives inside Kodi itself, so this is a separate set from the folder ids."""
    import zipfile
    ids = set()
    with zipfile.ZipFile(zip_path) as zf:
        for name in zf.namelist():
            parts = name.split('/')
            if len(parts) > 3 and parts[0] == 'userdata' and parts[1] == 'addon_data' and parts[2]:
                ids.add(parts[2])
    return ids


def wipe_to_build(zip_path, folder_ids, keep_gh_token='', keep_gh_repo=''):
    """Fresh Install: make the device match the build defaults while preserving paired build unlock token."""
    removed = 0
    addon_data = os.path.join(HOME, 'userdata', 'addon_data')
    # addons/: keep only what the build ships. addon_data/: keep data the build ships too, even
    # for add-ons whose folder is bundled in Kodi rather than the build.
    for base, keep, protect in (
            (ADDONS_DIR, set(folder_ids), {'packages'}),
            (addon_data, set(folder_ids) | build_addon_data_ids(zip_path), {ADDON_ID})):
        if not os.path.isdir(base):
            continue
        for name in os.listdir(base):
            if name in protect or name in keep:
                continue
            path = os.path.join(base, name)
            if os.path.isdir(path):
                shutil.rmtree(path, ignore_errors=True)
                removed += 1

    # The wizard is a build add-on so its folder is kept, but its general data is cleared.
    wiz_data = os.path.join(addon_data, ADDON_ID)
    if os.path.isdir(wiz_data):
        shutil.rmtree(wiz_data, ignore_errors=True)
        removed += 1
    try:
        _get_account_fanout().clear_all_credentials(HOME, include_github=False)
    except Exception as exc:
        log('could not clear credentials in wipe_to_build: %s' % exc, xbmc.LOGWARNING)

    # Re-persist the GitHub unlock token if present
    if keep_gh_token:
        try:
            os.makedirs(wiz_data, exist_ok=True)
            _save_token(keep_gh_token)
            if keep_gh_repo and keep_gh_repo != DEFAULT_REPO:
                xbmcaddon.Addon().setSetting('gh_repo', keep_gh_repo)
            log('preserved GitHub build unlock token across fresh install')
        except Exception as exc:
            log('could not restore gh_token after fresh install: %s' % exc, xbmc.LOGWARNING)

    log('fresh install wiped %d non-build folders (add-ons, data)' % removed)
    return removed


def clear_packages():
    """Drop cached add-on packages so Kodi does not reinstall stale versions."""
    if not os.path.isdir(PACKAGES):
        return
    for name in os.listdir(PACKAGES):
        path = os.path.join(PACKAGES, name)
        try:
            if os.path.isfile(path) or os.path.islink(path):
                os.remove(path)
            else:
                shutil.rmtree(path, ignore_errors=True)
        except OSError as exc:
            log('could not clear %s: %s' % (path, exc), xbmc.LOGWARNING)


# The menu the skin shows is the *generated* includes, rebuilt by script.skinshortcuts only
# when this hash no longer matches the .DATA.xml it was built from. The build's own generated
# includes can be stale (the StarWave v4 payload shipped includes still reading "v2" while its
# 13009.DATA.xml read "v4"), and update mode preserves the correct .DATA.xml but not the
# generated includes under addons/. Deleting the hash forces a rebuild from the .DATA.xml on
# the next start, so the menu always reflects the data, never a stale generated file.
SKINSHORTCUTS_DIR = os.path.join(HOME, 'userdata', 'addon_data', 'script.skinshortcuts')


ADDONS_DIR = os.path.join(HOME, 'addons')
VERSION_TXT = os.path.join(HOME, 'version.txt')
VERSION_RE = re.compile(r'StarWave v\d+')

# The single source of truth for "what build is on this device" is version.txt, which the build
# carries and every install extracts. The wizard also records, in its own addon_data, when it
# last applied a build and how - so "did my update actually run?" has a dated answer that cannot
# drift from a menu label. This file is the wizard's own state, excluded from every build, so it
# always describes THIS device.
APPLIED_RECORD = os.path.join(HOME, 'userdata', 'addon_data', ADDON_ID, 'applied.json')


def build_version():
    """The build version this device is actually running, read from the build's own version.txt.
    Returns e.g. 'StarWave v4', or None if the file is absent (no StarWave installed)."""
    try:
        first = open(VERSION_TXT, encoding='utf-8').read().strip().splitlines()
        m = VERSION_RE.search(first[0]) if first else None
        return m.group(0) if m else (first[0].strip() if first else None)
    except Exception:  # noqa: BLE001
        return None


# ---- one timestamp format for every line the wizard prints -----------------------------------
# The rule: every moment the wizard shows carries DATE, TIME and TIMEZONE, in ONE format, so two
# lines can never look like they mean different things. 12-hour clock with AM/PM (Kodi reports
# locale.use24hourclock = "regional" on these devices, so this matches the rest of the UI). Month
# names come from this table rather than strftime('%b') so the wording cannot shift with locale.
MONTHS = ('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec')


def _utc_offset(seconds):
    """Seconds east of UTC -> '+0100' / '-0400'. '' when the offset is not known."""
    if seconds is None:
        return ''
    sign = '-' if seconds < 0 else '+'
    seconds = abs(int(seconds))
    return '%s%02d%02d' % (sign, seconds // 3600, (seconds % 3600) // 60)


def zone_label(tz='', offset=''):
    """What to print for the zone: a name ('EDT'), else 'UTC-04:00', else '' - never a guess.

    %Z is empty on some platforms and returns a bare numeric offset on others, so anything that
    does not begin with a letter is treated as an offset and rendered from the numeric form.
    """
    tz = (tz or '').strip()
    if tz[:1].isalpha():
        return tz
    off = (offset or '').strip() or tz
    m = re.match(r'^([+-])(\d{2}):?(\d{2})$', off)
    return 'UTC%s%s:%s' % m.groups() if m else ''


def display_zone(when=None):
    """The zone to print beside a moment: the OS zone, which IS the zone Kodi is running in.

    Deliberately NOT read from Kodi's `locale.timezone` over JSON-RPC. That setting is
    Linux-only - measured on the Shield 2026-08-29, `Settings.GetSettingValue locale.timezone`
    answers `Invalid params` on Android, so asking would write an error into kodi.log on every
    render for nothing. On Android Kodi simply uses the OS zone (`persist.sys.timezone`, US/
    Eastern there, `date` printing EDT); on Linux, setting Kodi's timezone sets the process TZ,
    so %Z reflects it either way. Read at RENDER time, never frozen, because a device can move
    between zones. If the zone cannot be named at all, the caller prints no zone rather than an
    empty token or a guess.
    """
    when = when or time.localtime()
    return zone_label(getattr(when, 'tm_zone', '') or time.strftime('%Z', when),
                      _utc_offset(getattr(when, 'tm_gmtoff', None)))


def format_stamp(when, tz='', offset=''):
    """'Aug 22, 2026 at 3:11 PM EDT' - the single timestamp format every line goes through.

    `when` is a time.struct_time. `tz`/`offset` describe the zone to print; when both are empty
    the zone is left OFF. That is deliberate and it is the honest degrade for a record written
    before the wizard stamped a zone: the device may have moved since, so a backfilled zone
    would be a fabrication. Show what is known.
    """
    if not when:
        return ''
    hour = when.tm_hour % 12 or 12
    stamp = '%s %d, %d at %d:%02d %s' % (MONTHS[when.tm_mon - 1], when.tm_mday, when.tm_year,
                                         hour, when.tm_min, 'AM' if when.tm_hour < 12 else 'PM')
    zone = zone_label(tz, offset)
    return '%s %s' % (stamp, zone) if zone else stamp


def local_stamp(epoch=None):
    """format_stamp() for an epoch time, rendered in local time with the live zone label.

    Safe for a past moment: tm_zone/tm_gmtoff come from localtime() for THAT instant, so a
    summer file keeps its summer zone. The instant is absolute, so nothing has to be remembered
    and nothing can be wrong - unlike a record, which only ever holds wall-clock digits.
    """
    when = time.localtime(epoch)
    return format_stamp(when, display_zone(when))


def addon_updated_stamp(addon_id):
    """When this add-on was last updated here, approximated from its addon.xml mtime.

    THERE IS NO INSTALL TIMESTAMP FOR A KODI ADD-ON that the wizard can trust, so this is an
    APPROXIMATION and is labelled as an update time, not an install record: addon.xml is
    rewritten every time the add-on is extracted (by Kodi's own installer and by
    ensure_addon_current()), which makes its mtime the closest honest proxy for "when this
    version landed here". It moves if anything else touches the file, and a copy that preserves
    mtimes (tar -p, rsync -a) keeps the source's. If the mtime cannot be read at all this
    returns '', and the caller prints the version with NO timestamp rather than a wrong one.
    """
    try:
        return local_stamp(os.path.getmtime(os.path.join(HOME, 'addons', addon_id, 'addon.xml')))
    except Exception:  # noqa: BLE001
        return ''


def write_applied_record(mode):
    """Stamp version + time + zone + mode after an install, so the update is provably recorded."""
    now = time.localtime()
    rec = {'version': build_version() or 'unknown', 'mode': mode,
           # 'when' keeps its original naive '%Y-%m-%d %H:%M:%S' shape, so every existing reader
           # - including an older wizard, if one is ever rolled back onto a device - still parses
           # it unchanged. The zone is recorded ALONGSIDE it in both forms: the name because that
           # is what reads naturally on screen, and the numeric UTC offset because a name is
           # ambiguous and %Z is empty or numeric on some platforms. A record holds only
           # wall-clock digits, so the zone THOSE DIGITS WERE WRITTEN IN has to travel with them;
           # records written before this existed carry neither and are rendered with no zone,
           # never backfilled from today's, because the device may have moved since.
           'when': time.strftime('%Y-%m-%d %H:%M:%S', now),
           'tz': getattr(now, 'tm_zone', '') or time.strftime('%Z', now),
           'utcoffset': _utc_offset(getattr(now, 'tm_gmtoff', None))}
    try:
        os.makedirs(os.path.dirname(APPLIED_RECORD), exist_ok=True)
        with open(APPLIED_RECORD, 'w', encoding='utf-8') as fh:
            json.dump(rec, fh)
        log('recorded applied build: %s' % rec)
    except OSError as exc:
        log('could not write applied record: %s' % exc, xbmc.LOGWARNING)
    return rec


def applied_record():
    """The last-applied record, or None if the wizard has never applied a build here."""
    try:
        with open(APPLIED_RECORD, encoding='utf-8') as fh:
            return json.load(fh)
    except Exception:  # noqa: BLE001
        return None


def record_stamp(rec):
    """An applied record's moment in the shared format. '' when the record has no usable time.

    A record from before zones were stamped ('tz'/'utcoffset' absent) renders date and time with
    no zone - see format_stamp().
    """
    when = (rec or {}).get('when') or ''
    try:
        parsed = time.strptime(when[:19], '%Y-%m-%d %H:%M:%S')
    except ValueError:
        try:      # a record carrying only a date still renders, just without a time
            parsed = time.strptime(when[:10], '%Y-%m-%d')
        except ValueError:
            return ''
        return '%s %d, %d' % (MONTHS[parsed.tm_mon - 1], parsed.tm_mday, parsed.tm_year)
    return format_stamp(parsed, rec.get('tz', ''), rec.get('utcoffset', ''))


def format_row(label, stamp):
    """One line of the version block: 'Wizard v5.2.0 - Aug 29, 2026 at 6:12 PM EDT'.

    No verb. The owner cut 'updated' / 'fresh-installed' from these rows on 2026-08-30: a date
    already says the thing landed, so the word only widened the line. The install mode is still
    stamped into the applied record by write_applied_record(); it simply stopped being displayed
    (the bottom row is now logins_row(), which answers a question a date cannot).

    A row whose moment is unknown prints the label alone. Nothing else formats these lines, so
    they cannot drift apart.
    """
    if not stamp:
        return label
    return '%s - %s' % (label, stamp)


# The add-on components shown in the version block, in the order the owner set. ADDING ONE IS
# ONE ENTRY HERE and nothing else: the version comes from that add-on's addon.xml on disk and
# the moment from the same file's mtime, exactly like the two already listed. The skin is
# resolved at call time because it is whichever skin is active, not a fixed id.
COMPONENTS = (('Wizard', lambda: ADDON_ID), ('Skin', lambda: xbmc.getSkinDir()))

# WHERE A LOGIN CAN LIVE, per service. Adding a service is ONE entry here and nothing else,
# exactly like COMPONENTS above; a service counts as signed in when ANY of its locations holds a
# non-empty value. Several add-ons hold the same login independently, so several locations per
# service is normal rather than redundant - a device signed into Trakt through Umbrella but not
# through Seren is still signed into Trakt.
#
# A location is (addon_id, setting_id) in userdata/addon_data/<addon_id>/settings.xml, EXCEPT
# The Gears, which keeps its logins in a sqlite database instead - the trap documented in
# CLAUDE.md. GEARS_DB marks those.
#
# Every id below was read off the owner's Shield on 2026-08-30 rather than guessed: the naming
# is inconsistent between add-ons (`trakt.user.token`, `trakt.token`, `trakt.auth`,
# `RealDebridResolver_token`, `realdebridtoken`, `rd.auth`, `rd.token`) and there is no
# convention to infer.
GEARS_DB = '<gears-db>'
SIGNIN_SERVICES = (
    ('Trakt', (
        ('script.module.myaccounts', 'trakt.token'),
        ('plugin.video.umbrella', 'trakt.user.token'),
        ('plugin.video.thecrew', 'trakt.token'),
        ('plugin.video.seren', 'trakt.auth'),
        (GEARS_DB, 'trakt.token'),
    )),
    ('Real-Debrid', (
        ('script.module.myaccounts', 'realdebrid.token'),
        ('script.module.resolveurl', 'RealDebridResolver_token'),
        ('plugin.video.umbrella', 'realdebridtoken'),
        ('plugin.video.seren', 'rd.auth'),
        (GEARS_DB, 'rd.token'),
    )),
    ('Premiumize', (
        ('script.module.myaccounts', 'premiumize.token'),
        ('script.module.resolveurl', 'PremiumizeMeResolver_token'),
        ('plugin.video.umbrella', 'premiumizetoken'),
        ('plugin.video.seren', 'premiumize.token'),
        (GEARS_DB, 'pm.token'),
    )),
)


def _settings_xml_text(addon_id, cache):
    """An add-on's settings.xml as text, read at most once per render. '' if it cannot be read."""
    if addon_id not in cache:
        path = os.path.join(HOME, 'userdata', 'addon_data', addon_id, 'settings.xml')
        try:
            with open(path, 'r', encoding='utf-8', errors='ignore') as fh:
                cache[addon_id] = fh.read()
        except OSError:   # absent add-on, absent file, unreadable file: all mean "no login here"
            cache[addon_id] = ''
    return cache[addon_id]


def _gears_settings(cache):
    """{setting_id: has_a_value} from The Gears' sqlite settings table. {} if it cannot be read.

    Read-only with a short timeout, the same treatment Addons33.db gets, because Kodi may have
    this database open. Only the emptiness of each value is kept - never a value.
    """
    if GEARS_DB in cache:
        return cache[GEARS_DB]
    cache[GEARS_DB] = {}
    path = os.path.join(HOME, *GEARS_DB_REL.split('/'))
    if not os.path.exists(path):
        return cache[GEARS_DB]
    con = None
    try:
        uri = pathlib.Path(path).as_uri() + '?mode=ro'
        con = sqlite3.connect(uri, uri=True, timeout=1.0)
        cache[GEARS_DB] = {row[0]: bool(row[1])
                           for row in con.execute('SELECT setting_id, setting_value IS NOT NULL '
                                                  "AND TRIM(setting_value) != '' FROM settings")}
    except Exception as exc:  # noqa: BLE001 - locked, corrupt, or no such table
        log('could not read The Gears settings db for sign-in state: %s' % exc, xbmc.LOGWARNING)
    finally:
        if con is not None:
            try:
                con.close()
            except Exception:  # noqa: BLE001
                pass
    return cache[GEARS_DB]


def _credential_present(location, cache):
    """True when this one location holds a non-empty credential. Presence only, never a value."""
    addon_id, setting_id = location
    if addon_id == GEARS_DB:
        return _gears_settings(cache).get(setting_id, False)
    text = _settings_xml_text(addon_id, cache)
    if not text:
        return False
    # Kodi writes an unset setting as a self-closing element (`<setting id="x" default="true" />`)
    # and a set one with a body, so only the second form can match. The attribute order varies
    # between add-ons - The Crew writes `default` before `id` - hence [^>]* on both sides.
    match = re.search(r'<setting[^>]*\bid="%s"[^>]*>([^<]*)</setting>' % re.escape(setting_id),
                      text)
    return bool(match and match.group(1).strip())


def signin_state():
    """([signed in], [not signed in]) service names, in SIGNIN_SERVICES order. Names only.

    Nothing here returns, logs or stores a credential VALUE - every path collapses to a bool at
    the point of reading. kodi.log gets pasted into forums.

    Not cached across calls, deliberately: the cost is four small files and one sqlite read, and
    a cache would keep saying "not signed in" after the owner signed in until Kodi restarted -
    which is precisely the moment they would open this screen to check.
    """
    cache = {}
    yes, no = [], []
    for name, locations in SIGNIN_SERVICES:
        target = yes if any(_credential_present(loc, cache) for loc in locations) else no
        target.append(name)
    return yes, no


def logins_row():
    """The bottom row of the version block: what this device is actually signed into.

    'Signed in - Trakt · Premiumize' showing only actively connected services.
    """
    yes, _ = signin_state()
    if not yes:
        return 'Signed in - None'
    return format_row('Signed in', ' · '.join(yes))


def component_rows():
    """[(label, stamp)] for each component - 'Wizard v5.2.0' plus when it last landed here."""
    rows = []
    for label, resolve in COMPONENTS:
        addon_id = resolve()
        ver = addon_disk_version(addon_id) if addon_id else None
        if ver:
            rows.append(('%s v%s' % (label, ver), addon_updated_stamp(addon_id)))
    return rows


def device_rows():
    """Every line of the version block, in the owner's order:

        StarWave v4  - Aug 29, 2026 at 3:11 PM EDT
        Wizard v5.2.0 - Aug 29, 2026 at 6:12 PM EDT
        Skin v4.6.0  - Aug 20, 2026 at 9:02 AM EDT
        Signed in    - Trakt · Real-Debrid · Premiumize

    Build first (what the device IS), then each component, then what it is signed into. The
    first three go through format_row(), so their dates cannot diverge; the last is the one row
    that answers a question a date cannot - see logins_row().
    """
    rows = []
    ver = build_version()
    rec = applied_record()
    # The record only describes the build it recorded. If version.txt has moved on since, the
    # record's moment does not belong to this build and is not attached to it.
    stamp = record_stamp(rec) if rec and rec.get('version') == ver else ''
    if ver:
        rows.append(format_row(ver, stamp))
    rows.extend(format_row(label, when) for label, when in component_rows())
    # Unconditional, unlike the row it replaced: sign-in state is read from the device itself,
    # so it is knowable even when no install was ever recorded here.
    rows.append(logins_row())
    return rows


def version_summary():
    """A trustworthy one-line answer to 'which build am I on, and when did it apply?'."""
    ver = build_version()
    if not ver:
        return 'No StarWave build detected on this device.'
    rec = applied_record()
    stamp = record_stamp(rec)
    if rec and rec.get('version') == ver and stamp:
        # Same shape as the version screen's build row, through the same formatter, so the
        # one-line header and the four-row block can never word the same fact differently.
        return format_row(ver, stamp)
    # version.txt present but no matching record (installed before this wizard, or by hand)
    return '%s (installed)' % ver


def component_summary():
    """Skin and wizard versions for the ONE-LINE menu header - versions only, no timestamps.

    Separate from the build version on purpose: the build is the whole payload, the skin and the
    wizard are single add-ons inside it that now update themselves independently of it. Reporting
    one as the other would make the number move when no build was ever installed.

    The header is a single list-item label, so the dated rows live on the version screen
    (device_rows()) and this stays short. Both carry a lowercase 'v' so a bare number can never
    be mistaken for anything but a version.
    """
    return ' \u00b7 '.join(label for label, _stamp in component_rows())


def get_build_version():
    """Return short build version e.g. 'v4' or 'V4' for Window(Home) property."""
    rec = applied_record()
    ver = (rec.get('version') if rec else None) or build_version()
    if not ver:
        return ''
    if ver.lower().startswith('starwave '):
        ver = ver[9:].strip()
    return ver


def get_wizard_version():
    """Return wizard version e.g. 'v4.14.0' for Window(Home) property."""
    try:
        ver = xbmcaddon.Addon(ADDON_ID).getAddonInfo('version') or ''
    except Exception:
        ver = ''
    if ver and not ver.lower().startswith('v'):
        ver = 'v' + ver
    return ver


def set_window_properties():
    """Set Window(10000) properties for Home skin rules: StarWave.BuildVersion and StarWave.WizardVersion."""
    try:
        import xbmcgui
        b_ver = get_build_version()
        w_ver = get_wizard_version()
        win = xbmcgui.Window(10000)
        win.setProperty('StarWave.BuildVersion', b_ver)
        win.setProperty('StarWave.WizardVersion', w_ver)
        log('set window properties: StarWave.BuildVersion=%s, StarWave.WizardVersion=%s' % (b_ver, w_ver))
    except Exception as exc:  # noqa: BLE001
        log('could not set window properties: %s' % exc, xbmc.LOGWARNING)


def force_menu_rebuild():
    """Make the skin regenerate its menu from the .DATA.xml on next start.

    Two files together: the hash, and the *generated* includes it guards. Deleting the hash
    alone is not enough - if Kodi lingers before it exits, skinshortcuts re-hashes the stale
    includes and blesses them. Deleting the generated includes as well leaves nothing to bless,
    so the rebuild from the (correct, preserved) .DATA.xml is the only possible outcome.
    """
    removed = 0
    if os.path.isdir(SKINSHORTCUTS_DIR):
        for name in os.listdir(SKINSHORTCUTS_DIR):
            if name.endswith('.hash'):
                try:
                    os.remove(os.path.join(SKINSHORTCUTS_DIR, name))
                    removed += 1
                except OSError as exc:
                    log('could not remove %s: %s' % (name, exc), xbmc.LOGWARNING)

    # The generated menu lives at addons/<skin>/<res>/script-skinshortcuts-includes.xml.
    if os.path.isdir(ADDONS_DIR):
        for entry in os.listdir(ADDONS_DIR):
            if not entry.startswith('skin.'):
                continue
            skin_dir = os.path.join(ADDONS_DIR, entry)
            for res in os.listdir(skin_dir) if os.path.isdir(skin_dir) else ():
                inc = os.path.join(skin_dir, res, 'script-skinshortcuts-includes.xml')
                if os.path.isfile(inc):
                    try:
                        os.remove(inc)
                        removed += 1
                    except OSError as exc:
                        log('could not remove %s: %s' % (inc, exc), xbmc.LOGWARNING)

    if removed:
        log('cleared %d menu file(s) so the skin rebuilds from its .DATA.xml' % removed)


def force_arctic_fuse_rebuild():
    """Make Arctic Fuse 3 regenerate its template includes from script.skinvariables.

    1. Executes RunScript(script.skinvariables,action=buildtemplate,force=True) inside Kodi.
    2. Blanks script-skinvariables-generator-hash in skin.arctic.fuse.3/settings.xml so if
       Kodi restarts before/without generating a fresh file, skinvariables rebuilds on next boot.
    Guarded to be a no-op when skin.arctic.fuse.3 is not installed.
    """
    af_dir = os.path.join(ADDONS_DIR, 'skin.arctic.fuse.3')
    if not os.path.isdir(af_dir) and not addon_disk_version('skin.arctic.fuse.3'):
        return

    # Blank the hash in settings.xml so next startup rebuilds if builtin does not produce fresh includes
    af_settings = os.path.join(HOME, 'userdata', 'addon_data', 'skin.arctic.fuse.3', 'settings.xml')
    if os.path.exists(af_settings):
        try:
            tree = ET.parse(af_settings)
            root = tree.getroot()
            changed = False
            for s in root.findall('setting'):
                if (s.get('id') or '').lower() == 'script-skinvariables-generator-hash':
                    if s.text:
                        s.text = ''
                        changed = True
            if changed:
                af_tmp = af_settings + '.tmp.%d' % os.getpid()
                try:
                    tree.write(af_tmp, encoding='utf-8', xml_declaration=True)
                    os.replace(af_tmp, af_settings)
                finally:
                    if os.path.exists(af_tmp):
                        try:
                            os.remove(af_tmp)
                        except OSError:
                            pass
                log('blanked script-skinvariables-generator-hash in settings.xml')
        except Exception as exc:  # noqa: BLE001
            log('could not blank arctic fuse hash: %s' % exc, xbmc.LOGWARNING)

    # Issue the real builtin to trigger rebuild immediately (no template parameter)
    xbmc.executebuiltin('RunScript(script.skinvariables,action=buildtemplate,force=True)')
    log('requested Arctic Fuse menu rebuild via script.skinvariables')


def get_active_skin():
    """Return the currently active skin id (e.g. 'skin.arctic.fuse.3') or None."""
    try:
        r = _rpc('Settings.GetSettingValue', {'setting': 'lookandfeel.skin'})
        val = r.get('result', {}).get('value')
        if val:
            return str(val).strip()
    except Exception as exc:  # noqa: BLE001
        log('could not read active skin via JSON-RPC: %s' % exc, xbmc.LOGWARNING)

    if os.path.exists(GUISETTINGS):
        try:
            with open(GUISETTINGS, 'r', encoding='utf-8') as fh:
                val = _gui_read(fh.read(), 'lookandfeel.skin')
                if val:
                    return str(val).strip()
        except Exception as exc:  # noqa: BLE001
            log('could not read active skin from guisettings.xml: %s' % exc, xbmc.LOGWARNING)

    return None


def set_skin_on_disk(skin_id):
    """Write lookandfeel.skin straight into guisettings.xml.

    Deliberately not done through JSON-RPC. Setting it on a running Kodi swaps the skin
    live, which raises the "Keep this skin?" prompt and, on Android, has been seen to
    background the app until the system reclaims it. Writing the file and hard-exiting is
    deterministic: the change is already on disk, and Kodi comes up on the new skin.
    """
    if not os.path.exists(GUISETTINGS):
        raise IOError('guisettings.xml not found')
    with open(GUISETTINGS, 'r', encoding='utf-8') as fh:
        text = fh.read()
    new, n = re.subn(r'(<setting id="lookandfeel\.skin">)[^<]*(</setting>)',
                     r'\g<1>%s\g<2>' % skin_id, text)
    if not n:
        raise IOError('lookandfeel.skin not present in guisettings.xml')
    with open(GUISETTINGS, 'w', encoding='utf-8') as fh:
        fh.write(new)
    log('skin set to %s in guisettings.xml' % skin_id)


def _kill_kodi():
    """Hard kill the Kodi process immediately to prevent background thread deadlocks / zombies."""
    pid = os.getpid()
    log('terminating Kodi PID %s' % pid)
    try:
        import signal
        if hasattr(signal, 'SIGKILL'):
            os.kill(pid, signal.SIGKILL)
    except Exception as exc:
        log('os.kill failed: %s' % exc)
    try:
        if sys.platform.startswith('linux') or sys.platform == 'darwin':
            os.system('kill -9 %d 2>/dev/null' % pid)
        elif sys.platform == 'win32':
            os.system('taskkill /F /PID %d 2>nul' % pid)
    except Exception:
        pass
    os._exit(1)


def _finish(message, tail=''):
    xbmcgui.Dialog().ok(
        ADDON_NAME,
        'Installation Complete!\n\n%s\n\nKodi will now close so your new setup can load.\n\nReopen Kodi to start StarWave.%s' % (message, tail),
    )
    # Hard exit on purpose. A normal Quit() makes Kodi save its in-memory settings on the
    # way out, which would overwrite the configuration just written.
    log('done, hard-exiting so Kodi cannot rewrite userdata')
    try:
        xbmc.executebuiltin('InhibitIdleShutdown(true)')
    except Exception:
        pass
    _kill_kodi()


# ----------------------------------------------------------------------------- builds


def _apply(build, update):
    flatpak_after = False
    tuned = []
    menu_lines = []
    skip_ids = () if is_android() else ANDROID_ONLY
    # Never let the build's bundled copy of the wizard overwrite the one that is running. The
    # payload carries whatever wizard version it was captured with (an old build shipped 4.0.0),
    # so extracting it downgrades a device that updated the wizard from the repository - and
    # swaps this add-on's own code out mid-run. The repository owns the wizard's version. This
    # id is added to the *extraction* skip only, NOT to drop_from_db, so the wizard stays
    # registered and enabled.
    extract_skip = tuple(skip_ids) + (ADDON_ID,)
    dialog = xbmcgui.DialogProgress()
    dialog.create(ADDON_NAME, 'Starting')
    _cleanup_temp()

    try:
        saved_gh_token = gh_token()
        saved_gh_repo = gh_repo()
        token = saved_gh_token if (build.get('personal') or build.get('auth')) else None
        if not download(build['url'], TEMP_ZIP, dialog, build['name'], token=token):
            dialog.close()
            _cleanup_temp()
            notify('Cancelled')
            return

        dialog.update(0, 'Installing')
        if not extract(TEMP_ZIP, HOME, dialog, extract_skip, preserve=update):
            dialog.close()
            _cleanup_temp()
            xbmcgui.Dialog().ok(
                ADDON_NAME,
                'Cancelled part-way through installing, so this Kodi is now a mix of the old '
                'setup and the new one.\n\nRun the wizard again and let it finish.',
            )
            return

        dialog.update(100, 'Tidying up')
        build_ids = build_addon_ids(TEMP_ZIP, extract_skip)
        if update:
            # extract_skip (not skip_ids) so the wizard is left out of the merge too - its DB
            # rows belong to the repository-installed copy, not the build's.
            merge_installed(build_ids)
        else:
            dialog.update(100, 'Resetting to defaults')
            wipe_to_build(TEMP_ZIP, build_ids, keep_gh_token=saved_gh_token, keep_gh_repo=saved_gh_repo)
            try:
                set_skin_on_disk('skin.arctic.fuse.3')
            except Exception as exc:
                log('could not set default skin to arctic fuse on disk: %s' % exc, xbmc.LOGWARNING)
        drop_from_db(skip_ids)
        clear_packages()
        # Must precede force_menu_rebuild(): the rebuild regenerates the menu FROM these files.
        menu_lines = sync_menu_icons()
        force_menu_rebuild()
        force_arctic_fuse_rebuild()
        write_applied_record('update' if update else 'fresh')
        set_window_properties()
        # Fixes that cannot ride the payload, applied by detection on every install. The two
        # display settings are stripped on capture by design, and the Gears scraper switch
        # lives in a .db that Update preserves - see tune_this_device / fix_gears_scrapers.
        # on_disk=True: the hard exit below skips Kodi's own settings write.
        sly_lines, _ = ensure_slyguy()
        guide_lines = ensure_iptv_guide()
        sports_lines = ensure_canonical_sports(on_disk=True)
        af_lock_lines = ensure_arctic_fuse_update_lock()
        af_patch_lines = ensure_arctic_fuse_patches()
        tuned = menu_lines + tune_this_device(on_disk=True) + fix_gears_scrapers() + sly_lines + guide_lines + sports_lines + af_lock_lines + af_patch_lines
        # SteamOS (Steam Deck, Steam Machine) or any Flatpak install: do the whole live-stream
        # fix automatically. The owner should never have to find the button on a device whose
        # platform we can already identify. Non-Android gets it too, because that is where
        # inputstream.adaptive has to be fetched from Kodi's own repository - the build's copy
        # is an Android binary and is skipped.
        flatpak_after = is_flatpak()
        if flatpak_after or is_steamos() or not is_android():
            tuned += live_fix_kodi_side()
        _cleanup_temp()
        dialog.close()

    except Exception as exc:  # noqa: BLE001 - surface anything that goes wrong to the user
        dialog.close()
        _cleanup_temp()
        log('apply failed: %s' % exc, xbmc.LOGERROR)
        xbmcgui.Dialog().ok(
            ADDON_NAME,
            'The install did not finish.\n\n%s\n\nYour Kodi has not been fully changed. Check '
            'your connection and try again.' % exc,
        )
        return

    tail = ''
    if skip_ids:
        tail = (
            '\n\nTwo add-ons were skipped because this build carries the Android versions and '
            'they cannot run here: %s. Kodi\'s own copies are untouched. If streams will not '
            'play, install InputStream Adaptive from the Kodi Add-on repository.'
            % ', '.join(skip_ids)
        )
    if flatpak_after and flatpak_fix_applied():
        # Already done on this device - say so in one line and move on. Re-showing the command
        # every install trains the owner to dismiss the screen without reading it.
        tail += ('\n\nLive streams: already set up on this device (the sandbox fix is in '
                 'place), and the Kodi-side settings were re-checked.')
    elif flatpak_after:
        # A Steam Deck / Flatpak install that has NOT had the host command run: the Kodi-side
        # live fix already ran; hand over the one host command it cannot run itself.
        xbmcgui.Dialog().ok(
            ADDON_NAME,
            'This is a Steam Deck / Flatpak install, so live streams need one command run '
            'outside Kodi. The Kodi side is already done. The command is on the next screen.')
        xbmcgui.Dialog().textviewer(ADDON_NAME, flatpak_instructions())
        tail += ('\n\nLive streams: the Kodi-side fix ran automatically. Run the one Konsole '
                 'command shown a moment ago, once, for encrypted streams to authenticate.')

    if tuned:
        # Say what was changed for this specific device, so a silent behaviour change never
        # looks like the build breaking something, and name the platform that was detected.
        what_device = ('SteamOS' if is_steamos() else
                       'Flatpak' if flatpak_after else
                       'Android' if is_android() else 'this device')
        tail += '\n\nTuned for %s:\n- ' % what_device + '\n- '.join(tuned)

    what = 'updated - your settings and logins were kept' if update else 'installed'
    _finish('%s is %s.\n\nThis device is now on: %s' % (build['name'], what, version_summary()),
            tail)


def do_build(build_id, update):
    build = next((b for b in all_builds() if b['id'] == build_id), None)
    if not build:
        return notify('That build is no longer published')

    has_skin = os.path.isdir(os.path.join(HOME, 'addons', 'skin.NTVaura')) or os.path.isdir(os.path.join(HOME, 'addons', 'skin.arctic.fuse.3'))
    if update and not has_skin:
        xbmcgui.Dialog().ok(
            ADDON_NAME,
            'No StarWave install was found on this Kodi, so there are no settings to keep.\n\n'
            'Use Fresh Install instead.',
        )
        return

    if update:
        prompt = ('Update brings %s up to the current build. Your Kodi settings, sources, '
                  'favourites and add-on logins are kept.' % build['name'])
        yes = 'Update'
    else:
        prompt = ('Fresh Install wipes this device back to %s and nothing else - add-ons you '
                  'installed yourself, all settings and every saved login are removed, and your '
                  'saved GitHub token is cleared too. Use it to start clean or hand the device '
                  'on. To keep your setup, choose Update instead.' % build['name'])
        yes = 'Wipe & install'

    if xbmcgui.Dialog().yesno(ADDON_NAME, prompt + '\n\nKodi will close when it finishes. '
                              'Continue?', nolabel='Cancel', yeslabel=yes):
        _apply(build, update)


# ----------------------------------------------------------------------------- layouts


def do_layout(layout_id):
    _, layouts = get_manifest()
    layout = next((l for l in layouts if l['id'] == layout_id), None)
    if not layout:
        return notify('That layout is no longer published')

    skin_id = layout['skin']
    if xbmc.getSkinDir() == skin_id and not layout.get('config'):
        return notify('%s is already in use' % layout['name'])

    installed = os.path.isdir(os.path.join(HOME, 'addons', skin_id))
    if not installed:
        ok = xbmcgui.Dialog().yesno(
            ADDON_NAME,
            '%s is not installed yet. It will be downloaded from the StarWave repository '
            'first.\n\nYour settings and logins are not affected either way. Continue?'
            % layout['name'],
            nolabel='Cancel', yeslabel='Install',
        )
        if not ok:
            return
        xbmc.executebuiltin('InstallAddon(%s)' % skin_id, True)
        if not os.path.isdir(os.path.join(HOME, 'addons', skin_id)):
            xbmcgui.Dialog().ok(
                ADDON_NAME,
                'Could not install %s.\n\nCheck that the StarWave repository is installed '
                'and that you are online, then try again.' % layout['name'],
            )
            return

    dialog = xbmcgui.DialogProgress()
    dialog.create(ADDON_NAME, 'Applying %s' % layout['name'])
    cfg_zip = os.path.join(TEMP_DIR, 'starwave-layout.zip')
    try:
        if layout.get('config'):
            if download(layout['config'], cfg_zip, dialog, '%s settings' % layout['name']):
                extract(cfg_zip, HOME, dialog, only_missing=False)
            try:
                os.remove(cfg_zip)
            except OSError:
                pass
        set_skin_on_disk(skin_id)
        ensure_iptv_guide()
        if skin_id == 'skin.arctic.fuse.3':
            ensure_arctic_fuse_update_lock()
            ensure_arctic_fuse_patches()
            ensure_canonical_sports(on_disk=True)
        dialog.close()
    except Exception as exc:  # noqa: BLE001
        dialog.close()
        log('layout switch failed: %s' % exc, xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, 'Could not switch layout.\n\n%s' % exc)
        return

    _finish('%s is ready.\n\nYour settings, sources and logins were not touched.'
            % layout['name'])


def reset_device_settings():
    """Drop machine-bound settings from guisettings.xml. Returns the ids removed."""
    if not os.path.exists(GUISETTINGS):
        raise IOError('guisettings.xml not found')
    text = open(GUISETTINGS, 'r', encoding='utf-8').read()
    removed = []

    def repl(m):
        sid = m.group(1)
        if sid.startswith(DEVICE_PREFIXES) or sid in DEVICE_EXACT:
            removed.append(sid)
            return ''
        return m.group(0)

    new = re.sub(r'[ \t]*<setting id="([^"]+)"([^>]*)>([^<]*)</setting>\n?', repl, text)
    if removed:
        with open(GUISETTINGS, 'w', encoding='utf-8') as fh:
            fh.write(new)
    return removed


def do_reset_device():
    ok = xbmcgui.Dialog().yesno(
        ADDON_NAME,
        'Reset this device\'s audio output, passthrough, display resolution and refresh-rate '
        'handling to Kodi\'s defaults?\n\n'
        'Your skin, menus, add-on settings and logins are not affected. Kodi will close so it '
        'can detect this device\'s hardware fresh.',
        nolabel='Cancel', yeslabel='Reset',
    )
    if not ok:
        return
    try:
        removed = reset_device_settings()
    except Exception as exc:  # noqa: BLE001
        log('device reset failed: %s' % exc, xbmc.LOGERROR)
        return xbmcgui.Dialog().ok(ADDON_NAME, 'Could not reset the settings.\n\n%s' % exc)

    if not removed:
        return xbmcgui.Dialog().ok(
            ADDON_NAME,
            'Nothing to reset -  this device is already on Kodi\'s defaults for audio and '
            'display.')

    log('reset %d device settings: %s' % (len(removed), ', '.join(removed)))
    audio = len([r for r in removed if r.startswith('audiooutput.')])
    _finish('Reset %d settings for this device, %d of them audio.\n\nKodi will detect your '
            'audio and display again on the next start. If this device feeds a receiver, turn '
            'passthrough back on in Settings > System > Audio once you can hear sound.'
            % (len(removed), audio))


def do_fresh_wipe():
    """Reset Kodi to factory clean state while preserving the StarWave Wizard and File Manager sources."""
    ok = xbmcgui.Dialog().yesno(
        ADDON_NAME,
        'Perform a complete Fresh Wipe (Factory Reset)?\n\n'
        'This will erase the active build, custom skins, and add-ons, resetting Kodi back to default Estuary.\n\n'
        'Your File Manager sources (including StarWave) and the StarWave Wizard will be kept so you can '
        'immediately reinstall a fresh build upon relaunching Kodi.\n\n'
        'Kodi will close when finished. Are you sure you want to proceed?',
        nolabel='Cancel', yeslabel='Erase & Reset',
    )
    if not ok:
        return

    dialog = xbmcgui.DialogProgress()
    dialog.create(ADDON_NAME, 'Performing fresh wipe...')

    # 1. Clean userdata/addon_data except this wizard and repo
    addon_data = os.path.join(HOME, 'userdata', 'addon_data')
    if os.path.isdir(addon_data):
        for item in os.listdir(addon_data):
            if item in ('plugin.program.starwave.wizard', 'repository.starwave'):
                continue
            path = os.path.join(addon_data, item)
            try:
                if os.path.isdir(path):
                    shutil.rmtree(path, ignore_errors=True)
                else:
                    os.remove(path)
            except Exception:
                pass

    # 2. Clean userdata/Database
    db_dir = os.path.join(HOME, 'userdata', 'Database')
    if os.path.isdir(db_dir):
        for f in os.listdir(db_dir):
            try:
                os.remove(os.path.join(db_dir, f))
            except Exception:
                pass

    # 3. Clean addons directory (keep core skins, repository and wizard)
    addons_dir = os.path.join(HOME, 'addons')
    keep_addons = {
        'plugin.program.starwave.wizard', 'repository.starwave',
        'skin.estuary', 'packages'
    }
    if os.path.isdir(addons_dir):
        for item in os.listdir(addons_dir):
            if item in keep_addons or item.startswith('resource.language.'):
                continue
            path = os.path.join(addons_dir, item)
            try:
                if os.path.isdir(path):
                    shutil.rmtree(path, ignore_errors=True)
                else:
                    os.remove(path)
            except Exception:
                pass

    # 4. Clean configuration XMLs (preserve sources.xml for File Manager shortcuts)
    for xml_file in ('guisettings.xml', 'favourites.xml', 'profiles.xml', 'passwords.xml'):
        p = os.path.join(HOME, 'userdata', xml_file)
        if os.path.exists(p):
            try:
                os.remove(p)
            except Exception:
                pass

    # 5. Re-seed wizard and repository in fresh Addons33.db so they stay active immediately
    try:
        merge_installed(['plugin.program.starwave.wizard', 'repository.starwave'])
    except Exception as exc:
        log('could not re-seed wizard and repo in fresh wipe: %s' % exc, xbmc.LOGWARNING)

    dialog.close()
    _finish('Fresh wipe complete. Kodi will now close.\n\nReopen Kodi to start with a clean installation.')



# ----------------------------------------------------------------------- fix live streams

# Turning these on/off is the whole Kodi-side fix. adaptive is the HLS/DASH engine live
# streams need; ffmpegdirect re-routes live HTTP through FFmpeg's pipe, which drops the
# scraped User-Agent/Referer the stream hosts require - so it must be *off*.
LIVE_ENABLE = ('inputstream.adaptive', 'pvr.iptvsimple')
LIVE_DISABLE = ('inputstream.ffmpegdirect',)

# The Crew's general resolver/connection cache. Deliberately NOT settings.db (its config and
# logins), traktsync.db, bookmarks.db (resume points) or meta.*.db (rebuildable but heavy).
CREW_CACHE = ('userdata/addon_data/plugin.video.thecrew/cache.db',)

# The environment variable that lets a sandboxed Flatpak see the host CA certificates, so
# HTTPS/HLS handshakes to the stream hosts authenticate. Value found to work on SteamOS.
FLATPAK_ENV = 'SSL_CERT_DIR=/etc/ssl/certs'


def is_flatpak():
    """True when Kodi is running inside a Flatpak sandbox."""
    return os.path.exists('/.flatpak-info') or bool(os.environ.get('FLATPAK_ID'))


def flatpak_app_id():
    """The Flatpak application id, read at runtime so it is always correct.

    Falls back to the standard id for a Flatpak Kodi if the variable is somehow absent.
    """
    return os.environ.get('FLATPAK_ID') or 'tv.kodi.Kodi'


def flatpak_fix_applied():
    """True when the host-side sandbox fix is already in place.

    The load-bearing half of the Flatpak fix is SSL_CERT_DIR, and a Flatpak override - whether
    set with `flatpak override` or through Flatseal - lands in the sandbox as a plain environment
    variable. So the app can read it and know, rather than nagging on every single install about
    a command the owner ran weeks ago.
    """
    d = os.environ.get('SSL_CERT_DIR', '').strip()
    return d == '/etc/ssl/certs'


def flatpak_command():
    """The single host command that fixes encrypted-stream auth. Run once, in a terminal."""
    return ('flatpak override --user --env=%s --share=network --share=ipc %s'
            % (FLATPAK_ENV, flatpak_app_id()))


flatpak_override_cmd = flatpak_command


def is_addon_installed(addon_id):
    """True if addon is present on disk, registered in Addons33.db, or visible to Kodi."""
    try:
        xbmcaddon.Addon(addon_id)
        return True
    except Exception:  # noqa: BLE001
        pass
    try:
        if xbmc.getCondVisibility('System.HasAddon(%s)' % addon_id):
            return True
    except Exception:  # noqa: BLE001
        pass
    if os.path.exists(os.path.join(HOME, 'addons', addon_id)):
        return True
    addons_db = os.path.join(HOME, 'userdata', 'Database', 'Addons33.db')
    if os.path.exists(addons_db):
        try:
            con = sqlite3.connect(addons_db)
            row = con.execute('SELECT 1 FROM installed WHERE addonID = ?', (addon_id,)).fetchone()
            con.close()
            if row:
                return True
        except Exception:  # noqa: BLE001
            pass
    return False


def set_addon_enabled(addon_id, enabled):
    """Enable/disable an add-on via JSON-RPC, with Addons33.db fallback. Returns True if enabled, None if not installed."""
    if not is_addon_installed(addon_id):
        return None
    payload = json.dumps({
        'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.SetAddonEnabled',
        'params': {'addonid': addon_id, 'enabled': bool(enabled)},
    })
    ok = False
    try:
        raw = xbmc.executeJSONRPC(payload)
        res = json.loads(raw) if raw else {}
        if res.get('result') == 'OK':
            ok = True
    except Exception as exc:  # noqa: BLE001
        log('could not set %s enabled=%s via JSON-RPC: %s' % (addon_id, enabled, exc), xbmc.LOGWARNING)

    # Direct database fallback so disk state is immediately synced
    addons_db = os.path.join(HOME, 'userdata', 'Database', 'Addons33.db')
    if os.path.exists(addons_db):
        try:
            con = sqlite3.connect(addons_db)
            cur = con.cursor()
            cur.execute('UPDATE installed SET enabled = ? WHERE addonID = ?', (1 if enabled else 0, addon_id))
            if cur.rowcount > 0:
                con.commit()
                ok = True
            con.close()
        except Exception as exc:  # noqa: BLE001
            log('could not update %s in Addons33.db: %s' % (addon_id, exc), xbmc.LOGWARNING)

    return True if ok else False


def clear_crew_cache():
    """Delete The Crew's stream cache. Returns the number of files removed."""
    n = 0
    for rel in CREW_CACHE:
        path = os.path.join(HOME, rel.replace('/', os.sep))
        try:
            if os.path.exists(path):
                os.remove(path)
                n += 1
        except OSError as exc:
            log('could not clear %s: %s' % (rel, exc), xbmc.LOGWARNING)
    return n


DIALOG_LINE_BUDGET = 6      # measured on the Shield; past this the buttons draw over the text
DIALOG_COLS = 62            # characters per line in the skin's confirm dialog


def _dialog_lines(body):
    """How many lines the skin will actually render. Kodi markup takes no width."""
    import textwrap
    n = 0
    for para in body.split('\n'):
        para = re.sub(r'\[/?[A-Z]+[^\]]*\]', '', para)
        n += max(1, len(textwrap.wrap(para, DIALOG_COLS)))
    return n


def show_message(body, title=None):
    """Dialog.ok for short bodies, textviewer for anything taller.

    Dialog.ok does not scroll: past about six rendered lines the button grouplist draws ON TOP
    of the text, so the end of the message is simply unreadable. Seen on the Shield with the
    live-stream result, which runs to nine lines. textviewer scrolls, so it is always safe.
    """
    if _dialog_lines(body) > DIALOG_LINE_BUDGET:
        return xbmcgui.Dialog().textviewer(title or ADDON_NAME, body)
    return xbmcgui.Dialog().ok(title or ADDON_NAME, body)


def addon_disk_version(addon_id):
    """The version of the add-on, checked live and from disk."""
    path = os.path.join(HOME, 'addons', addon_id, 'addon.xml')
    try:
        with open(path, 'r', encoding='utf-8', errors='ignore') as fh:
            m = re.search(r'<addon\s+[^>]*id="%s"[^>]*version="([^"]+)"' % re.escape(addon_id),
                          fh.read())
            if m:
                return m.group(1)
    except Exception:  # noqa: BLE001
        pass
    if addon_id == ADDON_ID:
        try:
            local_path = os.path.join(os.path.dirname(__file__), 'addon.xml')
            if os.path.isfile(local_path):
                with open(local_path, 'r', encoding='utf-8', errors='ignore') as fh:
                    m = re.search(r'<addon\s+[^>]*id="%s"[^>]*version="([^"]+)"' % re.escape(addon_id),
                                  fh.read())
                    if m:
                        return m.group(1)
        except Exception:  # noqa: BLE001
            pass
    try:
        ver = xbmcaddon.Addon(addon_id).getAddonInfo('version')
        if ver:
            return ver
    except Exception:
        pass
    return None


skin_disk_version = addon_disk_version


# Files inside a skin zip that are NOT skin content: other add-ons generate them into the
# skin's folder from the device's own menu data. script.skinshortcuts writes the home menu,
# script.skinvariables writes Arctic Fuse's artwork variables. Whatever is packaged in the zip
# is a snapshot of some other machine's menu, so extracting it replaces the owner's menu with a
# stranger's. Measured on the Shield 2026-08-22: it wiped a freshly built 10-tile Settings row
# and put back a stale 5-tile one.
SKIN_GENERATED = ('script-skinshortcuts-includes', 'script-skinvariables')


def _is_generated(name):
    base = name.rsplit('/', 1)[-1]
    return base.startswith(SKIN_GENERATED)


def _vertuple(v):
    out = []
    for part in re.split(r'[.\-+~]', v or ''):
        out.append(int(part) if part.isdigit() else 0)
    return tuple(out)


def repo_addon_version(addon_id):
    """Version the StarWave repository is offering for an add-on, or None."""
    try:
        req = Request(BASE_URL + 'addons.xml', headers={'User-Agent': 'StarWave'})
        with urlopen(req, timeout=20) as r:
            xml = r.read().decode('utf-8', 'replace')
    except Exception as exc:  # noqa: BLE001 - repo closed or offline is normal
        log('could not read the repository index: %s' % exc)
        return None
    m = re.search(r'<addon\s+[^>]*id="%s"[^>]*?>' % re.escape(addon_id), xml)
    if not m:
        return None
    v = re.search(r'version="([^"]+)"', m.group(0))
    return v.group(1) if v else None


def ensure_skin_current():
    """Install a newer skin ourselves when Kodi will not.

    Kodi decides whether an add-on needs updating from its `addons` row in Addons33.db, and that
    row can disagree with the files on disk. Measured on the Shield 2026-08-22: row 4.3.0, files
    4.2.3. Kodi therefore believed it was current and never fetched the real 4.3.0, leaving a
    skin whose confirm dialog drew its buttons over the text.

    Neither `UpdateAddonRepos` nor `UpdateLocalAddons` repairs that - both were tried on the
    device and the row stayed wrong. Correcting the row means deleting it with Kodi stopped,
    which a service cannot do safely.

    So this bypasses Kodi's updater: compare the skin's addon.xml ON DISK against the version the
    repository offers and, if the repository is ahead, download and extract that add-on zip
    directly - the same download-and-extract the wizard already uses for builds. Kodi rereads
    addon.xml on the next start (`CAddonMgr::FindAddons`), so the new version takes effect then,
    regardless of what the stale row says.

    Returns a human line if a skin was installed, else None.
    """
    skin_id = xbmc.getSkinDir()
    if not skin_id:
        return None
    on_disk = addon_disk_version(skin_id)
    if not on_disk:
        return None
    offered = repo_addon_version(skin_id)
    if not offered or _vertuple(offered) <= _vertuple(on_disk):
        return None

    url = '%s%s/%s-%s.zip' % (BASE_URL, skin_id, skin_id, offered)
    dest = os.path.join(TEMP_DIR, '%s-%s.zip' % (skin_id, offered))
    log('skin on disk is %s, repository offers %s - fetching %s' % (on_disk, offered, url))
    try:
        req = Request(url, headers={'User-Agent': 'StarWave'})
        with urlopen(req, timeout=120) as r, open(dest, 'wb') as fh:
            shutil.copyfileobj(r, fh)
        import zipfile
        addons_dir = os.path.join(HOME, 'addons')
        with zipfile.ZipFile(dest) as zf:
            # The zip is rooted at <skin_id>/, which is exactly how it must land in addons/.
            # Everything except the generated menu files - see SKIN_GENERATED.
            members = [n for n in zf.namelist() if not _is_generated(n)]
            skipped = len(zf.namelist()) - len(members)
            zf.extractall(addons_dir, members)
            if skipped:
                log('kept %d generated menu file(s) this device already had' % skipped)
    except Exception as exc:  # noqa: BLE001
        log('could not install skin %s: %s' % (offered, exc), xbmc.LOGWARNING)
        return None
    finally:
        try:
            os.remove(dest)
        except Exception:  # noqa: BLE001
            pass

    now = addon_disk_version(skin_id)
    if now != offered:
        log('skin extract did not take (disk still %s)' % now, xbmc.LOGWARNING)
        return None
    log('skin %s installed on disk; active from the next start' % offered)
    return ('Updated the skin from %s to %s - Kodi had stopped offering it. Restart to see it.'
            % (on_disk, offered))


def ensure_arctic_fuse_settings():
    """Ensure Arctic Fuse 3 settings on disk land on In Progress widgets rather than empty spotlight."""
    af_settings = os.path.join(HOME, 'userdata', 'addon_data', 'skin.arctic.fuse.3', 'settings.xml')
    if not os.path.exists(af_settings):
        return None
    try:
        import xml.etree.ElementTree as ET
        tree = ET.parse(af_settings)
        root = tree.getroot()
        changed = False
        exempt_1101_keys = {
            'homeswitcher.1101.spotlight.target',
            'homeswitcher.1101.spotlight.path',
            'homeswitcher.1101.spotlight.label',
        }
        for s in root.findall('setting'):
            sid = s.get('id', '')
            if sid.lower() in exempt_1101_keys:
                continue
            if 'spotlight' in sid.lower() and ('target' in sid.lower() or 'path' in sid.lower() or 'label' in sid.lower()):
                if s.text:
                    s.text = ""
                    changed = True
        if changed:
            tree.write(af_settings, encoding='utf-8', xml_declaration=True)
            log('cleared dead spotlight settings from skin.arctic.fuse.3/settings.xml')
            return 'Arctic Fuse: default landing set to In Progress widgets'
    except Exception as exc:  # noqa: BLE001
        log('could not check arctic fuse settings: %s' % exc, xbmc.LOGWARNING)
    return None


SELF_UPDATE_THROTTLE = 86400  # 24 hours
SELF_UPDATE_TIMESTAMP = os.path.join(HOME, 'userdata', 'addon_data', ADDON_ID, 'self_update_last')


def addon_origin(addon_id):
    """Return the origin repository id for an add-on from Addons33.db, or None.

    Reads the `installed` table in userdata/Database/Addons33.db. A missing database, missing
    row, or empty origin value returns None, meaning origin cannot be determined (skip update).
    """
    if not os.path.exists(ADDONS_DB):
        return None
    try:
        con = sqlite3.connect(ADDONS_DB)
        try:
            cur = con.execute('SELECT origin FROM installed WHERE addonID = ?', (addon_id,))
            row = cur.fetchone()
            if row and row[0]:
                orig = str(row[0]).strip()
                return orig if orig else None
            return None
        finally:
            con.close()
    except Exception as exc:  # noqa: BLE001
        log('could not read origin for %s from database: %s' % (addon_id, exc), xbmc.LOGWARNING)
        return None


def repo_dirs(repo_id):
    """Parse addons/<repo_id>/addon.xml and return a list of directory definitions.

    Each entry is a dict with 'info' (addons.xml URL), 'datadir' (zip root URL), and optional
    'minversion' / 'maxversion' strings.
    """
    path = os.path.join(HOME, 'addons', repo_id, 'addon.xml')
    if not os.path.exists(path):
        return []
    try:
        tree = ET.parse(path)
        root = tree.getroot()
        dirs = []
        for ext in root.findall('extension'):
            if ext.get('point') == 'xbmc.addon.repository':
                dir_nodes = ext.findall('dir')
                if dir_nodes:
                    for d in dir_nodes:
                        info_node = d.find('info')
                        datadir_node = d.find('datadir')
                        if (info_node is not None and info_node.text and
                                datadir_node is not None and datadir_node.text):
                            dirs.append({
                                'info': info_node.text.strip(),
                                'datadir': datadir_node.text.strip(),
                                'minversion': d.get('minversion'),
                                'maxversion': d.get('maxversion'),
                            })
                else:
                    info_node = ext.find('info')
                    datadir_node = ext.find('datadir')
                    if (info_node is not None and info_node.text and
                            datadir_node is not None and datadir_node.text):
                        dirs.append({
                            'info': info_node.text.strip(),
                            'datadir': datadir_node.text.strip(),
                            'minversion': None,
                            'maxversion': None,
                        })
        return dirs
    except Exception as exc:  # noqa: BLE001
        log('could not parse repository addon.xml for %s: %s' % (repo_id, exc), xbmc.LOGWARNING)
        return []


def kodi_build_version():
    """Return the numeric Kodi build version string from System.BuildVersion, or None."""
    try:
        raw = xbmc.getInfoLabel('System.BuildVersion')
        m = re.search(r'^\s*(\d+(?:\.\d+)*)', raw or '')
        return m.group(1) if m else None
    except Exception:  # noqa: BLE001
        return None


def match_repo_dir(dirs):
    """Select the <dir> whose minversion/maxversion bracket contains this Kodi version.

    If Kodi version cannot be parsed, treats every <dir> as matching.
    If several match, returns the last matching entry.
    """
    if not dirs:
        return None
    kv = kodi_build_version()
    kv_tuple = _vertuple(kv) if kv else None

    matches = []
    for d in dirs:
        minv = d.get('minversion')
        maxv = d.get('maxversion')
        if kv_tuple is None:
            matches.append(d)
            continue
        if minv and kv_tuple < _vertuple(minv):
            continue
        if maxv and kv_tuple > _vertuple(maxv):
            continue
        matches.append(d)

    return matches[-1] if matches else None


# addons.xml fetched during one self-update run, keyed by url. Six add-ons resolved against
# seventeen repositories would otherwise be a hundred fetches; cleared at the start of every run.
_REPO_INDEX_CACHE = {}


def installed_repo_ids():
    """Every repository add-on present on disk. Used when an add-on has no recorded origin."""
    out = []
    try:
        for name in sorted(os.listdir(os.path.join(HOME, 'addons'))):
            if name.startswith('repository.') and os.path.exists(
                    os.path.join(HOME, 'addons', name, 'addon.xml')):
                out.append(name)
    except Exception:  # noqa: BLE001
        return []
    return out


def repo_offered_version(info_url, addon_id):
    """Fetch the repository addons.xml from info_url and return the offered version, or None.

    Handles gzipped content (either via .gz URL extension, Content-Encoding header, or gzip header
    bytes). Never raises.
    """
    if not info_url:
        return None
    if info_url in _REPO_INDEX_CACHE:
        xml = _REPO_INDEX_CACHE[info_url]
        if xml is None:
            return None
        return _version_from_index(xml, addon_id)
    try:
        req = Request(info_url, headers={
            'User-Agent': 'StarWave-Wizard',
            # gzip only: a server that honoured deflate would hand back bytes this cannot
            # decode, the version parse would find nothing, and the add-on would silently
            # never update again.
            'Accept-Encoding': 'gzip',
        })
        with urlopen(req, timeout=30) as r:
            raw = r.read()
            encoding = r.headers.get('Content-Encoding') if hasattr(r, 'headers') else None
            is_gzipped = (info_url.endswith('.gz') or
                          encoding == 'gzip' or
                          raw.startswith(b'\x1f\x8b'))
            if is_gzipped:
                try:
                    raw = gzip.decompress(raw)
                except Exception:  # noqa: BLE001
                    raw = gzip.GzipFile(fileobj=io.BytesIO(raw)).read()
            xml = raw.decode('utf-8', 'replace')
    except Exception as exc:  # noqa: BLE001 - repo closed, timeout or offline is normal
        log('could not read addons.xml from %s: %s' % (info_url, exc), xbmc.LOGWARNING)
        _REPO_INDEX_CACHE[info_url] = None
        return None

    _REPO_INDEX_CACHE[info_url] = xml
    return _version_from_index(xml, addon_id)


def _version_from_index(xml, addon_id):
    """Pull addon_id's version out of an addons.xml body, or None."""
    try:
        m = re.search(r'<addon\s+[^>]*id="%s"[^>]*?>' % re.escape(addon_id), xml)
        if not m:
            return None
        v = re.search(r'version="([^"]+)"', m.group(0))
        return v.group(1) if v else None
    except Exception:  # noqa: BLE001
        return None


def ensure_addon_current(addon_id):
    """Install a newer version of an add-on in SELF_UPDATE directly when Kodi will not.

    Bypasses Kodi's updater: resolves origin repository, finds matching directory, checks offered
    version, and downloads/extracts if offered version is strictly newer than disk version.

    Returns a human line if an add-on was installed, else None. Never raises.
    """
    if addon_id not in SELF_UPDATE:
        return None
    if addon_id == ADDON_ID or addon_id == xbmc.getSkinDir():
        return None
    if not is_android() and addon_id in ANDROID_ONLY:
        return None

    on_disk = addon_disk_version(addon_id)
    if not on_disk:
        return None

    # An add-on that arrived inside a StarWave build has NO recorded origin: merge_installed()
    # writes addonID/enabled/installDate and nothing else. Falling back to "ask every installed
    # repository" is therefore what makes this work at all on a device built from the payload -
    # which is most of them, and precisely where Kodi's own updater was already failing.
    repo_id = addon_origin(addon_id)
    candidates = [repo_id] if repo_id else installed_repo_ids()

    chosen = None
    offered = None
    for candidate in candidates:
        dirs = repo_dirs(candidate)
        if not dirs:
            continue
        d = match_repo_dir(dirs)
        if not d:
            continue
        v = repo_offered_version(d.get('info'), addon_id)
        if not v or _vertuple(v) <= _vertuple(on_disk):
            continue
        # More than one repository can carry the same add-on; take the newest on offer.
        if offered is None or _vertuple(v) > _vertuple(offered):
            chosen, offered = d, v

    if not chosen or not offered:
        return None

    datadir = chosen.get('datadir', '').rstrip('/')
    url = '%s/%s/%s-%s.zip' % (datadir, addon_id, addon_id, offered)
    dest = os.path.join(TEMP_DIR, '%s-%s.zip' % (addon_id, offered))
    log('%s on disk is %s, repository offers %s - fetching %s' % (addon_id, on_disk, offered, url))
    try:
        req = Request(url, headers={'User-Agent': 'StarWave-Wizard'})
        with urlopen(req, timeout=120) as r, open(dest, 'wb') as fh:
            shutil.copyfileobj(r, fh)
        import zipfile
        addons_dir = os.path.join(HOME, 'addons')
        with zipfile.ZipFile(dest) as zf:
            # Confine the extract to this add-on's own folder. The zip comes from a third-party
            # repository, and nothing else checks that its contents match the name on the tin -
            # a zip called plugin.video.umbrella-x.zip carrying skin.NTVaura/ paths would
            # otherwise overwrite the skin. (extractall already strips '..' and absolute paths;
            # this is the sibling-directory case it does not cover.)
            prefix = addon_id + '/'
            members = [n for n in zf.namelist()
                       if n.startswith(prefix) and not _is_generated(n)]
            if not members:
                log('%s zip contained nothing under %s - refusing it'
                    % (addon_id, prefix), xbmc.LOGWARNING)
                return None
            zf.extractall(addons_dir, members)
    except Exception as exc:  # noqa: BLE001
        log('could not install add-on %s: %s' % (addon_id, exc), xbmc.LOGWARNING)
        return None
    finally:
        try:
            if os.path.exists(dest):
                os.remove(dest)
        except Exception:  # noqa: BLE001
            pass

    now = addon_disk_version(addon_id)
    if now != offered:
        log('%s extract did not take (disk still %s)' % (addon_id, now), xbmc.LOGWARNING)
        return None

    log('%s %s installed on disk; active from the next start' % (addon_id, offered))
    return ('Updated %s from %s to %s - Kodi had stopped offering it. Restart to see it.'
            % (addon_id, on_disk, offered))


def ensure_addons_current(force=False):
    """Walk SELF_UPDATE and update add-ons directly when Kodi will not.

    Throttled to run at most once every 24 hours. Writes timestamp on every run.
    """
    _REPO_INDEX_CACHE.clear()
    now = time.time()
    if not force:
        try:
            if os.path.exists(SELF_UPDATE_TIMESTAMP):
                with open(SELF_UPDATE_TIMESTAMP, 'r', encoding='utf-8') as fh:
                    last_run = float(fh.read().strip())
                    if now - last_run < SELF_UPDATE_THROTTLE:
                        return []
        except Exception:  # noqa: BLE001
            pass

    try:
        os.makedirs(os.path.dirname(SELF_UPDATE_TIMESTAMP), exist_ok=True)
        with open(SELF_UPDATE_TIMESTAMP, 'w', encoding='utf-8') as fh:
            fh.write(str(now))
    except Exception as exc:  # noqa: BLE001
        log('could not write self-update timestamp: %s' % exc, xbmc.LOGWARNING)

    results = []
    for addon_id in SELF_UPDATE:
        try:
            line = ensure_addon_current(addon_id)
            if line:
                results.append(line)
        except Exception as exc:  # noqa: BLE001
            log('self-update error on %s: %s' % (addon_id, exc), xbmc.LOGWARNING)

    return results


def is_steamos():
    """True on SteamOS (Steam Deck, Steam Machine). Inside a Flatpak sandbox /etc/os-release is
    the RUNTIME's, not the host's - Flatpak exposes the real one at /run/host/os-release."""
    for path in ('/run/host/os-release', '/etc/os-release'):
        try:
            with open(path, 'r', encoding='utf-8', errors='ignore') as fh:
                if 'steamos' in fh.read().lower():
                    return True
        except Exception:  # noqa: BLE001
            continue
    return os.path.exists('/etc/steamos-release')


def ensure_addon(addon_id, timeout=15):
    """Make sure an add-on is present, installing it from Kodi's own repository if not.

    This is what a fresh non-Android install needs. The build ships ANDROID_ONLY binaries and
    the wizard skips them off-Android, so a brand new Steam Deck or Steam Machine can end up
    with NO inputstream.adaptive at all - and then live streams simply do not play, with the
    old code reporting a cheerful "not installed, skipped".

    Returns 'present', 'installed', or 'failed'.
    """
    if os.path.isdir(os.path.join(HOME, 'addons', addon_id)):
        try:
            merge_installed([addon_id])
            set_addon_enabled(addon_id, True)
        except Exception:
            pass
        return 'present'
    try:
        xbmcaddon.Addon(addon_id)
        return 'present'
    except Exception:  # noqa: BLE001 - not installed
        pass
    log('%s is missing; installing it from the Kodi repository' % addon_id)
    xbmc.executebuiltin('InstallAddon(%s)' % addon_id)
    monitor = xbmc.Monitor()
    waited = 0
    while waited < timeout:
        if monitor.waitForAbort(3):
            break
        waited += 3
        try:
            xbmcaddon.Addon(addon_id)
            log('%s installed after %ds' % (addon_id, waited))
            return 'installed'
        except Exception:  # noqa: BLE001
            continue
    log('%s could not be installed' % addon_id, xbmc.LOGWARNING)
    return 'failed'


SLYGUY_REPO_ID = 'repository.slyguy'
SLYGUY_REPO_URL = 'https://slyguy.uk/.repo/repository.slyguy/repository.slyguy/repository.slyguy-0.0.9.zip'
SLYGUY_MAX_ZIP_BYTES = 20 * 1024 * 1024
SLYGUY_CHANNEL_ADDONS = (
    'slyguy.pluto.tv.provider',
    'slyguy.samsung.tv.plus',
    'slyguy.roku',
    'plugin.program.iptv.merge',
)

IPTV_MERGE_ID = 'plugin.program.iptv.merge'
PVR_IPTVSIMPLE_ID = 'pvr.iptvsimple'
STARWAVE_CHANNELS_URL = 'https://strfck3r.github.io/starwave/iptv/channels.m3u8'

# THE GUIDE COMES FROM A RELEASE ASSET, NOT FROM PAGES.
#
# The Pages copy is a file COMMITTED to the public repo every three hours, so every refresh
# adds ~1.5 MiB of permanent git history to a repository three televisions pull from. The
# Release asset at a fixed tag is REPLACED in place and lives outside the git object
# database. Same host, same TLS, no new credential; see adr/003-epg-release-asset.md.
#
# The URL 302-redirects to a short-lived signed blob URL on release-assets.githubusercontent.com
# (verified 2026-09-05 by HEAD against a public release asset). urlopen() below follows
# redirects by default, so the seeding call needs no change. Whether IPTV Merge's own fetch
# follows it is NOT verifiable from this repo - it vendors no copy of the add-on - which is
# one of the reasons the Pages copy keeps being published until a device is observed on this
# URL. See adr/003, "When phase 3 may be taken".
STARWAVE_EPG_URL = 'https://github.com/strfck3r/starwave/releases/download/epg-current/epg.xml.gz'

# SUPERSEDED EPG SOURCE URLS - retired from a device's IPTV Merge database on EVERY pass.
#
# The seeding below has always been add-only: it asks "is MY url present?" and inserts when it
# is not. Change the constant and that logic is silently wrong on every device that already
# has the old row - it ADDS the new source and LEAVES the old one enabled, so IPTV Merge
# merges the same 800 channels twice, and the dead URL stays behind to fail forever once the
# Pages copy stops being written. Same asymmetry that made the 12h merge interval only reach
# fresh installs.
#
# RETRACTED IN 5.8.1, and the retraction is kept rather than deleted. Through 5.8.0 the
# retirement was gated on the same fingerprint as the insert, and this comment called that a
# deliberate ONE-SHOT migration - "after the first run the new row exists, so this never arms
# again and a URL the owner deliberately re-adds later survives". That reasoning is withdrawn.
# What withdrew it was a measurement: on 2026-09-05 the Steam Machine was found carrying THREE
# enabled epg rows - the Samsung and Roku upstream feeds beside the StarWave asset - and its
# merged epg.xml was 55.2 MB against 15.9 MB on both the Shield and the Deck. The gate is
# precisely what let that stand. The Machine had acquired the new row while the old ones
# survived, so the retirement was disarmed before it ever ran on the rows that mattered.
#
# IT IS NOW A STANDING POLICY: the DELETE runs on every pass, ahead of the existence check.
# Two reasons, the first of which is the owner's and settles it:
#    1. "All devices need to be running the exact same setup" (owner, 2026-09-05). A fleet
#      whose EPG sources depend on which wizard version a given box happened to take first is
#      not one setup, it is three, and the difference is invisible from the sofa.
#    2. The two upstream feeds are superseded BY CONSTRUCTION, not by preference.
#      scripts/generate-epg.py builds the StarWave guide FROM those same Roku and Samsung
#      feeds and re-keys every channel id with a roku_/samsung_ prefix so it matches
#      channels.m3u8. The raw upstream entries therefore match NOTHING in the 770-channel
#      playlist - roughly 39 MB of dead weight parsed on every merge, not a second opinion
#      that a device might reasonably want.
#
# THE CONSEQUENCE IS INTENDED AND IS NOT A SIDE EFFECT: a superseded URL the owner re-adds by
# hand is removed again on the next boot. That is what uniformity costs, and it was accepted
# knowingly rather than discovered afterwards. Anyone who wants one of these feeds back takes
# it out of this tuple; there is no per-device escape hatch and that is the point.
#
# Scoped to source_type = 0 (TYPE_URL) so an ADDON row is never in range.
#
# SAMSUNG_EPG_URL / ROKU_EPG_URL are named rather than inlined because the names document what
# the URLs ARE. They were dead constants from 5.7.6 until 5.8.1 - defined, never referenced,
# and that is exactly why the Machine's two rows survived a retirement that was supposed to
# cover them.
SAMSUNG_EPG_URL = 'https://i.mjh.nz/SamsungTVPlus/us.xml.gz'
ROKU_EPG_URL = 'https://i.mjh.nz/Roku/all.xml.gz'
SUPERSEDED_EPG_URLS = (
     'https://strfck3r.github.io/starwave/iptv/epg.xml.gz',
    SAMSUNG_EPG_URL,
    ROKU_EPG_URL,
)

# THE GUIDE FRESHNESS BUDGET. Derived from the upstream horizon, not chosen as a round number.
#
# Samsung TV Plus publishes only ~4.6h of forward programme data and is 514 of the 770 playlist
# channels; Roku publishes ~69h. So the merged artifact's useful life is set by Samsung: roughly
# four and a half hours after the artifact is BUILT, two thirds of the guide goes dark.
#
# A device's guide is stale by (age of the artifact when it was pulled) + (how long the device
# then sits on it). The first term belongs to the supply side; this constant is the second. It
# is deliberately smaller than the horizon so the client's own contribution is never the reason
# the guide goes dark - see adr/002-client-guide-freshness.md for the full arithmetic, including
# the finding that the supply-side jitter alone can already exceed the horizon.
#
# One number, used twice on purpose: it is both the interval seeded into IPTV Merge (which polls
# only while Kodi is running) and the staleness threshold checked at every boot (which is what
# covers a device that was powered off). Two knobs that must agree are a knob that will drift.
GUIDE_MAX_AGE_HOURS = 2

# Exists solely to undo wizard 5.3.0's withdrawn provider migration, and nothing else.
# Gated on the migration fingerprint (STARWAVE_CHANNELS_URL playlist row absent):
# - "URL row absent AND retired ADDON rows present" is precisely the fingerprint that 5.3.0's
#   migration leaves behind.
# - A normal StarWave device carries the URL row, so a user's own slyguy.roku ADDON source
#   sits alongside it and is never touched.
# - It self-heals the migrated case exactly once in practice: after the first repair the URL
#   row is back, so the delete never arms again.
# - That is what removes the permanence, with no marker file and no version stamp.
RETIRED_ADDON_SOURCES = ('slyguy.roku', 'slyguy.samsung.tv.plus')


def ensure_slyguy():
    """Ensure repository.slyguy, the SlyGuy FAST channel add-ons, and IPTV Merge are installed.

    Installs repository.slyguy from zip if missing (safely confined extract, registering in
    Addons33.db, rescanning local addons with UpdateLocalAddons until registered, then
    triggering UpdateAddonRepos), then installs missing channel add-ons via
    ensure_addon() so Kodi resolves slyguy.dependencies through the repository.
    Tolerates an unreachable repo as normal (log, report, no crash). Idempotent.
    Returns (lines, success) tuple where success is a bool signal.
    """
    lines = []
    has_build = (
        bool(get_build_version())
        or os.path.isdir(os.path.join(HOME, 'addons', 'skin.arctic.fuse.3'))
        or os.path.isdir(os.path.join(HOME, 'addons', 'skin.NTVaura'))
    )
    repo_present = False
    try:
        xbmcaddon.Addon(SLYGUY_REPO_ID)
        repo_present = True
    except Exception:  # noqa: BLE001 - not installed
        pass

    if not has_build and not repo_present:
        return lines, True

    if not repo_present:
        dest = os.path.join(TEMP_DIR, 'repository.slyguy-0.0.9.zip')
        log('repository.slyguy missing - downloading from %s' % SLYGUY_REPO_URL)
        try:
            req = Request(SLYGUY_REPO_URL, headers={'User-Agent': 'StarWave-Wizard'})
            downloaded = 0
            with urlopen(req, timeout=30) as r, open(dest, 'wb') as fh:
                while True:
                    chunk = r.read(64 * 1024)
                    if not chunk:
                        break
                    downloaded += len(chunk)
                    if downloaded > SLYGUY_MAX_ZIP_BYTES:
                        log('repository.slyguy download exceeded %d bytes - refusing it'
                            % SLYGUY_MAX_ZIP_BYTES, xbmc.LOGWARNING)
                        return lines, False
                    fh.write(chunk)
            import zipfile
            addons_dir = os.path.join(HOME, 'addons')
            with zipfile.ZipFile(dest) as zf:
                prefix = SLYGUY_REPO_ID + '/'
                members = [n for n in zf.namelist()
                           if n.startswith(prefix) and not _is_generated(n)]
                if not members:
                    log('repository.slyguy zip contained nothing under %s - refusing it'
                        % prefix, xbmc.LOGWARNING)
                    return lines, False
                zf.extractall(addons_dir, members)
            merge_installed([SLYGUY_REPO_ID])
            xbmc.executebuiltin('UpdateLocalAddons')
            monitor = xbmc.Monitor()
            waited = 0
            registered = False
            while waited < 10:
                if xbmc.getCondVisibility('System.HasAddon(%s)' % SLYGUY_REPO_ID):
                    registered = True
                    break
                if monitor.waitForAbort(1):
                    break
                waited += 1
            if not registered:
                log('repository.slyguy could not be registered by Kodi', xbmc.LOGWARNING)
                lines.append('[COLOR red]repository.slyguy: could not be registered.[/COLOR]')
                return lines, False

            xbmc.executebuiltin('UpdateAddonRepos')
            monitor.waitForAbort(2)
            lines.append('SlyGuy Repository: installed')
            log('repository.slyguy installed and repository check triggered')
        except Exception as exc:  # noqa: BLE001 - repo unreachable or network down is tolerated
            log('could not install repository.slyguy: %s' % exc, xbmc.LOGWARNING)
            return lines, False
        finally:
            try:
                if os.path.exists(dest):
                    os.remove(dest)
            except Exception:  # noqa: BLE001
                pass

    all_ok = True
    for addon_id in SLYGUY_CHANNEL_ADDONS:
        try:
            state = ensure_addon(addon_id)
            if state == 'installed':
                lines.append('%s: installed' % addon_id)
            elif state == 'failed':
                lines.append('[COLOR red]%s: could not install.[/COLOR]' % addon_id)
                all_ok = False
        except Exception as exc:  # noqa: BLE001
            log('could not install %s: %s' % (addon_id, exc), xbmc.LOGWARNING)
            lines.append('[COLOR red]%s: could not install.[/COLOR]' % addon_id)
            all_ok = False

    return lines, all_ok


def trigger_iptv_merge(force=True):
    """Trigger IPTV Merge to perform an immediate playlist/epg merge run.

    force=1 bypasses IPTV Merge's reload timer so the merge really runs;
    the PVR restart that force used to cause is prevented by restart_pvr=false,
    and IPTV Simple reloads the new files on its own within the IPTV Simple refresh
    interval, which ensure_guide_fresh keeps at 5 minutes (m3uRefreshMode=1).
    """
    try:
        cmd = 'RunPlugin(plugin://%s/?_=run_merge&force=%d)' % (IPTV_MERGE_ID, 1 if force else 0)
        xbmc.executebuiltin(cmd)
        log('triggered IPTV Merge: %s' % cmd)
        return True
    except Exception as exc:  # noqa: BLE001
        log('could not trigger IPTV Merge: %s' % exc, xbmc.LOGWARNING)
        return False


def ensure_guide_fresh(home=None, max_age_hours=None):
    """Re-assert GUIDE FRESHNESS on every boot. This is an invariant, not a one-shot.

    WHY THIS IS SEPARATE FROM ensure_iptv_guide(). The merge trigger used to live only inside
    ensure_iptv_guide(), which service.py calls from its once-per-wizard-version section. So the
    force-merge fired once per wizard RELEASE, not per boot: a device logged
    `per-device fixes already applied for 5.7.7` through a cold boot and two Kodi launches while
    sitting on an 8h-old merge, and what finally cleared it was a publish changing the version
    string. Merge history on that device shows gaps of 27.5h and 21.1h against a guide whose
    Samsung half - two thirds of the lineup - lives about 4.6 hours.

    The version gate is NOT the bug and is deliberately left alone. It exists so one-time
    per-device fixes (menu icons, display tuning, scraper repair) are not redone at every boot
    and do not fight an owner who changed one back. The bug was putting a FRESHNESS check behind
    a gate that only opens on a release. Same shape as ensure_live_stack: what must hold on every
    start gets its own invariant; what is correct once stays gated.

    Five steps run here, and all are cheap and idempotent:

    1a. THE INTERVAL AND RESTART SETTING (settings.db). reload_time_hours, auto_merge, and
        restart_pvr in IPTV Merge's SlyGuy settings are re-asserted here so the fix is independent
        of the version gate: a device that already carries the wizard picks up the settings on its
        next boot rather than on the next release. Read-then-write - an already-correct device
        writes nothing and says nothing. restart_pvr is now enforced every boot. When true, IPTV
        Merge's forced merge restarts IPTV Simple by disabling and re-enabling it, which turns
        inputstream.ffmpegdirect back on as a required dependency and triggers a permanent fight
        with the wizard's LIVE_DISABLE invariant. The rest of the SlyGuy plumbing (http_method,
        http_url, output_dir) stays gated: it is output-mode wiring, it has never been observed
        to drift, and a guard with no evidence behind it is cost, not foresight.

    1b. THE INTERVAL AND RESTART SETTING (settings.xml). Repairs reload_time_hours and restart_pvr
        inside IPTV Merge's settings.xml in place.

    1c. THE SOURCE LIST. Reconciles IPTV Merge's data.db epg table when the database already
        exists: guarantees the StarWave EPG URL is present and enabled, and deletes any superseded
        upstream feeds (SUPERSEDED_EPG_URLS). If any sources were changed or re-enabled, forces a
        merge in step 2 so the merged guide drops the retired feeds without waiting for
        staleness.

    1d. IPTV SIMPLE REFRESH (instance-settings-1.xml). Ensures m3uRefreshMode is 1 and
        m3uRefreshIntervalMins is 5 so IPTV Simple periodically checks for the updated playlist
        and guide without requiring a PVR restart.

    2. THE STALENESS CHECK. IPTV Merge polls only while Kodi is running, so its interval cannot
       cover a device that was powered off - which is the ordinary case. Comparing the merged
       epg.xml's mtime against the same budget covers it: a device that was off overnight merges
       at boot, and a device restarted ten minutes after a merge does not, so this is not a
       force-merge on every start. A failed merge leaves mtime alone and is retried next boot.

    Everything else ensure_iptv_guide() does stays behind the version gate on purpose:
      - the 5.3.0 ADDON-row migration (RETIRED_ADDON_SOURCES) in data.db is a one-time repair
        that stays gated behind the version check, while superseded-URL retirement and StarWave
        source reconciliation now also run every boot.
      - the bootstrap downloads of playlist.m3u8 / epg.xml are network work with 15s and 30s
        timeouts, only meaningful on a virgin device, and running them at boot would race the
        merge this function is about to trigger.
      - settings.xml and the PVR instance-settings are first-install scaffolding written only
        when absent; rewriting them would stomp an owner's own PVR tuning. IPTV Merge (SlyGuy)
        reads settings.db (SlyGuy settings/db_storage.py); settings.xml is only a one-time
        migration input, deleted once migrated, so step 1a is the fix that matters and 1b is a
        belt-and-braces repair for unmigrated devices.
      - installing and enabling pvr.iptvsimple is expensive, and its enablement is already a
        boot invariant via ensure_live_stack (pvr.iptvsimple is in LIVE_ENABLE).

    Returns a list of human-readable lines, EMPTY when nothing needed doing, so a healthy boot
    stays silent. Never raises: a failure here must not be able to break Kodi startup.
    """
    home = home or HOME
    budget = GUIDE_MAX_AGE_HOURS if max_age_hours is None else max_age_hours
    lines = []

    merge_dir = os.path.join(home, 'userdata', 'addon_data', IPTV_MERGE_ID)
    slyguy_dir = os.path.join(home, 'userdata', 'addon_data', 'script.module.slyguy')

    # 1a. The interval, in the SlyGuy settings database.
    #
    # Silent when the database is absent: seeding it is install-time work owned by
    # ensure_iptv_guide(), and a boot invariant only repairs what is already there. Saying
    # anything here would mean a line on every boot forever on a device that never had IPTV
    # Merge - the same reasoning ensure_live_stack uses for an add-on that is not installed.
    sly_db_path = os.path.join(slyguy_dir, 'settings.db')
    if os.path.exists(sly_db_path):
        sly_con = None
        try:
            sly_con = sqlite3.connect(sly_db_path)
            sly_cur = sly_con.cursor()
            wanted = (
                ('reload_time_hours', str(budget)),
                ('auto_merge', 'true'),
                ('restart_pvr', 'false'),
            )
            for key, want in wanted:
                row = sly_cur.execute(
                    'SELECT value FROM settings WHERE addon_id = ? AND key = ?',
                    (IPTV_MERGE_ID, key)).fetchone()
                have = row[0] if row else None
                if have == want:
                    continue
                sly_cur.execute(
                    'INSERT OR REPLACE INTO settings (addon_id, key, value) VALUES (?, ?, ?)',
                    (IPTV_MERGE_ID, key, want))
                if have is None:
                    was = 'unset (default true)' if key == 'restart_pvr' else 'unset'
                else:
                    was = have
                lines.append('CORRECTED: IPTV Merge %s was %s, set to %s'
                             % (key, was, want))
            sly_con.commit()
        except Exception as exc:  # noqa: BLE001 - a boot invariant must never raise
            log('guide interval check failed: %s' % exc, xbmc.LOGWARNING)
        finally:
            if sly_con is not None:
                try:
                    sly_con.close()
                except Exception:  # noqa: BLE001
                    pass

    # 1b. The same value inside IPTV Merge's own settings.xml, repaired in place.
    #
    # Only reload_time_hours and restart_pvr are touched, and only when the file already exists
    # and already carries the key - so this can neither create scaffolding nor disturb any other
    # value in the file.
    merge_settings = os.path.join(merge_dir, 'settings.xml')
    if os.path.exists(merge_settings):
        try:
            with open(merge_settings, 'r', encoding='utf-8') as fh:
                xml_text = fh.read()
            modified = False
            b_lines = []
            pattern_reload = r'(<setting id="reload_time_hours">)([^<]*)(</setting>)'
            found_reload = re.search(pattern_reload, xml_text)
            if found_reload and found_reload.group(2) != str(budget):
                xml_text = re.sub(pattern_reload, r'\g<1>%s\g<3>' % budget, xml_text)
                modified = True
                b_lines.append('CORRECTED: IPTV Merge settings.xml reload_time_hours was %s, '
                               'set to %s' % (found_reload.group(2), budget))
            pattern_pvr = r'(<setting id="restart_pvr">)([^<]*)(</setting>)'
            found_pvr = re.search(pattern_pvr, xml_text)
            if found_pvr and found_pvr.group(2) != 'false':
                xml_text = re.sub(pattern_pvr, r'\g<1>false\g<3>', xml_text)
                modified = True
                b_lines.append('CORRECTED: IPTV Merge settings.xml restart_pvr was %s, '
                               'set to false' % found_pvr.group(2))
            if modified:
                _atomic_write_text(merge_settings, xml_text)
                lines.extend(b_lines)
        except Exception as exc:  # noqa: BLE001
            log('guide settings.xml check failed: %s' % exc, xbmc.LOGWARNING)

    # 1c. The source list, in IPTV Merge's data.db.
    #
    # Reconciles the EPG sources table on every boot when data.db exists:
    # - Ensures the canonical StarWave EPG URL is present and enabled.
    # - Deletes any superseded feeds (SUPERSEDED_EPG_URLS).
    # Silent when data.db is absent: seeding is ensure_iptv_guide's job.
    # If any sources changed, forces a merge in step 2 so stale feed content is dropped immediately;
    # if IPTV Merge is disabled or the merge cannot be triggered, the removed feeds stay in the
    # merged epg.xml until the normal staleness check fires.
    db_con = None
    sources_changed = False
    db_path = os.path.join(merge_dir, 'data.db')
    if os.path.exists(db_path):
        try:
            db_con = sqlite3.connect(db_path, timeout=5)
            cur = db_con.cursor()

            cur.execute(
                'SELECT enabled FROM epg WHERE source_type = 0 AND path = ?',
                (STARWAVE_EPG_URL,))
            sw_rows = cur.fetchall()
            need_insert = not sw_rows
            need_enable = bool(sw_rows and any(r[0] == 0 for r in sw_rows))

            superseded_count = 0
            if SUPERSEDED_EPG_URLS:
                placeholders = ','.join('?' * len(SUPERSEDED_EPG_URLS))
                cur.execute(
                    'SELECT count(*) FROM epg WHERE source_type = 0 AND path IN (%s)' % placeholders,
                    SUPERSEDED_EPG_URLS)
                row = cur.fetchone()
                superseded_count = row[0] if row else 0

            if need_insert or need_enable or superseded_count > 0:
                sw_action = None
                if need_insert:
                    cur.execute(
                        'INSERT INTO epg (source_type, archive_type, path, enabled) '
                        'VALUES (0, 1, ?, 1)',
                        (STARWAVE_EPG_URL,))
                    sw_action = 'restored the StarWave source'
                elif need_enable:
                    cur.execute(
                        'UPDATE epg SET enabled = 1 WHERE source_type = 0 AND path = ? AND enabled = 0',
                        (STARWAVE_EPG_URL,))
                    sw_action = 're-enabled the StarWave source'

                removed_count = 0
                if superseded_count > 0:
                    placeholders = ','.join('?' * len(SUPERSEDED_EPG_URLS))
                    cur.execute(
                        'DELETE FROM epg WHERE source_type = 0 AND path IN (%s)' % placeholders,
                        SUPERSEDED_EPG_URLS)
                    removed_count = cur.rowcount if cur.rowcount > 0 else 0

                db_con.commit()
                sources_changed = True
                details = []
                if removed_count > 0:
                    details.append('removed %d superseded feed(s)' % removed_count)
                if sw_action:
                    details.append(sw_action)
                lines.append('CORRECTED: Live TV Guide sources - %s' % ', '.join(details))
        except Exception as exc:  # noqa: BLE001 - a boot invariant must never raise
            if db_con is not None:
                try:
                    db_con.rollback()
                except Exception:  # noqa: BLE001
                    pass
            log('guide source list check failed: %s' % exc, xbmc.LOGWARNING)
        finally:
            if db_con is not None:
                try:
                    db_con.close()
                except Exception:  # noqa: BLE001
                    pass

    # 1d. IPTV SIMPLE REFRESH
    #
    # Only if instance-settings-1.xml already exists (never create it; seeding is
    # ensure_iptv_guide's job). Silent when absent.
    # Ensures IPTV Simple reloads the playlist and EPG on its own (m3uRefreshMode=1,
    # m3uRefreshIntervalMins=5) so new content takes effect without restarting the PVR client.
    pvr_dir = os.path.join(home, 'userdata', 'addon_data', PVR_IPTVSIMPLE_ID)
    pvr_instance = os.path.join(pvr_dir, 'instance-settings-1.xml')
    if os.path.exists(pvr_instance):
        try:
            with open(pvr_instance, 'r', encoding='utf-8') as fh:
                xml_text = fh.read()
            changes = []
            wanted_simple = (
                ('m3uRefreshMode', '1'),
                ('m3uRefreshIntervalMins', '5'),
            )
            for key, want in wanted_simple:
                pat = re.compile(r'<setting\b[^>]*\bid="%s"[^>]*(?:/>|>([^<]*)</setting>)' % re.escape(key))
                m = pat.search(xml_text)
                if m:
                    if m.group(0) != '<setting id="%s">%s</setting>' % (key, want):
                        old_raw = m.group(1)
                        old_val = old_raw.strip() if old_raw is not None else ''
                        old_display = old_val or 'unset'
                        new_elem = '<setting id="%s">%s</setting>' % (key, want)
                        xml_text = xml_text[:m.start()] + new_elem + xml_text[m.end():]
                        changes.append((key, old_display, want))
                else:
                    idx = xml_text.rfind('</settings>')
                    if idx != -1:
                        new_elem = '    <setting id="%s">%s</setting>\n' % (key, want)
                        xml_text = xml_text[:idx] + new_elem + xml_text[idx:]
                        changes.append((key, 'unset', want))
            if changes:
                _atomic_write_text(pvr_instance, xml_text)
                for key, old_display, want in changes:
                    lines.append('CORRECTED: IPTV Simple %s was %s, set to %s'
                                 % (key, old_display, want))
        except Exception as exc:  # noqa: BLE001 - a boot invariant must never raise
            log('guide IPTV Simple instance settings check failed: %s' % exc, xbmc.LOGWARNING)

    # 2. The staleness check.
    #
    # Nothing to trigger if the merge add-on is not there - and nothing to say about it either,
    # for the same reason as 1a.
    try:
        if not addon_is_enabled(IPTV_MERGE_ID):
            return lines
    except Exception as exc:  # noqa: BLE001
        log('guide freshness check could not read IPTV Merge state: %s' % exc, xbmc.LOGWARNING)
        return lines

    try:
        merged_epg = os.path.join(merge_dir, 'epg.xml')
        if sources_changed:
            why = 'sources corrected'
        elif os.path.exists(merged_epg):
            age_hours = (time.time() - os.path.getmtime(merged_epg)) / 3600.0
            if age_hours < budget:
                return lines
            why = 'merged guide is %.1fh old (budget %sh)' % (age_hours, budget)
        else:
            why = 'no merged guide on disk yet'
        if trigger_iptv_merge(force=True):
            lines.append('Live TV Guide: %s - merge triggered' % why)
        else:
            lines.append('[COLOR red]Live TV Guide: %s and the merge could not be '
                         'triggered.[/COLOR]' % why)
    except Exception as exc:  # noqa: BLE001 - a boot invariant must never raise
        log('guide freshness check failed: %s' % exc, xbmc.LOGWARNING)
        return lines

    return lines


def ensure_iptv_guide(trigger=True):
    """Ensure IPTV Merge and PVR IPTV Simple Client are configured and enabled.

    1. Seeds iptv.merge SQLite database (data.db) with StarWave's verified channels.m3u8
       playlist and StarWave EPG XML feed if missing, and deletes superseded feeds (the Pages copy,
       Samsung and Roku).
    2. Seeds SlyGuy settings database (settings.db) so IPTV Merge uses direct local file output
       rather than HTTP server mode.
    3. Seeds pvr.iptvsimple instance settings (instance-settings-1.xml) pointing to the
       merged playlist.m3u8 and epg.xml.
    4. Ensures pvr.iptvsimple is enabled so Kodi lights up the Live TV Guide.
    5. Optionally triggers an immediate IPTV Merge run so updates land without waiting 12h.
    """
    lines = []

    # 1. Add-on data directories
    merge_dir = os.path.join(HOME, 'userdata', 'addon_data', IPTV_MERGE_ID)
    pvr_dir = os.path.join(HOME, 'userdata', 'addon_data', PVR_IPTVSIMPLE_ID)
    slyguy_dir = os.path.join(HOME, 'userdata', 'addon_data', 'script.module.slyguy')
    os.makedirs(merge_dir, exist_ok=True)
    os.makedirs(pvr_dir, exist_ok=True)
    os.makedirs(slyguy_dir, exist_ok=True)

    # 2. Seed IPTV Merge data.db if missing or empty
    db_path = os.path.join(merge_dir, 'data.db')
    con = None
    try:
        con = sqlite3.connect(db_path)
        cur = con.cursor()
        cur.execute('''
        CREATE TABLE IF NOT EXISTS source (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_type INTEGER NOT NULL,
            archive_type INTEGER NOT NULL DEFAULT 0,
            path TEXT NOT NULL,
            enabled INTEGER NOT NULL DEFAULT 1,
            results TEXT DEFAULT '[]'
        )''')
        cur.execute('''
        CREATE TABLE IF NOT EXISTS playlist (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_type INTEGER NOT NULL,
            archive_type INTEGER NOT NULL DEFAULT 0,
            path TEXT NOT NULL,
            enabled INTEGER NOT NULL DEFAULT 1,
            results TEXT DEFAULT '[]',
            skip_playlist_chno INTEGER NOT NULL DEFAULT 0,
            use_start_chno INTEGER NOT NULL DEFAULT 0,
            start_chno INTEGER NOT NULL DEFAULT 1,
            default_visible INTEGER NOT NULL DEFAULT 1,
            skip_playlist_groups INTEGER NOT NULL DEFAULT 0,
            group_name TEXT,
            "order" INTEGER NOT NULL DEFAULT 1
        )''')
        cur.execute('''
        CREATE TABLE IF NOT EXISTS epg (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_type INTEGER NOT NULL,
            archive_type INTEGER NOT NULL DEFAULT 0,
            path TEXT NOT NULL,
            enabled INTEGER NOT NULL DEFAULT 1,
            results TEXT DEFAULT '[]',
            start_index INTEGER NOT NULL DEFAULT 0,
            end_index INTEGER NOT NULL DEFAULT 0
        )''')

        cur.execute('SELECT 1 FROM playlist WHERE path = ?', (STARWAVE_CHANNELS_URL,))
        has_channels_playlist = cur.fetchone() is not None

        # source_type = 2 is IPTV Merge's TYPE_ADDON (resources/lib/models.py).
        # Remove retired provider add-on rows left behind by wizard 5.3.0 only when the migration
        # fingerprint is present (frozen STARWAVE_CHANNELS_URL playlist row absent).
        if not has_channels_playlist:
            placeholders = ','.join('?' * len(RETIRED_ADDON_SOURCES))
            cur.execute('DELETE FROM playlist WHERE source_type = 2 AND path IN (%s)' % placeholders,
                        RETIRED_ADDON_SOURCES)
            cur.execute('DELETE FROM epg WHERE source_type = 2 AND path IN (%s)' % placeholders,
                        RETIRED_ADDON_SOURCES)

        if not has_channels_playlist:
            cur.execute('INSERT INTO playlist (source_type, archive_type, path, enabled, "order") VALUES (0, 0, ?, 1, 1)', (STARWAVE_CHANNELS_URL,))

        # Retire superseded URL rows on every pass as a standing policy (ahead of the
        # existence check), so a device never carries dead upstream feeds alongside
        # the merged guide. See SUPERSEDED_EPG_URLS for the standing-policy rationale.
        #
        # Guarded on non-empty, and the reason is NARROWER than this comment first
        # claimed. The original claim - "`path IN ()` is a SQLite SYNTAX ERROR" - is
        # WRONG and is retracted. SQLite documents an empty RHS list as an allowed
        # extension; measured 2026-09-05 on CPython's bundled SQLite 3.53.4,
        # `DELETE ... path IN ()` parses fine and simply matches nothing. So this
        # guard changes NO behaviour on any runtime that can be tested from here, and
        # a mutant that deletes it passes the whole suite - correctly, because it is
        # behaviour-preserving.
        #
        # It is kept as three lines of defence-in-depth, not as a load-bearing line.
        # The wizard runs on whatever SQLite the host Kodi was built against, which is
        # not inspectable from this repo, and `IN ()` is an SQLite-specific allowance
        # that stricter parsers reject. If one ever did, the broad `except Exception`
        # below would swallow it and abandon the WHOLE seeding commit, so a virgin
        # device would get no EPG source at all - silently. Three lines against a
        # silent seeding failure on an untestable runtime is a trade worth taking; a
        # confident false rationale for them is not.
        if SUPERSEDED_EPG_URLS:
            epg_placeholders = ','.join('?' * len(SUPERSEDED_EPG_URLS))
            cur.execute('DELETE FROM epg WHERE source_type = 0 AND path IN (%s)'
                        % epg_placeholders, SUPERSEDED_EPG_URLS)

        cur.execute('SELECT 1 FROM epg WHERE path = ?', (STARWAVE_EPG_URL,))
        if cur.fetchone() is None:
            cur.execute('INSERT INTO epg (source_type, archive_type, path, enabled) VALUES (0, 1, ?, 1)', (STARWAVE_EPG_URL,))

        con.commit()
    except Exception as exc:
        log('could not initialize iptv.merge database: %s' % exc, xbmc.LOGWARNING)
    finally:
        # Deliberate deviation from 087b5f2: 5.3.0 correctly used try/finally to close the
        # sqlite connection even when a commit raises, preventing resource leaks.
        if con is not None:
            try:
                con.close()
            except Exception:  # noqa: BLE001
                pass

    # 2b. Seed initial playlist.m3u8 and epg.xml if missing so PVR Simple Client has channels immediately
    initial_m3u = os.path.join(merge_dir, 'playlist.m3u8')
    # A bare '#EXTM3U' header is 8 bytes and an empty merge output with headers or blank lines
    # is under 100 bytes, while even a minimal single-channel entry exceeds 100 bytes. A 100-byte
    # threshold re-seeds missing or empty/stub playlists without re-downloading valid small playlists.
    if not os.path.exists(initial_m3u) or os.path.getsize(initial_m3u) < 100:
        try:
            req = Request(STARWAVE_CHANNELS_URL, headers={'User-Agent': 'StarWave-Wizard'})
            with urlopen(req, timeout=15) as r, open(initial_m3u, 'wb') as fh:
                shutil.copyfileobj(r, fh)
            log('seeded initial playlist.m3u8 (%d bytes)' % os.path.getsize(initial_m3u))
        except Exception as exc:  # noqa: BLE001
            log('could not download initial channels playlist: %s' % exc, xbmc.LOGWARNING)

    initial_epg = os.path.join(merge_dir, 'epg.xml')
    if not os.path.exists(initial_epg) or os.path.getsize(initial_epg) < 1000:
        try:
            req = Request(STARWAVE_EPG_URL, headers={'User-Agent': 'StarWave-Wizard'})
            with urlopen(req, timeout=30) as r:
                gz_data = r.read()
                xml_data = gzip.decompress(gz_data) if gz_data.startswith(b'\x1f\x8b') else gz_data
                with open(initial_epg, 'wb') as fh:
                    fh.write(xml_data)
            log('seeded initial epg.xml (%d bytes)' % os.path.getsize(initial_epg))
        except Exception as exc:  # noqa: BLE001
            log('could not download initial epg.xml: %s' % exc, xbmc.LOGWARNING)

    # 3. Seed SlyGuy settings.db for IPTV Merge (disable HTTP server mode, force local file paths)
    sly_db_path = os.path.join(slyguy_dir, 'settings.db')
    sly_con = None
    try:
        sly_con = sqlite3.connect(sly_db_path)
        sly_cur = sly_con.cursor()
        sly_cur.execute('''
        CREATE TABLE IF NOT EXISTS settings (
            addon_id VARCHAR(255) NOT NULL,
            key VARCHAR(255) NOT NULL,
            value TEXT NOT NULL,
            PRIMARY KEY (addon_id, key)
        )''')
        sly_entries = [
            (IPTV_MERGE_ID, 'http_method', 'false'),
            (IPTV_MERGE_ID, 'http_url', '""'),
            (IPTV_MERGE_ID, 'auto_merge', 'true'),
            # Seeded from the one constant so an install and a boot repair can never disagree.
            (IPTV_MERGE_ID, 'reload_time_hours', str(GUIDE_MAX_AGE_HOURS)),
            (IPTV_MERGE_ID, 'restart_pvr', 'false'),
            (IPTV_MERGE_ID, 'output_dir', json.dumps('special://userdata/addon_data/' + IPTV_MERGE_ID)),
        ]
        sly_cur.executemany('INSERT OR REPLACE INTO settings (addon_id, key, value) VALUES (?, ?, ?)', sly_entries)
        sly_con.commit()
    except Exception as exc:
        log('could not initialize slyguy settings database: %s' % exc, xbmc.LOGWARNING)
    finally:
        if sly_con is not None:
            try:
                sly_con.close()
            except Exception:  # noqa: BLE001
                pass

    # 4. Seed IPTV Merge settings.xml as fallback
    merge_settings = os.path.join(merge_dir, 'settings.xml')
    if not os.path.exists(merge_settings):
        try:
            _atomic_write_text(
                merge_settings,
                '<settings version="2">\n'
                '    <setting id="auto_merge">true</setting>\n'
                '    <setting id="reload_time_hours">%s</setting>\n'
                '    <setting id="restart_pvr">false</setting>\n'
                '    <setting id="http_method">false</setting>\n'
                '    <setting id="output_dir">special://userdata/addon_data/plugin.program.iptv.merge</setting>\n'
                '</settings>' % GUIDE_MAX_AGE_HOURS,
            )
        except Exception as exc:
            log('could not write iptv.merge settings.xml: %s' % exc, xbmc.LOGWARNING)

    # 5. Seed PVR IPTV Simple instance-settings-1.xml
    pvr_instance = os.path.join(pvr_dir, 'instance-settings-1.xml')
    if not os.path.exists(pvr_instance):
        try:
            _atomic_write_text(
                pvr_instance,
                '<settings version="2">\n'
                '    <setting id="kodi_addon_instance_name">IPTV Merge</setting>\n'
                '    <setting id="kodi_addon_instance_enabled">true</setting>\n'
                '    <setting id="m3uPathType">0</setting>\n'
                '    <setting id="m3uPath">special://userdata/addon_data/plugin.program.iptv.merge/playlist.m3u8</setting>\n'
                '    <setting id="m3uUrl">special://userdata/addon_data/plugin.program.iptv.merge/playlist.m3u8</setting>\n'
                '    <setting id="m3uRefreshMode">1</setting>\n'
                '    <setting id="m3uRefreshIntervalMins">5</setting>\n'
                '    <setting id="m3uCache">false</setting>\n'
                '    <setting id="epgPathType">0</setting>\n'
                '    <setting id="epgPath">special://userdata/addon_data/plugin.program.iptv.merge/epg.xml</setting>\n'
                '    <setting id="epgUrl">special://userdata/addon_data/plugin.program.iptv.merge/epg.xml</setting>\n'
                '    <setting id="epgCache">false</setting>\n'
                '    <setting id="startNum">1</setting>\n'
                '</settings>',
            )
        except Exception as exc:
            log('could not write pvr.iptvsimple instance settings: %s' % exc, xbmc.LOGWARNING)

    # 6. Enable PVR IPTV Simple (install if missing on non-Android)
    if not is_android():
        ensure_addon(PVR_IPTVSIMPLE_ID)

    res = set_addon_enabled(PVR_IPTVSIMPLE_ID, True)
    if res:
        lines.append('Live TV Guide (PVR): enabled')

    # 7. Explicitly trigger IPTV Merge if installed/enabled
    if trigger and addon_is_enabled(IPTV_MERGE_ID):
        if trigger_iptv_merge(force=True):
            lines.append('Live TV Guide (IPTV Merge): merge triggered')

    return lines


def ensure_slyguy_proxy(home=None):
    """Ensure SlyGuy Common proxy has SO_REUSEADDR and does not throw blocking modal error dialogs on port collision.

    1. Patches script.module.slyguy/resources/lib/proxy.py:
       - Sets allow_reuse_address = True at class level on ThreadedHTTPServer.
       - Falls back dynamically to check_port() if binding fixed port fails before raising modal popup.
    2. Clears fixed proxy_port from script.module.slyguy/settings.db if present so dynamic port probing works.
    """
    lines = []
    base_home = home or HOME
    slyguy_proxy_path = os.path.join(base_home, 'addons', 'script.module.slyguy', 'resources', 'lib', 'proxy.py')

    if os.path.exists(slyguy_proxy_path):
        try:
            with open(slyguy_proxy_path, 'r', encoding='utf-8') as f:
                content = f.read()

            modified = False
            # 1. Ensure allow_reuse_address is at class level in ThreadedHTTPServer
            if 'class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):' in content and 'allow_reuse_address = True' not in content.split('class ThreadedHTTPServer')[1].split('class Proxy')[0]:
                content = content.replace(
                    'class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):\n    daemon_threads = True',
                    'class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):\n    daemon_threads = True\n    allow_reuse_address = True'
                )
                modified = True

            # 2. Dynamic fallback in Proxy.start() before giving up with modal popup
            old_start_block = """        try:
            self._server = ThreadedHTTPServer(('0.0.0.0', port), RequestHandler)
        except Exception as e:
            log.exception(e)
            settings.set('_proxy_path', '')
            error = 'Unable to start Slyguy Proxy on port: {}. Some addon features will not work. You can change port under Slyguy Settings -> System'.format(port)
            log.error(error)
            gui.error(error)
            return"""

            new_start_block = """        try:
            self._server = ThreadedHTTPServer(('0.0.0.0', port), RequestHandler)
        except Exception as e:
            new_port = check_port()
            if new_port and new_port != port:
                try:
                    self._server = ThreadedHTTPServer(('0.0.0.0', new_port), RequestHandler)
                    port = new_port
                except Exception as ex:
                    log.exception(ex)
                    settings.set('_proxy_path', '')
                    return
            else:
                log.exception(e)
                settings.set('_proxy_path', '')
                return"""

            if old_start_block in content:
                content = content.replace(old_start_block, new_start_block)
                modified = True

            if modified:
                with open(slyguy_proxy_path, 'w', encoding='utf-8') as f:
                    f.write(content)
                lines.append('SlyGuy Proxy: patched with SO_REUSEADDR and dynamic port fallback')
        except Exception as exc:
            log('could not patch slyguy proxy.py: %s' % exc, xbmc.LOGWARNING)

    # 3. Clean fixed proxy_port from settings.db so default dynamic check runs
    sly_db_path = os.path.join(base_home, 'userdata', 'addon_data', 'script.module.slyguy', 'settings.db')
    if os.path.exists(sly_db_path):
        try:
            con = sqlite3.connect(sly_db_path)
            cur = con.cursor()
            cur.execute("DELETE FROM settings WHERE addon_id = 'script.module.slyguy' AND key = 'proxy_port'")
            con.commit()
            con.close()
        except Exception:
            pass

    return lines


def generate_error_report(home=None):
    """Scan kodi.log for high-signal errors, tracebacks, socket errors, and dialog triggers.

    Generates a structured dictionary, saves to error_report.json, and returns human-readable formatted text.
    """
    base_home = home or HOME
    log_candidates = [
        os.path.join(base_home, 'temp', 'kodi.log'),
        os.path.join(base_home, 'userdata', 'temp', 'kodi.log'),
    ]
    log_file = None
    for cand in log_candidates:
        if os.path.exists(cand):
            log_file = cand
            break

    events = []
    if log_file:
        try:
            with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
                raw_lines = f.readlines()

            in_tb = False
            current_tb = []
            for line in raw_lines[-2000:]:
                if 'Traceback (most recent call last):' in line:
                    in_tb = True
                    current_tb = [line.strip()]
                    continue
                if in_tb:
                    current_tb.append(line.strip())
                    if not line.startswith(' ') and not line.startswith('\t') and len(current_tb) > 2:
                        in_tb = False
                        events.append({
                            'type': 'traceback',
                            'details': '\n'.join(current_tb)
                        })
                        current_tb = []
                    continue

                if 'error <general>:' in line or 'fatal <general>:' in line or 'Unable to start' in line:
                    if 'Direct texture file loading failed' in line or "has been asked to focus, but it can't" in line:
                        continue
                    events.append({
                        'type': 'error',
                        'line': line.strip()
                    })
        except Exception as exc:
            events.append({'type': 'diagnostic_error', 'message': str(exc)})

    report = {
        'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
        'log_file': log_file,
        'total_events': len(events),
        'events': events[-30:]
    }

    wiz_data_dir = os.path.join(base_home, 'userdata', 'addon_data', 'plugin.program.starwave.wizard')
    try:
        os.makedirs(wiz_data_dir, exist_ok=True)
        report_json_path = os.path.join(wiz_data_dir, 'error_report.json')
        with open(report_json_path, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2)
    except Exception:
        pass

    text_lines = [
        '==================================================',
        ' STARWAVE KODI DIAGNOSTIC ERROR REPORT',
        ' Generated: %s' % report['timestamp'],
        ' Events Found: %d' % len(events),
        '==================================================\n'
    ]
    if not events:
        text_lines.append('No critical errors or tracebacks detected in kodi.log.')
    else:
        for idx, ev in enumerate(events[-20:], 1):
            if ev.get('type') == 'traceback':
                text_lines.append('[%d] PYTHON TRACEBACK:\n%s\n' % (idx, ev.get('details', '')))
            else:
                text_lines.append('[%d] %s' % (idx, ev.get('line', ev.get('message', ''))))

    return '\n'.join(text_lines)


def view_error_log():
    """Display the StarWave error report in Kodi TextViewer dialog."""
    report_text = generate_error_report()
    xbmcgui.Dialog().textviewer('StarWave Error Report', report_text)


SPORTS_ROUTE = 'plugin://plugin.program.starwave.wizard/?action=sports'
SPORTS_HERO_ROUTE = 'plugin://plugin.program.starwave.wizard/?action=sports_hero'
LEGACY_SPORTS_GUID = 'guid-sports-pvr'
CANONICAL_SPORTS_GUID = 'guid-sports-canonical-games'

# Only used when the widget file is missing or unreadable. On a device that already has a
# 1101 row, ensure_canonical_sports corrects widget 1's PATH and nothing else - see below.
CANONICAL_1101_WIDGETS = [
    {
        "label": "NFL",
        "icon": "special://skin/extras/icons/football-american.png",
        "path": "plugin://plugin.program.starwave.wizard/?action=sports&sport=nfl&skip_hero=1",
        "target": "videos",
        "guid": CANONICAL_SPORTS_GUID,
        "widget_style": "Landscape"
    },
    {
        "label": "MLB",
        "icon": "special://skin/extras/icons/baseball.png",
        "path": "plugin://plugin.program.starwave.wizard/?action=sports&sport=mlb&skip_hero=1",
        "target": "videos",
        "guid": "guid-sports-row-mlb",
        "widget_style": "Landscape"
    },
    {
        "label": "College Football",
        "icon": "special://skin/extras/icons/football.png",
        "path": "plugin://plugin.program.starwave.wizard/?action=sports&sport=cfb&skip_hero=1",
        "target": "videos",
        "guid": "guid-sports-row-cfb",
        "widget_style": "Landscape"
    },
    {
        "label": "Boxing",
        "icon": "special://skin/extras/icons/boxing.png",
        "path": "plugin://plugin.program.starwave.wizard/?action=sports&sport=boxing&skip_hero=1",
        "target": "videos",
        "guid": "guid-sports-row-boxing",
        "widget_style": "Landscape"
    },
    {
        "label": "Leagues & Events",
        "icon": "special://skin/extras/icons/trophy.png",
        "path": "plugin://plugin.video.thecrew/?action=bluehat",
        "target": "videos",
        "guid": "guid-sports-leagues",
        "widget_style": "Landscape"
    },
    {
        "label": "Replays & Highlights",
        "icon": "special://skin/extras/icons/stopwatch.png",
        "path": "plugin://plugin.video.thecrew/?action=sreplays",
        "target": "videos",
        "guid": "guid-sports-replays",
        "widget_style": "Landscape"
    }
]


CANONICAL_1101_SUBMENU = [
    {
        "label": "Live Sports (TV)",
        "icon": "special://skin/extras/icons/tvguide.png",
        "path": "ActivateWindow(TVGuide)",
        "target": "",
        "guid": "guid-sub-pvr"
    },
    {
        "label": "NFL",
        "icon": "special://skin/extras/icons/football-american.png",
        "path": "ActivateWindow(videos,\"plugin://plugin.program.starwave.wizard/?action=sports&sport=nfl\",return)",
        "target": "",
        "guid": "guid-sub-nfl"
    },
    {
        "label": "MLB",
        "icon": "special://skin/extras/icons/baseball.png",
        "path": "ActivateWindow(videos,\"plugin://plugin.program.starwave.wizard/?action=sports&sport=mlb\",return)",
        "target": "",
        "guid": "guid-sub-mlb"
    },
    {
        "label": "NBA",
        "icon": "special://skin/extras/icons/basketball.png",
        "path": "ActivateWindow(videos,\"plugin://plugin.video.thecrew/?action=nba\",return)",
        "target": "",
        "guid": "guid-sub-nba"
    },
    {
        "label": "NHL",
        "icon": "special://skin/extras/icons/hockey-puck.png",
        "path": "ActivateWindow(videos,\"plugin://plugin.video.thecrew/?action=nhl\",return)",
        "target": "",
        "guid": "guid-sub-nhl"
    },
    {
        "label": "College Football",
        "icon": "special://skin/extras/icons/football.png",
        "path": "ActivateWindow(videos,\"plugin://plugin.program.starwave.wizard/?action=sports&sport=cfb\",return)",
        "target": "",
        "guid": "guid-sub-cfb"
    },
    {
        "label": "UFC / MMA",
        "icon": "special://skin/extras/icons/medal.png",
        "path": "ActivateWindow(videos,\"plugin://plugin.video.thecrew/?action=ufc\",return)",
        "target": "",
        "guid": "guid-sub-ufc"
    },
    {
        "label": "Boxing",
        "icon": "special://skin/extras/icons/boxing.png",
        "path": "ActivateWindow(videos,\"plugin://plugin.video.thecrew/?action=boxing\",return)",
        "target": "",
        "guid": "guid-sub-boxing"
    },
    {
        "label": "FIFA",
        "icon": "special://skin/extras/icons/soccer.png",
        "path": "ActivateWindow(videos,\"plugin://plugin.video.thecrew/?action=fifa\",return)",
        "target": "",
        "guid": "guid-sub-fifa"
    },
    {
        "label": "Formula 1",
        "icon": "special://skin/extras/icons/car-side.png",
        "path": "ActivateWindow(videos,\"plugin://plugin.video.thecrew/?action=f1\",return)",
        "target": "",
        "guid": "guid-sub-f1"
    },
    {
        "label": "Replays",
        "icon": "special://skin/extras/icons/stopwatch.png",
        "path": "ActivateWindow(videos,\"plugin://plugin.video.thecrew/?action=sreplays\",return)",
        "target": "",
        "guid": "guid-sub-replays"
    }
]


# The 1101 rows as StarWave shipped them BEFORE Option D. Recognising our own previous
# output by (label, path) is what makes the upgrade below safe: a device still carrying
# exactly this is running an untouched StarWave default and can be migrated, while a row
# the owner has edited is left alone. Fingerprints, never a blanket overwrite.
LEGACY_1101_WIDGET_ROWS = (
    (('Live Matches', SPORTS_ROUTE),
     ('Leagues & Events', 'plugin://plugin.video.thecrew/?action=bluehat'),
     ('Replays & Highlights', 'plugin://plugin.video.thecrew/?action=sreplays')),
    (('NFL', 'plugin://plugin.program.starwave.wizard/?action=sports&sport=nfl&skip_hero=1'),
     ('MLB', 'plugin://plugin.program.starwave.wizard/?action=sports&sport=mlb&skip_hero=1'),
     ('College Football', 'plugin://plugin.program.starwave.wizard/?action=sports&sport=cfb&skip_hero=1'),
     ('Leagues & Events', 'plugin://plugin.video.thecrew/?action=bluehat'),
     ('Replays & Highlights', 'plugin://plugin.video.thecrew/?action=sreplays')),
)


def _row_fingerprint(items):
    """(label, path) pairs for a node list, or None if it is not a node list at all."""
    if not isinstance(items, list):
        return None
    out = []
    for it in items:
        if not isinstance(it, dict):
            return None
        out.append((it.get('label', ''), it.get('path', '')))
    return tuple(out)


def ensure_canonical_sports(on_disk=False):
    """Keep the Sports Hub's first 1101 widget pointed at the live sports route.

    This runs on EVERY boot (service.py section 1), so it is deliberately the narrowest
    thing that still defends the invariant. The invariant is "widget 1's path must not rot
    back to the dead crew_sports.m3u or the legacy PVR route", NOT "the whole row is ours":

    1. Widget 1's `path` is forced to SPORTS_ROUTE, and a legacy `guid-sports-pvr` guid is
       migrated. Its label, icon, target and widget_style are left exactly as found, and
       widgets 2 and 3 are never touched - a user who renamed or reordered their Sports Hub
       row keeps that across restarts.
    2. The full CANONICAL_1101_WIDGETS row is only written when the file is missing, empty
       or unparseable, i.e. when there is nothing of the user's to preserve.
    3. Arctic Fuse 3 settings.xml is split the same way. Only what STRUCTURALLY makes the
       row exist is forced on every boot - homeswitcher.1101.toggle == true (the row is
       enabled at all), homeswitcher.1101.mode == Wall (the window mode the widgets are
       authored for), and homeswitcher.1101.spotlight.target / path (the hero spotlight container).
       HomeSwitcher.1101.Name, homeswitcher.1101.icon, and homeswitcher.1101.spotlight.label
       are SEEDED when absent or empty and never rewritten afterwards, so a user who renames
       the row or picks another icon keeps it - the same over-reach, and the same fix, as the
       widget file above. All four are de-duplicated, since a doubled setting id is Arctic Fuse
       reading whichever it happens to hit first. The file is CREATED when it is absent:
       a device whose Arctic Fuse settings dialog has never been opened has no
       settings.xml at all, and skipping it there left the Sports Hub row switched off
       with nothing else in the system that would ever switch it on.

    It performs NO network I/O. It used to seed userdata/playlists/video/crew_sports.m3u
    over HTTP; nothing reads that playlist any more (the widget is a plugin:// route) and
    from section 1 that fetch would have run at every boot on any device whose seed never
    succeeded - Kodi starting before wifi associates being the common case.
    """
    lines = []
    changed_1101 = False

    # Check & update 1101widgets.json
    nodes_dir = os.path.join(HOME, 'userdata', 'addon_data', 'script.skinvariables', 'nodes', 'skin.arctic.fuse.3')
    widgets_1101 = os.path.join(nodes_dir, 'skinvariables-shortcut-1101widgets.json')

    data = None
    if os.path.exists(widgets_1101):
        try:
            with open(widgets_1101, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except Exception as exc:  # noqa: BLE001
            log('could not read 1101widgets.json (%s); rewriting canonical row' % exc, xbmc.LOGWARNING)
            data = None

    usable = isinstance(data, list) and len(data) > 0 and isinstance(data[0], dict)

    # ONE-TIME UPGRADE to the Option D row. Only fires when the file on disk is
    # byte-for-byte one of OUR previous defaults by (label, path); anything the owner has
    # edited keeps its own shape and is never touched. Without this the row never reaches a
    # device that already has a 1101widgets.json - which is every device already running
    # StarWave, i.e. all of them.
    if usable and _row_fingerprint(data) in LEGACY_1101_WIDGET_ROWS:
        try:
            os.makedirs(nodes_dir, exist_ok=True)
            with open(widgets_1101, 'w', encoding='utf-8') as f:
                json.dump(CANONICAL_1101_WIDGETS, f, indent=2)
            changed_1101 = True
            data = list(CANONICAL_1101_WIDGETS)
            log('upgraded the 1101 row to include league categories (NFL, MLB, College Football, Boxing)')
            lines.append('Sports Hub: league categories added (NFL, MLB, College Football, Boxing)')
        except Exception as exc:  # noqa: BLE001
            log('could not upgrade 1101widgets.json: %s' % exc, xbmc.LOGWARNING)

    if usable:
        first = data[0]
        changed = False
        # startswith, not equality: since Option D widget 1 is the NFL category and its
        # path is SPORTS_ROUTE + '&sport=nfl'. An equality test would rewrite that back to
        # the unfiltered route on EVERY boot, silently undoing the layout. The dead
        # crew_sports.m3u and the legacy PVR route still fail this, which is the invariant.
        if not first.get('path', '').startswith(SPORTS_ROUTE):
            log('sports widget path was %r; correcting to the live sports route' % first.get('path', ''))
            first['path'] = SPORTS_ROUTE
            changed = True
        if first.get('guid') == LEGACY_SPORTS_GUID:
            first['guid'] = CANONICAL_SPORTS_GUID
            changed = True
        if changed:
            try:
                os.makedirs(nodes_dir, exist_ok=True)
                with open(widgets_1101, 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=2)
                changed_1101 = True
                log('repointed 1101 widget 1 at the live sports route (other widgets untouched)')
                lines.append('Sports Hub: live sports route restored on widget 1')
            except Exception as exc:  # noqa: BLE001
                log('could not write 1101widgets.json: %s' % exc, xbmc.LOGWARNING)
    else:
        try:
            os.makedirs(nodes_dir, exist_ok=True)
            with open(widgets_1101, 'w', encoding='utf-8') as f:
                json.dump(CANONICAL_1101_WIDGETS, f, indent=2)
            changed_1101 = True
            log('wrote canonical skinvariables-shortcut-1101widgets.json (none was present)')
            lines.append('Sports Hub: 1101 widgets configured to live sports route')
        except Exception as exc:  # noqa: BLE001
            log('could not write 1101widgets.json: %s' % exc, xbmc.LOGWARNING)

    # THE SUBMENU. Nothing managed this before, so every device still carries league tiles
    # pointing at special://skin/extras/icons/sw/, a directory Arctic Fuse does not have -
    # those icons only exist under skin.NTVaura. Seeded when absent or unreadable; an
    # existing one is left alone, because it is the owner's menu.
    submenu_1101 = os.path.join(nodes_dir, 'skinvariables-shortcut-1101submenu.json')
    sub_data = None
    if os.path.exists(submenu_1101):
        try:
            with open(submenu_1101, 'r', encoding='utf-8') as f:
                sub_data = json.load(f)
        except Exception:  # noqa: BLE001
            sub_data = None
    if _row_fingerprint(sub_data) is None:
        try:
            os.makedirs(nodes_dir, exist_ok=True)
            with open(submenu_1101, 'w', encoding='utf-8') as f:
                json.dump(CANONICAL_1101_SUBMENU, f, indent=2)
            changed_1101 = True
            log('wrote canonical skinvariables-shortcut-1101submenu.json (none was usable)')
            lines.append('Sports Hub: league submenu configured')
        except Exception as exc:  # noqa: BLE001
            log('could not write 1101submenu.json: %s' % exc, xbmc.LOGWARNING)

    # Check & update settings for Arctic Fuse 3.
    forced_map = {
        'homeswitcher.1101.toggle': 'true',
        'homeswitcher.1101.mode': 'Wall',
        'homeswitcher.1101.spotlight.target': 'videos',
        'homeswitcher.1101.spotlight.path': SPORTS_HERO_ROUTE,
    }
    seeded_map = {
        'homeswitcher.1101.icon': 'special://skin/extras/icons/football-american.png',
        'HomeSwitcher.1101.Name': 'Sports Hub',
        'homeswitcher.1101.icon': 'special://skin/extras/icons/sw/nfl.png',
        'homeswitcher.1101.spotlight.label': 'Featured Match',
    }

    active_skin = get_active_skin()
    skin_changed = False

    if not on_disk and active_skin == 'skin.arctic.fuse.3':
        try:
            # 1. FORCED: check current skin string before setting so already-correct values don't trigger rebuild
            for k, v in forced_map.items():
                cur = ''
                try:
                    cur = xbmc.getInfoLabel('Skin.String(%s)' % k)
                except Exception:  # noqa: BLE001
                    cur = ''
                if cur != v:
                    xbmc.executebuiltin('Skin.SetString(%s,"%s")' % (k, v))
                    skin_changed = True

            # 2. SEEDED only when missing or blank
            for k, v in seeded_map.items():
                cur = ''
                try:
                    cur = xbmc.getInfoLabel('Skin.String(%s)' % k)
                except Exception:  # noqa: BLE001
                    cur = ''
                if not (cur or '').strip():
                    xbmc.executebuiltin('Skin.SetString(%s,"%s")' % (k, v))
                    skin_changed = True

            # 3. Verify forced value readback where cheaply possible
            if skin_changed:
                rb = ''
                try:
                    rb = xbmc.getInfoLabel('Skin.String(homeswitcher.1101.spotlight.path)')
                except Exception:  # noqa: BLE001
                    rb = ''
                readback_ok = (rb == SPORTS_HERO_ROUTE)

                if readback_ok:
                    log('applied sports hub skin settings via Skin.SetString (mode/toggle/spotlight forced; name and icon left as found)')
                    lines.append('Sports Hub: Arctic Fuse 3 row enabled in Wall viewmode with Spotlight')
                else:
                    log('applied sports hub skin settings via Skin.SetString (spotlight.path readback mismatch, got %r)' % rb, xbmc.LOGWARNING)

            try:
                log('sports hub skin settings verified: spotlight.path=%r toggle=%r' % (
                    xbmc.getInfoLabel('Skin.String(homeswitcher.1101.spotlight.path)'),
                    xbmc.getInfoLabel('Skin.String(homeswitcher.1101.toggle)')))
            except Exception:  # noqa: BLE001
                pass
        except Exception as exc:  # noqa: BLE001
            log('could not apply sports hub skin settings via Skin.SetString: %s' % exc, xbmc.LOGWARNING)
    else:
        af_settings = os.path.join(HOME, 'userdata', 'addon_data', 'skin.arctic.fuse.3', 'settings.xml')
        try:
            if os.path.exists(af_settings):
                tree = ET.parse(af_settings)
                root = tree.getroot()
            else:
                os.makedirs(os.path.dirname(af_settings), exist_ok=True)
                root = ET.Element('settings', {'version': '2'})
                tree = ET.ElementTree(root)
                log('arctic fuse settings.xml absent; creating it so the Sports Hub row exists')
            changed = False
            found_keys = set()
            to_remove = []
            for s in root.findall('setting'):
                sid = s.get('id', '')
                if sid not in forced_map and sid not in seeded_map:
                    continue
                if sid in found_keys:
                    to_remove.append(s)
                    changed = True
                    continue
                found_keys.add(sid)
                if sid in forced_map:
                    if s.text != forced_map[sid]:
                        s.text = forced_map[sid]
                        changed = True
                elif not (s.text or '').strip():
                    s.text = seeded_map[sid]
                    changed = True
            for s in to_remove:
                root.remove(s)
            for k, v in list(forced_map.items()) + list(seeded_map.items()):
                if k not in found_keys:
                    elem = ET.SubElement(root, 'setting', {'id': k, 'type': 'string'})
                    elem.text = v
                    changed = True
            if changed:
                af_tmp = af_settings + '.tmp.%d' % os.getpid()
                try:
                    tree.write(af_tmp, encoding='utf-8', xml_declaration=True)
                    os.replace(af_tmp, af_settings)
                finally:
                    if os.path.exists(af_tmp):
                        try:
                            os.remove(af_tmp)
                        except OSError:
                            pass
                skin_changed = True
                log('updated skin.arctic.fuse.3/settings.xml sports hub row via file (mode/toggle/spotlight forced; name and icon left as found)')
                lines.append('Sports Hub: Arctic Fuse 3 row enabled in Wall viewmode with Spotlight')
        except Exception as exc:  # noqa: BLE001
            log('could not update sports hub skin settings: %s' % exc, xbmc.LOGWARNING)

    if changed_1101 or skin_changed:
        force_arctic_fuse_rebuild()

    return lines


_SPORTS_PROBE = None


def _load_sports_probe():
    """Load vendored probe_live_sports module from resources/lib/."""
    global _SPORTS_PROBE
    if _SPORTS_PROBE is not None:
        return _SPORTS_PROBE

    try:
        addon_path = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
    except Exception:
        addon_path = None
    if not addon_path or not os.path.exists(addon_path):
        addon_path = os.path.dirname(os.path.abspath(__file__))

    lib_path = os.path.join(addon_path, 'resources', 'lib')
    if os.path.isdir(lib_path) and lib_path not in sys.path:
        sys.path.insert(0, lib_path)

    try:
        import probe_live_sports
        _SPORTS_PROBE = probe_live_sports
        return _SPORTS_PROBE
    except Exception as exc:
        log('error loading vendored probe_live_sports: %s' % exc, xbmc.LOGWARNING)
        return None


# ONLY sports that have passed a channel sweep may appear here. A sport is added
# ONLY after its stream path has been verified end-to-end; the hub must never
# advertise links we cannot back. This list is owner-gated, not a developer convenience.
MONITORED_SPORTS = ['mlb', 'nfl', 'cfb', 'boxing']

# TOTAL_SPORTS_BUDGET bounds how many scoreboard fetches are STARTED, not how long the
# sweep takes. urlopen(timeout=) is a per-socket-operation deadline, not a deadline for the
# whole request, and it does not cover DNS at all - a device whose resolver is not up yet
# (Kodi starting before wifi associates) can block well past this figure inside a single
# call. So: after this many seconds no NEW sport is fetched, and the last one in flight is
# still bounded only by PER_SPORT_TIMEOUT per socket op. Do not describe it as a hard wall.
TOTAL_SPORTS_BUDGET = 3.5
PER_SPORT_TIMEOUT = 1.5   # Maximum timeout passed to a single sport scoreboard fetch

SPORTS_CACHE_TTL = 60             # a complete sweep is good for a minute
SPORTS_CACHE_TTL_TRUNCATED = 15   # a sweep cut short by the budget is NOT a minute's worth

# The five structurally different things the widget can be showing. They are kept apart
# because collapsing them is how a device reports a plausible false state ("quiet night")
# while something is actually broken - a zip shipped without resources/lib, or a box with
# no network - and nothing anywhere reports a fault.
SPORTS_STATE_OK = 'ok'                    # games found
SPORTS_STATE_NO_RESOLVER = 'no_resolver'  # probe module absent/unimportable
SPORTS_STATE_UNREACHABLE = 'unreachable'  # probe ran, every fetch came back empty
SPORTS_STATE_NO_GAMES = 'no_games'        # ESPN answered, nothing is live
SPORTS_STATE_NOT_MONITORED = 'not_monitored'  # a per-league view for a sport we never sweep

SPORTS_EMPTY_ROWS = {
    SPORTS_STATE_NO_RESOLVER: (
        'Live sports unavailable - wizard files are incomplete',
        'The StarWave Wizard could not load its live sports resolver '
        '(resources/lib/probe_live_sports.py). Reinstall or update the wizard from the '
        'StarWave repository. This is NOT a quiet sports night.',
    ),
    SPORTS_STATE_UNREACHABLE: (
        'Could not reach ESPN - check this device\'s connection',
        'Every scoreboard request came back empty, so this device could not reach ESPN. '
        'Check the network, then reopen the Sports Hub. Whether anything is live right now '
        'is unknown.',
    ),
    SPORTS_STATE_NO_GAMES: (
        'No live games right now',
        'ESPN answered and reported nothing in progress across the monitored sports. '
        'Open this again later.',
    ),
    # Same doctrine as no_resolver and unreachable: this row exists so a per-league view of
    # a sport the sweep never fetches cannot report "No live games", which would be a claim
    # about a scoreboard nobody read. MONITORED_SPORTS is the whole of what is swept.
    SPORTS_STATE_NOT_MONITORED: (
        'This league is not monitored',
        'StarWave sweeps %s for live games, and this league is not among them, so whether '
        'anything is live in it right now is unknown. Add it to MONITORED_SPORTS in the '
        'wizard to change that. This is NOT a report that nothing is on.'
        % ', '.join(sp.upper() for sp in MONITORED_SPORTS),
    ),
}


def _norm_sport(raw):
    """Normalise a sport= query parameter to a MONITORED_SPORTS-shaped id, or None.

    MONITORED_SPORTS and every game's `sport` field are lowercase, and the skin's category
    URLs are hand-authored XML. A tile written as `sport=NFL` would otherwise miss the
    membership test and render "this league is not monitored" while live NFL games sat in
    the cache - a wrong answer produced by a capital letter.
    """
    return (raw or '').strip().lower() or None


def _sport_label(probe, sport):
    """Human label for a league id, e.g. 'nfl' -> 'NFL'. Falls back to the id upper-cased,
    so an unknown league still renders a readable row rather than an empty string."""
    cfg = getattr(probe, 'SPORT_CONFIG', {}).get(sport, {}) if probe else {}
    return cfg.get('label', sport.upper())


def get_sports_favourites():
    """Return list of favourite ESPN team IDs if configured."""
    try:
        fav_str = ADDON.getSetting('sports_favourites') if hasattr(ADDON, 'getSetting') else ''
        if fav_str:
            return [x.strip() for x in fav_str.split(',') if x.strip()]
    except Exception:
        pass
    return []


# Quality cache TTL for live game stream probes (15 minutes / 900 seconds).
# A live game lasts ~2.5-3.5 hours; stream server availability and CDN heights can shift
# mid-game. 15 minutes allows smooth widget navigation without repeated background network
# storms, while ensuring stale measurements self-heal quickly and never outlive the game itself.
SPORTS_QUALITY_CACHE_TTL = 900


def _quality_cache_path():
    return os.path.join(HOME, 'userdata', 'addon_data', ADDON_ID, 'sports_quality_cache.json')


def _read_quality_cache():
    """Read quality cache from disk, dropping expired entries.

    Entries without a valid 'timestamp' or older than SPORTS_QUALITY_CACHE_TTL are dropped
    so an expired game falls back to the honest 'not measured yet' state and gets re-probed.
    """
    q_file = _quality_cache_path()
    if not os.path.exists(q_file):
        return {}
    try:
        with open(q_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return {}
        now = time.time()
        valid = {}
        for k, v in data.items():
            if not isinstance(v, dict):
                continue
            ts = v.get('timestamp')
            if ts is not None and isinstance(ts, (int, float)):
                if now - float(ts) < SPORTS_QUALITY_CACHE_TTL:
                    valid[k] = v
        return valid
    except Exception:
        return {}


def _write_quality_cache(quality_map):
    """Write quality cache to disk, pruning expired entries so the file does not grow unboundedly."""
    q_file = _quality_cache_path()
    try:
        now = time.time()
        pruned = {}
        if isinstance(quality_map, dict):
            for k, v in quality_map.items():
                if not isinstance(v, dict):
                    continue
                ts = v.get('timestamp')
                if ts is not None and isinstance(ts, (int, float)):
                    if now - float(ts) < SPORTS_QUALITY_CACHE_TTL:
                        pruned[k] = v
        os.makedirs(os.path.dirname(q_file), exist_ok=True)
        with open(q_file, 'w', encoding='utf-8') as f:
            json.dump(pruned, f)
    except Exception as exc:  # noqa: BLE001
        log('could not save quality cache: %s' % exc, xbmc.LOGDEBUG)


def _probe_games_quality_bg(probe, unprobed_games):
    """Probe stream quality for unprobed live games in background without blocking UI."""
    if not probe or not unprobed_games:
        return

    def _worker():
        try:
            quality_map = _read_quality_cache()
            updated = False
            for g in unprobed_games:
                sport = g.get('sport')
                if not sport:
                    continue
                game_id = str(g.get('id') or g.get('name') or '')
                if not game_id:
                    continue
                try:
                    schedule = probe.fetch_schedule(sport, timeout=4)
                    matching = [e for e in schedule if probe.entry_matches_game(e, g)]
                    if matching:
                        server_count = len(matching)
                        provider = matching[0].get('provider', 'SE')
                        piped = probe.resolve_stage_b(matching[0]['href'], timeout=4, provider=provider)
                        if piped:
                            stream_url = piped.split('|')[0]
                            stream_qc_mod = getattr(probe, 'stream_qc', None)
                            q_str = None
                            probe_measured = False
                            if stream_qc_mod and hasattr(stream_qc_mod, 'probe_hls_stream'):
                                alive, max_h, reason, res_list = stream_qc_mod.probe_hls_stream(piped, timeout=3)
                                if alive and max_h:
                                    q_str = f"{max_h}p"
                                    probe_measured = True
                                else:
                                    probe_measured = False

                            host = _stream_host(stream_url)
                            provider_name = "StreamEast" if provider == 'SE' else ("BuffStreams" if provider == 'BS' else provider)
                            source_str = f"{provider_name} > {host}" if host else provider_name

                            quality_map[game_id] = {
                                'quality': q_str,
                                'measured': probe_measured,
                                'servers': server_count,
                                'source': source_str,
                                'timestamp': time.time(),
                            }
                            updated = True
                except Exception as exc:  # noqa: BLE001
                    log('background quality probe failed for %s: %s' % (game_id, exc), xbmc.LOGDEBUG)
            if updated:
                _write_quality_cache(quality_map)
        except Exception as exc:  # noqa: BLE001
            log('background quality probe thread failed: %s' % exc, xbmc.LOGDEBUG)

    try:
        import threading
        t = threading.Thread(target=_worker, daemon=True)
        t.start()
    except Exception:
        pass


def _sports_cache_path():
    return os.path.join(HOME, 'userdata', 'addon_data', ADDON_ID, 'espn_live_cache.json')


def _read_sports_cache():
    """Return (games, state, rotation, order) from the on-disk cache.

    games is None whenever there is no FRESH, well-shaped cache to serve - which includes a
    truncated or hand-edited file. The cache is arbitrary JSON on disk, and the render loop
    used to walk it without validation, so a short write left the widget spinning with no
    actionable error. rotation is returned even from a STALE cache, so the starting sport
    keeps moving between sweeps (see _collect_live_games).
    """
    cache_file = _sports_cache_path()
    if not os.path.exists(cache_file):
        return None, SPORTS_STATE_NO_GAMES, 0, []
    try:
        with open(cache_file, 'r', encoding='utf-8') as cf:
            cache_data = json.load(cf)
        if not isinstance(cache_data, dict):
            return None, SPORTS_STATE_NO_GAMES, 0, []
        rotation = int(cache_data.get('rotation', 0)) % len(MONITORED_SPORTS)
        order = cache_data.get('order', [])
        games = cache_data.get('games')
        state = cache_data.get('state')
        if not isinstance(games, list) or not all(isinstance(g, dict) for g in games):
            log('sports cache has an unusable shape; re-querying', xbmc.LOGWARNING)
            return None, SPORTS_STATE_NO_GAMES, rotation, order
        # NOT_MONITORED is a per-league RENDER state, never a cache state - it describes the
        # request, not the scoreboard. It is a key in SPORTS_EMPTY_ROWS, so without this it
        # would validate here and a hand-edited cache could put "this league is not
        # monitored" on the unfiltered fleet widget.
        if state == SPORTS_STATE_NOT_MONITORED:
            log('cache carries a render-only state (%s); re-querying' % state, xbmc.LOGWARNING)
            return None, SPORTS_STATE_NO_GAMES, rotation, order
        if state not in SPORTS_EMPTY_ROWS and state != SPORTS_STATE_OK:
            return None, SPORTS_STATE_NO_GAMES, rotation, order
        ttl = SPORTS_CACHE_TTL_TRUNCATED if cache_data.get('truncated') else SPORTS_CACHE_TTL
        if time.time() - float(cache_data.get('timestamp', 0)) < ttl:
            return games, state, rotation, order
        return None, state, rotation, order
    except Exception as exc:  # noqa: BLE001
        log('could not read sports cache (%s); re-querying' % exc, xbmc.LOGWARNING)
        return None, SPORTS_STATE_NO_GAMES, 0, []


def _read_sports_upcoming():
    """Upcoming fixtures from the same cache file, or [] if there are none.

    Deliberately NOT folded into _read_sports_cache's return tuple: that 4-tuple is stubbed
    in fourteen harness tests, and widening it would churn every one of them to carry a
    value they do not care about. Freshness is governed by the same file, so a caller that
    got a live list from the cache is reading an upcoming list of exactly the same age.
    """
    try:
        with open(_sports_cache_path(), 'r', encoding='utf-8') as cf:
            data = json.load(cf)
        up = data.get('upcoming')
        return up if isinstance(up, list) and all(isinstance(g, dict) for g in up) else []
    except Exception:  # noqa: BLE001 - a missing or unreadable cache simply has no slate
        return []


def _write_sports_cache(games, state, truncated, rotation, order=None, upcoming=None):
    cache_file = _sports_cache_path()
    try:
        os.makedirs(os.path.dirname(cache_file), exist_ok=True)
        if order is None:
            order = [str(g.get('id') or g.get('name') or '') for g in games]
        with open(cache_file, 'w', encoding='utf-8') as cf:
            json.dump({'timestamp': time.time(), 'games': games, 'state': state,
                       'truncated': bool(truncated), 'rotation': rotation, 'order': order,
                       'upcoming': upcoming or []}, cf)
    except Exception as exc:  # noqa: BLE001
        log('could not cache sports list: %s' % exc, xbmc.LOGWARNING)


def _collect_live_games(probe, rotation=0, previous_order=None):
    """Sweep the monitored sports. Returns (games, state, truncated, next_rotation).

    MONITORED_SPORTS is a fixed order, so on a consistently slow link the budget cut would
    always land in the same place and the tail of the list would never appear
   - deterministically and silently. The sweep therefore STARTS where the previous one was
    cut off, which is what next_rotation carries.
    """
    games = []
    upcoming = []
    reached = False
    truncated = False
    attempted = 0
    t0 = time.time()
    order = MONITORED_SPORTS[rotation:] + MONITORED_SPORTS[:rotation]

    for sport in order:
        elapsed = time.time() - t0
        remaining = TOTAL_SPORTS_BUDGET - elapsed
        if remaining < 0.4:
            truncated = True
            log('sports budget spent (%.2fs elapsed); stopping discovery early' % elapsed, xbmc.LOGINFO)
            break
        attempted += 1
        call_timeout = min(PER_SPORT_TIMEOUT, remaining)
        try:
            raw_sb = probe.fetch_espn_scoreboard(sport, timeout=call_timeout)
        except Exception as exc:  # noqa: BLE001 - one bad sport must not lose the others
            log('ESPN scoreboard fetch failed for %s: %s' % (sport, exc), xbmc.LOGWARNING)
            continue
        if not raw_sb:
            continue
        reached = True
        try:
            events = probe.parse_espn_events(raw_sb)
            live_games_sport = probe.espn_live_games(events)
            for g in live_games_sport:
                g_copy = dict(g)
                g_copy['sport'] = sport
                games.append(g_copy)
            if sport == 'nfl' and hasattr(probe, 'synthesize_nfl_channels'):
                for ch in probe.synthesize_nfl_channels():
                    games.append(dict(ch))
            # Same payload, previously discarded. This is what lets an idle league show
            # "Tomorrow 8:20 PM" instead of "no live games right now", at no extra request.
            if hasattr(probe, 'espn_upcoming_games'):
                for g in probe.espn_upcoming_games(events):
                    g_copy = dict(g)
                    g_copy['sport'] = sport
                    upcoming.append(g_copy)
        except Exception as exc:  # noqa: BLE001
            log('could not parse ESPN scoreboard for %s: %s' % (sport, exc), xbmc.LOGWARNING)

    favs = get_sports_favourites()
    if probe and hasattr(probe, 'order_sports_games'):
        games = probe.order_sports_games(games, previous_order=previous_order, favourites=favs)

    if games:
        state = SPORTS_STATE_OK
    elif reached:
        state = SPORTS_STATE_NO_GAMES
    else:
        state = SPORTS_STATE_UNREACHABLE

    next_rotation = (rotation + attempted) % len(MONITORED_SPORTS)
    upcoming.sort(key=lambda g: g.get('date') or '')
    return games, state, truncated, next_rotation, upcoming


def _add_upcoming_items(probe, upcoming, sport_filter=None, skip_hero=False):
    """Render scheduled fixtures as non-playable tiles.

    Used twice: appended AFTER the live games, so a league mid-slate shows what is on next;
    and on its own when a league has nothing live at all.
    """
    for game in upcoming:
        teams = game.get('teams', [])
        away_t = next((t for t in teams if t.get('homeAway') == 'away'), teams[0] if teams else {})
        home_t = next((t for t in teams if t.get('homeAway') == 'home'), teams[1] if len(teams) > 1 else {})
        away_s = away_t.get('shortDisplayName') or away_t.get('displayName') or 'Away'
        home_s = home_t.get('shortDisplayName') or home_t.get('displayName') or 'Home'

        when = probe.format_kickoff(game) if probe and hasattr(probe, 'format_kickoff') else ''
        when = when or game.get('status_detail', '') or 'Scheduled'
        network = game.get('broadcast', '') or ''
        meta = ' \u00b7 '.join(x for x in (when, network) if x)

        li = xbmcgui.ListItem(
            label='[B]%s @ %s[/B][CR][COLOR=panel_fg_50]%s[/COLOR]' % (away_s, home_s, meta))
        if probe and hasattr(probe, 'format_game_art'):
            li.setArt(probe.format_game_art(game))
        li.setInfo('video', {
            'title': '%s at %s' % (away_s, home_s),
            'plot': '%s\n\nNot started yet. This game has not begun, so there is no stream '
                    'to resolve.' % meta,
            'tagline': _sport_label(probe, game.get('sport', '')),
            'genre': _sport_label(probe, game.get('sport', '')),
        })
        # NOT playable. A game that has not kicked off cannot resolve to a stream, and
        # offering Play would spend the whole 25s resolve budget on a busy dialog before
        # failing. Clicking simply re-lists, which is a refresh.
        li.setProperty('IsPlayable', 'false')
        refresh = {'action': 'sports'}
        if sport_filter:
            refresh['sport'] = sport_filter
        if skip_hero:
            refresh['skip_hero'] = '1'
        xbmcplugin.addDirectoryItem(HANDLE, build_url(**refresh), li, True)


def sports_menu(hero_only=False, sport_filter=None, skip_hero=False):
    """Render the live sports list for the Sports Hub (1101 widget / action=sports route).

    When hero_only=True (action=sports_hero / Spotlight 301 container), renders only
    the hero game with rich hero plot (format_hero_plot). When hero_only=False (Wall
    grid 501 container), renders all live games with standard plot (format_hero_plot
    is applied to hero only).

    sport_filter narrows the listing to one league (action=sports&sport=nfl), which is what
    lets the Arctic Fuse Wall selector carry a category per league. It is named
    sport_filter, not sport, so it cannot shadow the per-game `sport` inside the render
    loop below.

    skip_hero drops the ONE game the Spotlight is already showing, so it is not printed
    twice on the same screen. It is a URL parameter rather than something inferred here,
    because whether the Spotlight is on is a skin setting and this code renders a plugin
    listing - it has no business guessing at the skin's configuration. The node JSON turns
    it on, which is the same file that decides the layout in the first place.
    """
    games, state, rotation, order = _read_sports_cache()
    probe = _load_sports_probe()
    upcoming = []

    if games is None:
        if probe is None:
            games, state = [], SPORTS_STATE_NO_RESOLVER
            log('sports probe module not available (resources/lib missing from the add-on?)',
                xbmc.LOGERROR)
        else:
            try:
                games, state, truncated, next_rotation, upcoming = _collect_live_games(probe, rotation, previous_order=order)
            except Exception as exc:  # noqa: BLE001
                log('error querying ESPN live sports: %s' % exc, xbmc.LOGWARNING)
                games, state, truncated, next_rotation, upcoming = [], SPORTS_STATE_UNREACHABLE, False, rotation, []
            order = [str(g.get('id') or g.get('name') or '') for g in games]
            _write_sports_cache(games, state, truncated, next_rotation, order=order, upcoming=upcoming)
    else:
        upcoming = _read_sports_upcoming()

    # The Spotlight route (action=sports_hero) is UNFILTERED, so the game it displays is the
    # first of the whole ordered list. Take its id before narrowing to a league: "index 0 of
    # this category" is a different game and dropping that would hide a fixture nothing else
    # is showing.
    hero_id = ''
    if skip_hero and not hero_only:
        if games:
            live_first = [g for g in games if not g.get('is_channel')]
            if live_first:
                hero_id = str(live_first[0].get('id') or live_first[0].get('name') or '')
            elif upcoming:
                hero_id = str(upcoming[0].get('id') or upcoming[0].get('name') or '')
        elif upcoming:
            hero_id = str(upcoming[0].get('id') or upcoming[0].get('name') or '')

    # Per-league views filter HERE, after the sweep and after the cache write, never inside
    # _collect_live_games. The cache stays fleet-wide on purpose: every league category on
    # the hub reads the same one, so five categories cost ONE set of ESPN fetches rather
    # than five, and they cannot disagree with each other or with the hero. Filtering
    # upstream would also poison the cache for whichever category happened to populate it.
    if sport_filter:
        if sport_filter not in MONITORED_SPORTS:
            # Never claim "no live games" for a scoreboard that was never fetched.
            log('per-league view requested for unmonitored sport %r (monitored: %s)'
                % (sport_filter, ', '.join(MONITORED_SPORTS)), xbmc.LOGWARNING)
            games, upcoming, state = [], [], SPORTS_STATE_NOT_MONITORED
        else:
            games = [g for g in games if g.get('sport') == sport_filter]
            upcoming = [g for g in upcoming if g.get('sport') == sport_filter]
            # A monitored league with nothing on is a quiet night for THAT league, not a
            # fault. Carrying the fleet-wide state through would put "could not reach ESPN"
            # on an idle category while the other categories are happily listing games.
            if not games and state == SPORTS_STATE_OK:
                state = SPORTS_STATE_NO_GAMES

    # Drop the Spotlight's game from the grid beneath it. The guard matters more than the
    # feature: if this category's ONLY game is the hero, skipping would leave an empty
    # category rendering "No live games right now" directly under a tile proving otherwise.
    # Better a duplicate than a lie.
    if hero_id:
        deduped = [g for g in games if str(g.get('id') or g.get('name') or '') != hero_id]
        if deduped:
            games = deduped
        deduped_up = [g for g in upcoming if str(g.get('id') or g.get('name') or '') != hero_id]
        if deduped_up or games:
            upcoming = deduped_up

    xbmcplugin.setContent(HANDLE, 'videos')
    try:
        live_games = [g for g in games if not g.get('is_channel')] if games else []
        channel_games = [g for g in games if g.get('is_channel')] if games else []
        favs = get_sports_favourites()
        quality_map = _read_quality_cache()
        unprobed_games = []

        def _render_game_list(items, is_hero=False):
            for i, game in enumerate(items):
                sport = game.get('sport', 'mlb')
                teams = game.get('teams', [])
                if len(teams) >= 2:
                    away_t = next((t for t in teams if t.get('homeAway') == 'away'), teams[0])
                    home_t = next((t for t in teams if t.get('homeAway') == 'home'), teams[1])
                elif len(teams) == 1:
                    away_t = teams[0]
                    home_t = {'displayName': 'TBD', 'score': '', 'abbreviation': 'TBD'}
                else:
                    away_t = {'displayName': 'Away', 'score': '', 'abbreviation': 'AWY'}
                    home_t = {'displayName': 'Home', 'score': '', 'abbreviation': 'HME'}

                away_name = away_t.get('displayName') or away_t.get('shortDisplayName') or 'Away'
                home_name = home_t.get('displayName') or home_t.get('shortDisplayName') or 'Home'
                # SHORT names for anything the skin prints as a heading. Arctic Fuse gives the
                # window title two lines and then clips, so "Cleveland Guardians at Baltimore
                # Orioles" renders as "Cleveland Guardians at" - a headline that stops
                # mid-sentence. "Guardians at Orioles" fits one line. The FULL names stay on
                # team1/team2 in the play URL below, because that is what the stream resolver
                # matches schedule entries against; shortening those would break playback.
                away_short = away_t.get('shortDisplayName') or away_name
                home_short = home_t.get('shortDisplayName') or home_name
                game_id = str(game.get('id') or game.get('name') or '')

                # Quality lookup
                q_entry = quality_map.get(game_id) if isinstance(quality_map, dict) else None
                has_entry = isinstance(q_entry, dict)
                quality = q_entry.get('quality') if has_entry else None
                servers = q_entry.get('servers') if has_entry else None
                source = q_entry.get('source') if has_entry else None
                probed = has_entry

                if game.get('state') == 'in' and not has_entry and not game.get('is_channel'):
                    unprobed_games.append(game)

                is_fav = False
                if favs:
                    for t in teams:
                        if str(t.get('id', '')) in favs:
                            is_fav = True
                            break

                if probe and hasattr(probe, 'format_tile_label'):
                    tile_label = probe.format_tile_label(game, quality=quality)
                else:
                    tile_sep = ' vs ' if sport == 'boxing' else ' @ '
                    tile_label = f"[B]{away_name}{tile_sep}{home_name}[/B]"

                if is_hero:
                    if probe and hasattr(probe, 'format_hero_plot'):
                        plot = probe.format_hero_plot(
                            game,
                            is_fav=is_fav,
                            quality=quality,
                            servers=servers,
                            source=source,
                            probed=probed,
                        )
                    else:
                        plot = game.get('name', tile_label)
                else:
                    title_sep_long = ' vs ' if sport == 'boxing' else ' at '
                    plot = game.get('name') or f"{away_name}{title_sep_long}{home_name}"

                if probe and hasattr(probe, 'format_game_art'):
                    art = probe.format_game_art(game)
                else:
                    art = {'icon': 'special://skin/extras/icons/trophy.png', 'thumb': 'special://skin/extras/icons/trophy.png'}

                if game.get('is_channel'):
                    channel_icon = None
                    for cand in [
                        'special://skin/extras/icons/sw/nfl.png',
                        'special://skin/extras/icons/nfl.png',
                        'special://skin/extras/icons/trophy.png',
                    ]:
                        if hasattr(xbmcvfs, 'exists') and xbmcvfs.exists(cand):
                            channel_icon = cand
                            break
                    if not channel_icon:
                        channel_icon = 'special://skin/extras/icons/trophy.png'
                    art = {'icon': channel_icon, 'thumb': channel_icon}

                li = xbmcgui.ListItem(label=tile_label)
                li.setArt(art)
                sport_label = _sport_label(probe, sport)
                title_sep = ' vs ' if sport == 'boxing' else ' at '
                item_title = game.get('name') if game.get('is_channel') else f"{away_short}{title_sep}{home_short}"
                li.setInfo('video', {
                    'title': item_title,
                    'plot': plot,
                    'tagline': sport_label,
                    'genre': sport_label,
                })
                li.setProperty('IsPlayable', 'true')
                li.setProperty('sport', sport)

                if sport == 'nfl' and not game.get('is_channel'):
                    rz_url = build_url(
                        action='play_sport',
                        sport='nfl',
                        game_name='NFL RedZone',
                        team1='NFL RedZone',
                        team2='NFL RedZone',
                    )
                    net_url = build_url(
                        action='play_sport',
                        sport='nfl',
                        game_name='NFL Network',
                        team1='NFL Network',
                        team2='NFL Network',
                    )
                    if hasattr(li, 'addContextMenuItems'):
                        li.addContextMenuItems([
                            ('Watch on NFL RedZone', f'PlayMedia({rz_url})'),
                            ('Watch on NFL Network', f'PlayMedia({net_url})'),
                        ])

                url = build_url(
                    action='play_sport',
                    sport=sport,
                    game_name=game.get('name', ''),
                    team1=away_name,
                    team2=home_name,
                )
                xbmcplugin.addDirectoryItem(HANDLE, url, li, False)

        # Three distinct, on-screen-distinguishable rows. "No live games" must never be
        # shown for a missing resolver or a dead network: that is a false statement the
        # device is in no position to make, and it is invisible without reading kodi.log.
        def _render_empty_row():
            title, plot = SPORTS_EMPTY_ROWS.get(state, SPORTS_EMPTY_ROWS[SPORTS_STATE_NO_GAMES])
            if sport_filter:
                label = _sport_label(probe, sport_filter)
                # Name the league. Five categories showing an identical "No live games" row
                # is unreadable on a TV, and gives no clue which one is idle.
                title = '%s - %s' % (label, title)
                if state == SPORTS_STATE_NO_GAMES:
                    # The fleet-wide plot says "nothing in progress across the monitored
                    # sports", which is FALSE on screen the moment a neighbouring category
                    # is listing games - and an idle CFB tile sitting beside a live MLB one
                    # is the normal midweek case, not an edge case.
                    plot = ('ESPN answered and reported nothing in progress for %s. Other '
                            'leagues may still have games on - check the other categories.'
                            % label)
            icon = 'special://skin/extras/icons/trophy.png'
            li = xbmcgui.ListItem(label=title)
            li.setArt({'icon': icon, 'thumb': icon})
            li.setInfo('video', {'title': title, 'plot': plot})
            # Clicking used to ask Kodi to play '' - point it back at this listing so the
            # click is simply a retry. The retry must stay INSIDE the league, or an idle
            # NFL category silently becomes the unfiltered all-games list on one click.
            retry = {'action': 'sports'}
            if sport_filter:
                retry['sport'] = sport_filter
            if skip_hero:
                retry['skip_hero'] = '1'
            xbmcplugin.addDirectoryItem(HANDLE, build_url(**retry), li, True)

        if state not in (SPORTS_STATE_OK, SPORTS_STATE_NO_GAMES):
            _render_empty_row()
        elif hero_only:
            if live_games:
                _render_game_list(live_games[:1], is_hero=True)
            elif upcoming:
                # NOTHING LIVE, BUT SOMETHING SCHEDULED. These fixtures came out of the same
                # scoreboard payload as the live sweep and used to be thrown away, so the hub
                # said "no live games right now" while the device held tomorrow's kickoff in
                # memory. Gated on NO_GAMES on purpose: an unreachable ESPN or a missing
                # resolver still reports itself, because a cached slate must never paper over
                # a fault.
                _add_upcoming_items(probe, upcoming[:1], sport_filter, skip_hero)
            else:
                _render_empty_row()
        else:
            has_rendered = False
            if live_games:
                _render_game_list(live_games, is_hero=False)
                has_rendered = True
            if upcoming:
                # WHAT IS ON NEXT, under what is on now. Without this a league mid-slate shows
                # only its live games and then, the moment the last one ends, jumps to a list of
                # fixtures as if the schedule had appeared from nowhere. The hero stays a live
                # game: hero_only renders one item and it should be one you can actually play.
                _add_upcoming_items(probe, upcoming, sport_filter, skip_hero)
                has_rendered = True
            if channel_games:
                _render_game_list(channel_games, is_hero=False)
                has_rendered = True
            if not has_rendered:
                _render_empty_row()

        if unprobed_games and probe and not getattr(probe, '_DISABLE_BG_PROBE', False):
            _probe_games_quality_bg(probe, unprobed_games)
    finally:
        # cacheToDisc=False: Kodi's directory cache works directly against a listing whose
        # whole point is 60-second freshness.
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


# Click-to-play budget. fetch_schedule makes four sequential HTTP requests (SE pointer, SE
# schedule, BS pointer, BS schedule) before the first resolve is even attempted, and each
# resolve_stage_b is two or more more. With a blackholed pointer host that is minutes of an
# uncancellable busy dialog on a TV box, which reads as a hang and gets Kodi force-stopped -
# losing whatever guisettings.xml had not been flushed.
#
# What this DOES guarantee: no new candidate is started once the budget is gone, per-call
# timeouts are clamped to what is left, and the user can cancel between attempts. What it
# does NOT guarantee is a hard ceiling on total time - urlopen(timeout=) is per socket
# operation and does not cover DNS, so one call in flight can still overrun. Same honest
# caveat as TOTAL_SPORTS_BUDGET.
PLAY_RESOLVE_BUDGET = 25.0    # total wall-clock seconds allowed for a click-to-play resolve
PLAY_SCHEDULE_TIMEOUT = 10    # per-request ceiling for the schedule fetch
PLAY_RESOLVE_TIMEOUT = 8      # per-request ceiling for one stage-B resolve
MAX_PLAY_CANDIDATES = 3       # candidate schedule entries tried before giving up


def _stream_host(piped_url):
    """Host only, for logging. The full resolved URL carries the scraped headers and is a
    live credential of sorts - and kodi.log is the file people paste into forums.

    `.hostname`, never `.netloc`. netloc preserves the whole authority component including
    any `user:pass@` userinfo, so a resolver that ever returned an authenticated URL would
    write the credential straight into the log this function exists to keep clean. No
    provider carries userinfo today; using hostname makes that leak structurally
    impossible rather than incidentally absent. It also lowercases the host and drops any
    port, both of which are fine for a log line."""
    try:
        return urlparse(piped_url.split('|')[0]).hostname or 'unknown-host'
    except Exception:  # noqa: BLE001
        return 'unknown-host'


def play_sport(params):
    """Resolve and play a live game stream on click, inside a wall-clock budget."""
    sport = params.get('sport', '')
    game_name = params.get('game_name', '')
    team1 = params.get('team1', '')
    team2 = params.get('team2', '')

    probe = _load_sports_probe()
    if not probe or not sport:
        log('could not load sports probe for playback', xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        xbmcgui.Dialog().notification(ADDON_NAME, 'Live sports resolver unavailable', ICON, 4000)
        return

    teams = []
    if team1:
        teams.append({'displayName': team1})
    if team2:
        teams.append({'displayName': team2})
    game = {
        'name': game_name or (f"{team1} at {team2}" if team1 and team2 else ''),
        'teams': teams,
    }

    started = time.time()

    def _remaining():
        return PLAY_RESOLVE_BUDGET - (time.time() - started)

    try:
        monitor = xbmc.Monitor()
    except Exception:  # noqa: BLE001
        monitor = None

    try:
        sched_started = time.time()
        schedule = probe.fetch_schedule(
            sport, timeout=max(2.0, min(PLAY_SCHEDULE_TIMEOUT, _remaining())))
        sched_secs = time.time() - sched_started

        # Match on the ENTRY, not on its display title. entry_matches_game decides from
        # the href slug, which carries both team names in full, and falls back to the title
        # only when the entry has no usable slug. That is what makes a college game
        # clickable at all: the game rebuilt above carries displayName ONLY - no location,
        # abbreviation or shortDisplayName - and the title matcher needs those to name a
        # school, so every college click used to end in reason=no_match on a real device.
        # KNOWN RECALL GAP (review advisory 2, 2026-08-29, deliberately not fixed): the flip
        # side of carrying displayName only is that a TRUNCATED slug - one where SE dropped
        # a nickname, leaving just the school - cannot match HERE, because covering that
        # side needs `location`. It is a MISSED match, never a wrong one: the click resolves
        # nothing and logs reason=no_match rather than routing to a different game. Listing
        # is unaffected; it builds games from the full ESPN payload, locations included.
        # getattr, because a hand-packaged zip can ship this default.py against an older
        # resources/lib; there the title-only call is still better than a traceback.
        match_entry = getattr(probe, 'entry_matches_game', None)
        if match_entry is None:
            # Failing loudly on a stale device would be worse than degrading, but degrading
            # SILENTLY is how this stays undiagnosable: on such a device every collision the
            # slug engine was built to remove comes back, college clicks stop matching at
            # all, and the only trace in kodi.log is `reason=no_match` - which reads exactly
            # like a quiet night on StreamEast. Name the cause here so the log says it.
            log('STALE resources/lib: vendored probe_live_sports has no entry_matches_game, '
                'so slug matching is unavailable and this click falls back to the TITLE '
                'matcher - it cannot match college games and can mis-match pro ones. '
                'Update or reinstall the StarWave Wizard to refresh resources/lib.',
                xbmc.LOGWARNING)
        matching_entries = []
        seen_hrefs = set()
        for entry in schedule:
            href = entry.get('href')
            if not href or href in seen_hrefs:
                continue
            if match_entry is not None:
                matched = match_entry(entry, game)
            else:
                matched = probe.schedule_matches_game(entry.get('teams', ''), game)
            if not matched:
                continue
            seen_hrefs.add(href)
            matching_entries.append(entry)
            # SE, BS and their mirrors can all match one game; without a cap a single click
            # walks every one of them at ~8s a piece.
            if len(matching_entries) >= MAX_PLAY_CANDIDATES:
                break

        resolved_piped = None
        budget_spent = False
        cancelled = False
        # One (provider, host, seconds) tuple per resolve actually attempted. This is the
        # half of the failure story the old single log line could not tell: "no playable
        # stream" read the same whether the schedule came back empty, nothing matched, or
        # three resolves were tried and every one of them died.
        attempts = []

        for entry in matching_entries:
            if monitor is not None and monitor.abortRequested():
                cancelled = True
                log('live stream resolve cancelled before trying %s' % entry.get('provider', 'SE'))
                break
            remaining = _remaining()
            if remaining < 1.0:
                budget_spent = True
                log('play budget spent after %.1fs; giving up on %s'
                    % (time.time() - started, game.get('name')), xbmc.LOGWARNING)
                break
            attempt_started = time.time()
            piped = probe.resolve_stage_b(
                entry['href'],
                timeout=max(1.0, min(PLAY_RESOLVE_TIMEOUT, remaining)),
                provider=entry.get('provider', 'SE'),
            )
            # Provider and HOST only - never entry['href'] in full and never the resolved
            # URL, which carries the scraped headers the host authenticates on.
            attempts.append((entry.get('provider', 'SE'), _stream_host(entry['href']),
                             time.time() - attempt_started, bool(piped)))
            if piped:
                resolved_piped = piped
                break

        if resolved_piped:
            if '|' in resolved_piped:
                bare_url, raw_headers = resolved_piped.split('|', 1)
            else:
                bare_url, raw_headers = resolved_piped, ''

            header_pairs = []
            header_keys = []
            if raw_headers:
                for part in raw_headers.split('&'):
                    if not part:
                        continue
                    if '=' in part:
                        k, v = part.split('=', 1)
                    else:
                        k, v = part, ''
                    header_pairs.append(f"{k}={quote(v, safe='')}")
                    header_keys.append(k)

            encoded_headers = '&'.join(header_pairs)

            play_item = xbmcgui.ListItem(path=bare_url)
            # Live HLS streams require inputstream.adaptive with manifest and stream headers
            # URL-encoded, and explicit HLS mime type declaration.
            try:
                play_item.setContentLookup(False)
                play_item.setMimeType('application/vnd.apple.mpegurl')
                play_item.setProperty('inputstream', 'inputstream.adaptive')
                play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
                play_item.setProperty('inputstream.adaptive.live_delay', '20')
                play_item.setProperty(
                    'inputstream.adaptive.manifest_config',
                    json.dumps({
                        'hls_ignore_endlist': True,
                        'hls_fix_mediasequence': True,
                        'hls_fix_discsequence': True,
                    })
                )
                play_item.setProperty(
                    'inputstream.adaptive.config',
                    json.dumps({'internal_cookies': True})
                )
                if encoded_headers:
                    play_item.setProperty('inputstream.adaptive.manifest_headers', encoded_headers)
                    play_item.setProperty('inputstream.adaptive.stream_headers', encoded_headers)
            except AttributeError:
                pass
            xbmcplugin.setResolvedUrl(HANDLE, True, play_item)
            # Host only - never the full piped URL, which carries the scraped headers.
            log('resolved live stream for %s from %s in %.1fs'
                % (game.get('name'), _stream_host(resolved_piped), time.time() - started))
            log('live sports playback engaged inputstream.adaptive for %s (%d header keys: %s)'
                % (game.get('name'), len(header_keys), ', '.join(header_keys) if header_keys else 'none'))
            # Carrying the headers as adaptive properties rather than a piped path is what
            # makes these hosts authenticate - but it also makes inputstream.adaptive
            # load-bearing. With ISA absent or disabled Kodi falls back to its own player
            # with a bare URL and NO headers at all, and the host answers 403 - which reads
            # on screen exactly like a dead stream. ffmpegdirect has already been observed
            # silently re-enabling itself on the Deck as a dependency default, so the
            # reverse is credible. Name it in the log rather than let it be undiagnosable.
            if addon_is_enabled('inputstream.adaptive') is not True:
                log('inputstream.adaptive is NOT enabled - live sports headers cannot be '
                    'applied and this host will answer 403. Run the wizard\'s "Fix live '
                    'streams" action, or enable inputstream.adaptive.', xbmc.LOGWARNING)
        else:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            # ONE terminal reason, decided in this order so it always names the thing that
            # actually stopped the click. A user's cancel outranks everything; a spent
            # budget outranks a failed resolve because the resolve never got its full
            # timeout; and no_schedule/no_match are only reachable when nothing was tried.
            if cancelled:
                reason = 'aborted'
            elif budget_spent:
                reason = 'budget_spent'
            elif not schedule:
                reason = 'no_schedule'
            elif not matching_entries:
                reason = 'no_match'
            elif attempts:
                reason = 'resolve_failed'
            else:
                reason = 'no_match'
            # The device-side diagnosis line. On the Shield this path printed nothing but
            # "no playable stream resolved for <game>", which cannot tell an empty schedule
            # from an unmatched title from three dead resolves - and the same module on a
            # Mac resolved that same game in 7.4s. Every number needed to tell those apart
            # is here, on one line, at a level service logs keep.
            log('live sports resolve FAILED reason=%s sport=%s game=%r '
                'schedule_entries=%d schedule_secs=%.1f candidates=%d attempts=%d '
                'total_secs=%.1f budget=%.1f'
                % (reason, sport, game.get('name'), len(schedule or []), sched_secs,
                   len(matching_entries), len(attempts), time.time() - started,
                   PLAY_RESOLVE_BUDGET), xbmc.LOGWARNING)
            if attempts:
                # Host only, per attempt - which mirror was tried, and how long it burned.
                log('live sports resolve attempts: %s'
                    % '; '.join('%s %s %.1fs %s' % (prov, host, secs, 'ok' if ok else 'none')
                                for prov, host, secs, ok in attempts), xbmc.LOGWARNING)
            if budget_spent:
                xbmcgui.Dialog().notification(
                    ADDON_NAME, 'Timed out finding a stream - try again', ICON, 4000)
            elif not cancelled:
                xbmcgui.Dialog().notification(ADDON_NAME, 'Stream unavailable for this game', ICON, 4000)
    except Exception as exc:  # noqa: BLE001
        log('playback resolution failed: %s' % exc, xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        xbmcgui.Dialog().notification(ADDON_NAME, 'Stream resolution error', ICON, 4000)


def addon_is_enabled(addon_id):
    """Read an add-on's enabled state. Returns True, False, or None if it is not installed.

    The mirror image of set_addon_enabled, and it uses the same two mechanisms for the same
    reason: JSON-RPC is what a running Kodi believes, and Addons33.db is what is on disk.
    They can disagree, so the JSON-RPC answer wins when there is one and the database only
    answers when Kodi will not.
    """
    if not is_addon_installed(addon_id):
        return None
    payload = json.dumps({
        'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.GetAddonDetails',
        'params': {'addonid': addon_id, 'properties': ['enabled']},
    })
    try:
        raw = xbmc.executeJSONRPC(payload)
        res = json.loads(raw) if raw else {}
        addon = (res.get('result') or {}).get('addon') or {}
        if 'enabled' in addon:
            return bool(addon['enabled'])
    except Exception as exc:   # noqa: BLE001
        log('could not read %s enabled state via JSON-RPC: %s' % (addon_id, exc), xbmc.LOGWARNING)

    addons_db = os.path.join(HOME, 'userdata', 'Database', 'Addons33.db')
    if os.path.exists(addons_db):
        con = None
        try:
            # Read-only, and with a short timeout, because this runs in the startup service
            # against the database a live Kodi has open. A plain read-write connect waits out
            # sqlite's 5 second default on every add-on asked about, which would stall the boot
            # check for no gain: nothing here ever writes.
            # as_uri() percent-escapes the path. Interpolating it raw would let a '?' or '#'
            # in the path truncate the URI, silently dropping mode=ro and opening the
            # database read-write-create.
            uri = pathlib.Path(addons_db).as_uri() + '?mode=ro'
            con = sqlite3.connect(uri, uri=True, timeout=1.0)
            row = con.execute('SELECT enabled FROM installed WHERE addonID = ?',
                              (addon_id,)).fetchone()
            if row is not None:
                return bool(row[0])
        except Exception as exc:  # noqa: BLE001
            log('could not read %s from Addons33.db: %s' % (addon_id, exc), xbmc.LOGWARNING)
        finally:
            if con is not None:
                try:
                    con.close()
                except Exception:  # noqa: BLE001
                    pass
    return None


def ensure_live_stack():
    """Re-assert the live-stream add-on stack on every boot, not once per install.

    adaptive on and ffmpegdirect off is what makes live streams play at all, and it used to be
    a one-shot: applied at install and by the manual menu action, then never checked again.
    On the owner's Steam Deck ffmpegdirect was found enabled again seven days after the fix,
    which silently killed every live stream with nothing in the UI to say why. Kodi re-enables
    a disabled binary add-on on its own when a dependency pulls it back in, so the only safe
    shape is an invariant re-checked at startup rather than a button someone has to remember.

    Returns a list of human-readable lines, EMPTY when everything was already correct, so a
    healthy boot stays silent in the log and any output at all means a regression was repaired.
    Never raises: a failure here must not be able to break Kodi startup.
    """
    # The same platform gate _apply() uses. On Android the build ships its own binaries and
    # this stack is correct out of the box, so there is nothing to re-assert.
    if not (is_flatpak() or is_steamos() or not is_android()):
        return []

    lines = []
    try:
        for a in LIVE_ENABLE:
            state = addon_is_enabled(a)
            if state is None:
                # Deliberately NOT installed here, and deliberately silent about it. Fetching a
                # missing add-on is install-time work (live_fix_kodi_side does it); a boot check
                # only repairs what is present. service.py logs every line this returns at
                # LOGWARNING, so saying anything would warn on every boot forever on a device
                # that is missing one - which includes a fresh Steam Machine, where ANDROID_ONLY
                # skips inputstream.adaptive on extract and this runs before it is installed.
                # Same shape as the LIVE_DISABLE loop below, which already skips silently.
                continue
            if state:
                continue
            r = set_addon_enabled(a, True)
            if r:
                lines.append('CORRECTED: %s was disabled, re-enabled' % a)
            else:
                lines.append('[COLOR red]%s was disabled and could not be re-enabled.[/COLOR]' % a)
        for a in LIVE_DISABLE:
            state = addon_is_enabled(a)
            if state is None or not state:
                continue
            r = set_addon_enabled(a, False)
            if r:
                lines.append('CORRECTED: %s was enabled, disabled again '
                              '(this breaks live streams)' % a)
            else:
                lines.append('[COLOR red]%s was enabled and could not be disabled.[/COLOR]' % a)
    except Exception as exc:   # noqa: BLE001 - a boot invariant must never raise
        log('live stack check failed: %s' % exc, xbmc.LOGWARNING)
        return ['[COLOR red]Live stack check failed: %s[/COLOR]' % exc]

    # The Crew's cache is deliberately NOT cleared here. That is expensive and it is
    # install-time behaviour, not an invariant that has to hold on every boot.
    return lines


def live_fix_kodi_side():
    """Apply the Kodi-side live-stream fix (adaptive on, ffmpegdirect off, clear Crew cache).
    Returns a list of human lines. Shared by the standalone action and by an install on Flatpak,
    so a Steam Deck install ends already fixed Kodi-side."""
    lines = []
    for a in LIVE_ENABLE:
        # On Android the build ships this itself. Anywhere else it has to come from Kodi's own
        # repository, and without it live streams cannot play at all - so install it rather
        # than reporting it missing.
        if not is_android():
            state = ensure_addon(a)
            if state == 'failed':
                lines.append('[COLOR red]%s: missing and could not be installed.[/COLOR]' % a)
                continue
            if state == 'installed':
                lines.append('%s: installed' % a)
        r = set_addon_enabled(a, True)
        if r is None:
            lines.append('%s: not installed, skipped.' % a)
        elif r:
            lines.append('%s: on' % a)
        else:
            lines.append('[COLOR red]%s: could not enable.[/COLOR]' % a)
    for a in LIVE_DISABLE:
        r = set_addon_enabled(a, False)
        if r is None:
            lines.append('%s: not installed' % a)
        elif r:
            lines.append('%s: off' % a)
        else:
            lines.append('[COLOR red]%s: could not disable.[/COLOR]' % a)
    cleared = clear_crew_cache()
    lines.append("The Crew's cache: cleared" if cleared
                 else "The Crew's cache: nothing to clear")
    return lines


# --- per-device tuning ----------------------------------------------------------------
# Two Kodi settings are right on one device and wrong on another, so they can never travel in
# a build payload - the wizard already strips them on capture (DEVICE_PREFIXES / DEVICE_EXACT)
# for exactly that reason. They are detected here instead, from facts about the hardware:
#
#   refresh switching  A Steam Deck's internal panel offers exactly ONE resolution, so asking
#                      Kodi to change mode at every playback start and stop is a KMS modeset
#                      with nowhere to go. Measured on the Deck: 1 option. On the Shield, on a
#                      TV: 4 options. A Steam Machine on a TV looks like the Shield and WANTS
#                      refresh switching, or 24p judders - so the rule keys on the mode count,
#                      not on the operating system.
#
#   passthrough        When passthrough is aimed at a different device than normal audio, the
#                      bitstream path goes somewhere the sound does not. On the Deck that was
#                      ALSA:hdmi:CARD=Generic,DEV=0 while audio played through PulseAudio, with
#                      the machine undocked - so AC3 content opened raw HDMI hardware behind
#                      PipeWire's back. On a working receiver the two devices are the SAME
#                      string (verified on the Shield), so a real passthrough setup never
#                      matches this rule.
GEARS_SCRAPER_FIX = (
    ('provider.external', 'true', ('true',)),
    ('external_scraper.module', 'script.module.gearsscrapers', ('empty_setting', '')),
)


def _rpc(method, params=None):
    """JSON-RPC against this running Kodi. Returns the parsed reply, or {} on failure."""
    payload = json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params or {}})
    try:
        return json.loads(xbmc.executeJSONRPC(payload))
    except Exception as exc:  # noqa: BLE001
        log('json-rpc %s failed: %s' % (method, exc), xbmc.LOGWARNING)
        return {}


def display_mode_count():
    """How many resolutions this display offers. 1 means there is nothing to switch to.
    Returns 0 when Kodi will not say, which every caller treats as "do not touch"."""
    r = _rpc('Settings.GetSettings',
             {'level': 'expert', 'filter': {'section': 'system', 'category': 'display'}})
    for st in r.get('result', {}).get('settings', []):
        if st.get('id') == 'videoscreen.resolution':
            return len(st.get('options') or [])
    return 0


def _gui_read(text, sid):
    """Value of one setting in a guisettings.xml body, or None if it is not there."""
    m = re.search(r'<setting id="%s"[^>]*>([^<]*)</setting>' % re.escape(sid), text)
    return m.group(1) if m else None


def _gui_write(text, sid, value):
    """Set one setting in a guisettings.xml body. Drops Kodi's default="true" marker, which is
    what capture-build.py keys on to tell touched settings from untouched ones. Returns
    (text, changed)."""
    pat = r'<setting id="%s"[^>]*>[^<]*</setting>' % re.escape(sid)
    repl = '<setting id="%s">%s</setting>' % (sid, value)
    new, n = re.subn(pat, repl, text)
    return (new, True) if n else (text, False)


def _settings_io(on_disk):
    """Return (get, set, commit) for whichever Kodi we are talking to.

    on_disk  the install path. Kodi is about to be killed with os._exit(1), which deliberately
             skips writing guisettings.xml, so the only change that survives is one made to the
             file. Same reasoning as set_skin_on_disk.
    live     the standalone action. Kodi keeps running and WILL write its in-memory settings
             over the file on exit, so the change has to go through Kodi itself.
    """
    if not on_disk:
        def get(sid):
            r = _rpc('Settings.GetSettingValue', {'setting': sid})
            return r.get('result', {}).get('value', None)

        def setv(sid, value):
            r = _rpc('Settings.SetSettingValue', {'setting': sid, 'value': value})
            return r.get('result') is True

        return get, setv, (lambda: None)

    state = {'text': None}
    if os.path.exists(GUISETTINGS):
        with open(GUISETTINGS, 'r', encoding='utf-8') as fh:
            state['text'] = fh.read()

    def get(sid):
        if state['text'] is None:
            return None
        raw = _gui_read(state['text'], sid)
        if raw is None:
            return None
        if raw in ('true', 'false'):
            return raw == 'true'
        try:
            return int(raw)
        except ValueError:
            return raw

    def setv(sid, value):
        if state['text'] is None:
            return False
        if isinstance(value, bool):
            value = 'true' if value else 'false'
        state['text'], ok = _gui_write(state['text'], sid, value)
        return ok

    def commit():
        if state['text'] is not None:
            with open(GUISETTINGS, 'w', encoding='utf-8') as fh:
                fh.write(state['text'])

    return get, setv, commit


def tune_this_device(on_disk):
    """Apply the two display-dependent fixes if this device needs them. Returns human lines,
    empty when nothing needed changing. Never guesses from the platform."""
    get, setv, commit = _settings_io(on_disk)
    lines = []

    modes = display_mode_count()
    if modes == 1 and get('videoplayer.adjustrefreshrate') not in (0, None):
        if setv('videoplayer.adjustrefreshrate', 0):
            lines.append('This display offers one resolution, so refresh-rate switching was '
                         'turned off - it was asking for a mode change with nowhere to go at '
                         'every play and stop.')

    if get('audiooutput.passthrough') is True:
        main = get('audiooutput.audiodevice')
        thru = get('audiooutput.passthroughdevice')
        if main and thru and main != thru:
            if setv('audiooutput.passthrough', False):
                lines.append('Audio passthrough pointed at a different device than your sound '
                             '(%s), so it was turned off. Turn it back on if you connect a '
                             'receiver.' % thru.split('|')[0])

    if lines:
        commit()
    return lines


SKINSHORTCUTS_REL = 'userdata/addon_data/script.skinshortcuts'
# The reference menus ship INSIDE this add-on (~230 KB) rather than being read out of the build
# payload. That is what lets icon changes arrive with a 500 KB add-on update instead of a 238 MB
# build download, and it means the sync can run at startup with nothing to fetch. Keep these in
# step with build-clean's copies - scripts/test-wizard.py asserts they match.
MENU_REF_DIR = os.path.join(ADDON.getAddonInfo('path'), 'resources', 'menu')
MENU_ART_KEYS = ('icon', 'thumb')
WIZARD_TILE_MARK = 'plugin.program.starwave.wizard'


def _parse_shortcut_meta(xml_text):
    """Map action -> {icon, thumb, description} for every <shortcut> in a skinshortcuts .DATA.xml."""
    out = {}
    for block in re.findall(r'<shortcut>.*?</shortcut>', xml_text, re.S):
        act = re.search(r'<action>(.*?)</action>', block, re.S)
        if not act:
            continue
        action_str = act.group(1).strip()
        meta = {}
        for key in MENU_ART_KEYS:
            m = re.search(r'<%s>(.*?)</%s>' % (key, key), block, re.S)
            if m:
                meta[key] = m.group(1).strip()
        m_desc = re.search(r'<property name="description">(.*?)</property>', block, re.S)
        if m_desc:
            meta['description'] = m_desc.group(1).strip()
        if meta:
            out[action_str] = meta
    return out


def _migrate_settings_data_xml(device_text):
    """Remove wizard actions from settings.DATA.xml and ensure Quit shortcut is present."""
    changes = 0
    nl = '\r\n' if '\r\n' in device_text else '\n'

    def strip_wizard(match):
        nonlocal changes
        block = match.group(0)
        act = re.search(r'<action>(.*?)</action>', block, re.S)
        if act and WIZARD_TILE_MARK in act.group(1):
            changes += 1
            return ''
        return block

    new_text = re.sub(r'[ \t]*<shortcut>.*?</shortcut>[ \t]*(\r?\n)?', strip_wizard, device_text, flags=re.S)

    has_quit = any('Quit()' in act for act in re.findall(r'<action>(.*?)</action>', new_text, re.S))
    if not has_quit:
        close = re.search(r'[ \t]*</shortcuts>', new_text)
        if close:
            quit_block = (
                '\t<shortcut>' + nl +
                '\t\t<defaultID />' + nl +
                '\t\t<label>Quit</label>' + nl +
                '\t\t<label2>Custom item</label2>' + nl +
                '\t\t<icon>special://skin/extras/icons/sw/exit.png</icon>' + nl +
                '\t\t<thumb>special://skin/extras/icons/sw/exit.png</thumb>' + nl +
                '\t\t<action>Quit()</action>' + nl +
                '\t\t<property name="description">Close Kodi.</property>' + nl +
                '\t</shortcut>' + nl
            )
            new_text = new_text[:close.start()] + quit_block + new_text[close.start():]
            changes += 1

    return new_text, changes


def _migrate_mainmenu_data_xml(device_text):
    """Remove 13009 shortcut and ensure Sports and TV shortcuts are present between Shows and Settings."""
    changes = 0
    nl = '\r\n' if '\r\n' in device_text else '\n'

    def strip_13009(match):
        nonlocal changes
        block = match.group(0)
        if ('<defaultID>13009</defaultID>' in block or
                '<label>13009</label>' in block or
                '<action>Quit()</action>' in block):
            changes += 1
            return ''
        return block

    new_text = re.sub(r'[ \t]*<shortcut>.*?</shortcut>[ \t]*(\r?\n)?', strip_13009, device_text, flags=re.S)

    labels = [lbl.strip().lower() for lbl in re.findall(r'<label>(.*?)</label>', new_text, re.S)]
    has_sports = 'sports' in labels or any('action=sports' in a or 'plugin.video.thecrew' in a for a in re.findall(r'<action>(.*?)</action>', new_text, re.S))
    if not has_sports:
        sports_block = (
            '\t<shortcut>' + nl +
            '\t\t<defaultID />' + nl +
            '\t\t<label>Sports</label>' + nl +
            '\t\t<label2>Custom item</label2>' + nl +
            '\t\t<icon>special://skin/extras/icons/sw/nfl.png</icon>' + nl +
            '\t\t<thumb>special://skin/extras/icons/sw/nfl.png</thumb>' + nl +
            '\t\t<action>ActivateWindow(Videos,"plugin://plugin.video.thecrew",return)</action>' + nl +
            '\t</shortcut>' + nl
        )
        shows_match = re.search(r'[ \t]*<shortcut>(?:(?!</shortcut>).)*?<label>Shows</label>.*?</shortcut>[ \t]*(\r?\n)?', new_text, re.S)
        if shows_match:
            insert_pos = shows_match.end()
            new_text = new_text[:insert_pos] + sports_block + new_text[insert_pos:]
            changes += 1
        else:
            settings_match = re.search(r'[ \t]*<shortcut>(?:(?!</shortcut>).)*?(?:<defaultID>settings</defaultID>|<label>10004</label>|<label>Settings</label>).*?</shortcut>', new_text, re.S)
            if settings_match:
                insert_pos = settings_match.start()
                new_text = new_text[:insert_pos] + sports_block + new_text[insert_pos:]
                changes += 1
            else:
                close = re.search(r'[ \t]*</shortcuts>', new_text)
                if close:
                    new_text = new_text[:close.start()] + sports_block + new_text[close.start():]
                    changes += 1

    labels = [lbl.strip().lower() for lbl in re.findall(r'<label>(.*?)</label>', new_text, re.S)]
    has_tv = 'tv' in labels or any('plugin://slyguy.pluto.tv.provider' in a for a in re.findall(r'<action>(.*?)</action>', new_text, re.S))
    if not has_tv:
        tv_block = (
            '\t<shortcut>' + nl +
            '\t\t<defaultID />' + nl +
            '\t\t<label>TV</label>' + nl +
            '\t\t<label2>Custom item</label2>' + nl +
            '\t\t<icon>special://skin/extras/icons/sw/livetv.png</icon>' + nl +
            '\t\t<thumb>special://skin/extras/icons/sw/livetv.png</thumb>' + nl +
            '\t\t<action>ActivateWindow(Videos,"plugin://slyguy.pluto.tv.provider/",return)</action>' + nl +
            '\t\t<visible>System.HasAddon(slyguy.pluto.tv.provider)</visible>' + nl +
            '\t</shortcut>' + nl
        )
        sports_match = re.search(r'[ \t]*<shortcut>(?:(?!</shortcut>).)*?<label>Sports</label>.*?</shortcut>[ \t]*(\r?\n)?', new_text, re.S)
        if sports_match:
            insert_pos = sports_match.end()
            new_text = new_text[:insert_pos] + tv_block + new_text[insert_pos:]
            changes += 1
        else:
            settings_match = re.search(r'[ \t]*<shortcut>(?:(?!</shortcut>).)*?(?:<defaultID>settings</defaultID>|<label>10004</label>|<label>Settings</label>).*?</shortcut>', new_text, re.S)
            if settings_match:
                insert_pos = settings_match.start()
                new_text = new_text[:insert_pos] + tv_block + new_text[insert_pos:]
                changes += 1
            else:
                close = re.search(r'[ \t]*</shortcuts>', new_text)
                if close:
                    new_text = new_text[:close.start()] + tv_block + new_text[close.start():]
                    changes += 1

    return new_text, changes


def _repoint_data_xml(device_text, build_meta):
    """Copy icon, thumb, and description from the build onto matching shortcuts by <action>."""
    changes = [0]

    def fix(block):
        shortcut_text = block.group(0)
        act = re.search(r'<action>(.*?)</action>', shortcut_text, re.S)
        if not act:
            return shortcut_text
        action_str = act.group(1).strip()
        want = build_meta.get(action_str)
        if not want:
            return shortcut_text
        out = shortcut_text
        for key in MENU_ART_KEYS:
            if key in want:
                val = want[key]
                pat = r'(<%s>)(.*?)(</%s>)' % (key, key)
                m = re.search(pat, out, re.S)
                if m:
                    if m.group(2).strip() != val:
                        out = out[:m.start(2)] + val + out[m.end(2):]
                        changes[0] += 1
                else:
                    close_sc = re.search(r'(\t*)</shortcut>', out)
                    if close_sc:
                        indent = close_sc.group(1) or '\t\t'
                        nl = '\r\n' if '\r\n' in out else '\n'
                        out = out[:close_sc.start()] + ('<%s>%s</%s>' % (key, val, key)) + nl + indent + out[close_sc.start():]
                        changes[0] += 1
        if 'description' in want:
            desc_val = want['description']
            m_desc = re.search(r'(<property name="description">)(.*?)(</property>)', out, re.S)
            if m_desc:
                if m_desc.group(2).strip() != desc_val:
                    out = out[:m_desc.start(2)] + desc_val + out[m_desc.end(2):]
                    changes[0] += 1
            else:
                close_sc = re.search(r'(\t*)</shortcut>', out)
                if close_sc:
                    indent = close_sc.group(1) or '\t\t'
                    nl = '\r\n' if '\r\n' in out else '\n'
                    prop_tag = '<property name="description">%s</property>' % desc_val
                    out = out[:close_sc.start()] + prop_tag + nl + indent + out[close_sc.start():]
                    changes[0] += 1
        return out

    return re.sub(r'<shortcut>.*?</shortcut>', fix, device_text, flags=re.S), changes[0]


_REF_SPORTS_XML = """<shortcuts>
	<shortcut>
		<defaultID />
		<label>NFL</label>
		<label2>Custom item</label2>
		<icon>special://skin/extras/icons/sw/nfl.png</icon>
		<thumb>special://skin/extras/icons/sw/nfl.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.thecrew/?action=nfl",return)</action>
	</shortcut>
	<shortcut>
		<defaultID />
		<label>NHL</label>
		<label2>Custom item</label2>
		<icon>special://skin/extras/icons/sw/nhl.png</icon>
		<thumb>special://skin/extras/icons/sw/nhl.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.thecrew/?action=nhl",return)</action>
	</shortcut>
	<shortcut>
		<defaultID />
		<label>NBA</label>
		<label2>Custom item</label2>
		<icon>special://skin/extras/icons/sw/nba.png</icon>
		<thumb>special://skin/extras/icons/sw/nba.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.thecrew/?action=nba",return)</action>
	</shortcut>
	<shortcut>
		<defaultID />
		<label>MLB</label>
		<label2>Custom item</label2>
		<icon>special://skin/extras/icons/sw/mlb.png</icon>
		<thumb>special://skin/extras/icons/sw/mlb.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.thecrew/?action=mlb",return)</action>
	</shortcut>
	<shortcut>
		<defaultID />
		<label>UFC</label>
		<label2>Custom item</label2>
		<icon>special://skin/extras/icons/sw/ufc.png</icon>
		<thumb>special://skin/extras/icons/sw/ufc.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.thecrew/?action=ufc",return)</action>
	</shortcut>
	<shortcut>
		<defaultID />
		<label>Boxing</label>
		<label2>Custom item</label2>
		<icon>special://skin/extras/icons/sw/boxing.png</icon>
		<thumb>special://skin/extras/icons/sw/boxing.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.thecrew/?action=boxing",return)</action>
	</shortcut>
</shortcuts>
"""

_REF_TV_XML = """<shortcuts>
	<shortcut>
		<defaultID />
		<label>Pluto TV</label>
		<label2>Custom item</label2>
		<icon>special://skin/extras/icons/sw/pluto.png</icon>
		<thumb>special://skin/extras/icons/sw/pluto.png</thumb>
		<action>ActivateWindow(Videos,"plugin://slyguy.pluto.tv.provider/",return)</action>
		<visible>System.HasAddon(slyguy.pluto.tv.provider)</visible>
		<property name="description">Free live TV channels from Pluto TV. No account needed.</property>
	</shortcut>
	<shortcut>
		<defaultID />
		<label>Samsung TV Plus</label>
		<label2>Custom item</label2>
		<icon>special://skin/extras/icons/sw/samsungtv.png</icon>
		<thumb>special://skin/extras/icons/sw/samsungtv.png</thumb>
		<action>ActivateWindow(Videos,"plugin://slyguy.samsung.tv.plus/",return)</action>
		<visible>System.HasAddon(slyguy.samsung.tv.plus)</visible>
		<property name="description">Samsung's free streaming channels. No account needed.</property>
	</shortcut>
	<shortcut>
		<defaultID />
		<label>The Roku Channel</label>
		<label2>Custom item</label2>
		<icon>special://skin/extras/icons/sw/roku.png</icon>
		<thumb>special://skin/extras/icons/sw/roku.png</thumb>
		<action>ActivateWindow(Videos,"plugin://slyguy.roku/",return)</action>
		<visible>System.HasAddon(slyguy.roku)</visible>
		<property name="description">Free movies, shows and live channels from Roku. No account needed.</property>
	</shortcut>
</shortcuts>
"""


def _repoint_properties(device_text, build_text):
    """Copy build's icon, thumb, and description values onto entries the device has,
    and remove obsolete entries (13009, starwave.*)."""
    try:
        dev = json.loads(device_text)
        bld = json.loads(build_text)
    except ValueError:
        return device_text, 0
    if not isinstance(dev, list) or not isinstance(bld, list):
        return device_text, 0

    remove_items = {
        ('mainmenu', '13009'),
        ('settings', 'starwave.wizard'),
        ('settings', 'starwave.layout'),
        ('settings', 'starwave.audio'),
        ('settings', 'starwave.backup'),
        ('settings', 'starwave.token'),
        ('settings', 'starwave.live'),
    }
    stock_crew_items = {'movie collection', 'tv collection', 'movie lists', 'tv show lists'}

    orig_len = len(dev)
    dev = [
        e for e in dev
        if not (isinstance(e, list) and len(e) >= 2 and (
            (e[0], e[1]) in remove_items or
            (e[0] == 'plugin-video-thecrew' and str(e[1]).lower() in stock_crew_items)
        ))
    ]
    changes = orig_len - len(dev)

    for e in dev:
        if isinstance(e, list) and len(e) == 4:
            if e[0] == 'sports':
                e[0] = 'plugin-video-thecrew'
                changes += 1
            elif e[0] == 'tv':
                e[0] = 'slyguy-pluto-tv-provider'
                changes += 1

    want = {}
    for e in bld:
        if isinstance(e, list) and len(e) == 4:
            want[(e[0], e[1], e[2])] = e[3]

    for e in dev:
        if not (isinstance(e, list) and len(e) == 4):
            continue
        key = (e[0], e[1], e[2])
        new = want.get(key)
        if new is not None and e[3] != new:
            e[3] = new
            changes += 1

    dev_keys = set((e[0], e[1], e[2]) for e in dev if isinstance(e, list) and len(e) == 4)
    for key, val in want.items():
        group, item, prop = key
        if prop == 'description':
            item_exists = any(e[0] == group and e[1] == item for e in dev if isinstance(e, list) and len(e) == 4)
            if item_exists and key not in dev_keys:
                dev.append([group, item, prop, val])
                dev_keys.add(key)
                changes += 1
        elif group == 'settings' and item == 'quit':
            group_exists = any(e[0] == 'settings' for e in dev if isinstance(e, list) and len(e) == 4)
            if group_exists and key not in dev_keys:
                dev.append([group, item, prop, val])
                dev_keys.add(key)
                changes += 1
        elif group in ('plugin-video-thecrew', 'slyguy-pluto-tv-provider') or (group == 'mainmenu' and item in ('sports', 'tv')):
            if key not in dev_keys:
                dev.append([group, item, prop, val])
                dev_keys.add(key)
                changes += 1

    if not changes:
        return device_text, 0
    return json.dumps(dev, indent=4), changes


def sync_menu_icons():
    """Bring the device's menu into line with the Phase 1 rebuild, without resetting the menu.

    Why this is needed: skinshortcuts .DATA.xml and .properties are in _preserved(), on purpose -
    they hold the owner's customised menus, and an update that reset them would be worse than
    stale icons. So they are never extracted, and a skin shipping new icon FILES under addons/
    lands on a device still pointing at the old paths.

    The reference copies live in this add-on (MENU_REF_DIR), not in the build, so this costs no
    download and can run at startup. The build owns the icons deliberately: the point of the set
    is that every device looks the same. Must run BEFORE force_menu_rebuild(), which regenerates
    the menu from these files. Returns human lines.
    """
    base = os.path.join(HOME, *SKINSHORTCUTS_REL.split('/'))
    if not os.path.isdir(base) or not os.path.isdir(MENU_REF_DIR):
        return []
    total, files = 0, 0

    p_13009 = os.path.join(base, '13009.DATA.xml')
    if os.path.exists(p_13009):
        try:
            os.remove(p_13009)
            total += 1
            files += 1
            log('removed obsolete 13009.DATA.xml')
        except Exception as exc:  # noqa: BLE001
            log('could not remove 13009.DATA.xml: %s' % exc, xbmc.LOGWARNING)

    p_sports = os.path.join(base, 'sports.DATA.xml')
    if os.path.exists(p_sports):
        try:
            with open(p_sports, 'r', encoding='utf-8') as fh:
                sp_content = fh.read()
            if sp_content.strip().replace('\r\n', '\n') == _REF_SPORTS_XML.strip().replace('\r\n', '\n'):
                os.remove(p_sports)
                total += 1
                files += 1
                log('removed obsolete sports.DATA.xml')
            else:
                log('kept customized sports.DATA.xml')
        except Exception as exc:  # noqa: BLE001
            log('could not check/remove sports.DATA.xml: %s' % exc, xbmc.LOGWARNING)

    p_tv = os.path.join(base, 'tv.DATA.xml')
    if os.path.exists(p_tv):
        try:
            with open(p_tv, 'r', encoding='utf-8') as fh:
                tv_content = fh.read()
            if tv_content.strip().replace('\r\n', '\n') == _REF_TV_XML.strip().replace('\r\n', '\n'):
                os.remove(p_tv)
                total += 1
                files += 1
                log('removed obsolete tv.DATA.xml')
            else:
                log('kept customized tv.DATA.xml')
        except Exception as exc:  # noqa: BLE001
            log('could not check/remove tv.DATA.xml: %s' % exc, xbmc.LOGWARNING)

    CREW_SPORT_ACTIONS = ('action=nfl', 'action=nhl', 'action=nba', 'action=mlb', 'action=ufc', 'action=boxing')
    p_crew = os.path.join(base, 'plugin-video-thecrew.DATA.xml')
    p_crew_ref = os.path.join(MENU_REF_DIR, 'plugin-video-thecrew.DATA.xml')
    if os.path.exists(p_crew_ref):
        replace_crew = False
        if not os.path.exists(p_crew):
            replace_crew = True
        else:
            try:
                with open(p_crew, 'r', encoding='utf-8') as fh:
                    crew_text = fh.read()
                if not any(act in crew_text for act in CREW_SPORT_ACTIONS):
                    replace_crew = True
            except Exception as exc:  # noqa: BLE001
                log('could not read plugin-video-thecrew.DATA.xml: %s' % exc, xbmc.LOGWARNING)
        if replace_crew:
            try:
                shutil.copy(p_crew_ref, p_crew)
                total += 1
                files += 1
                log('installed reference plugin-video-thecrew.DATA.xml')
            except Exception as exc:  # noqa: BLE001
                log('could not copy plugin-video-thecrew.DATA.xml: %s' % exc, xbmc.LOGWARNING)

    p_slyguy = os.path.join(base, 'slyguy-pluto-tv-provider.DATA.xml')
    p_slyguy_ref = os.path.join(MENU_REF_DIR, 'slyguy-pluto-tv-provider.DATA.xml')
    if not os.path.exists(p_slyguy) and os.path.exists(p_slyguy_ref):
        try:
            shutil.copy(p_slyguy_ref, p_slyguy)
            total += 1
            files += 1
            log('created slyguy-pluto-tv-provider.DATA.xml from reference')
        except Exception as exc:  # noqa: BLE001
            log('could not copy slyguy-pluto-tv-provider.DATA.xml: %s' % exc, xbmc.LOGWARNING)

    for name in sorted(os.listdir(MENU_REF_DIR)):
        if not (name.endswith('.DATA.xml') or name.endswith('.properties')):
            continue
        local = os.path.join(base, name)
        if not os.path.exists(local):
            continue
        try:
            with open(os.path.join(MENU_REF_DIR, name), 'r', encoding='utf-8') as fh:
                build_text = fh.read()
            with open(local, 'r', encoding='utf-8') as fh:
                device_text = fh.read()
        except Exception:  # noqa: BLE001 - one unreadable file must not stop the rest
            continue

        n = 0
        if name == 'settings.DATA.xml':
            device_text, n_mig = _migrate_settings_data_xml(device_text)
            n += n_mig
        elif name == 'mainmenu.DATA.xml':
            device_text, n_mig = _migrate_mainmenu_data_xml(device_text)
            n += n_mig

        if name.endswith('.properties'):
            new_text, n_rep = _repoint_properties(device_text, build_text)
            n += n_rep
        else:
            new_text, n_rep = _repoint_data_xml(device_text, _parse_shortcut_meta(build_text))
            n += n_rep

        if n:
            try:
                with open(local, 'w', encoding='utf-8') as fh:
                    fh.write(new_text)
            except Exception as exc:  # noqa: BLE001
                log('could not write %s: %s' % (name, exc), xbmc.LOGWARNING)
                continue
            total += n
            files += 1

    if not total:
        return []
    log('menu art repointed: %d value(s) across %d file(s)' % (total, files))
    return ['Updated %d menu icon%s to the current set - your menu layout was not changed.'
            % (total, '' if total == 1 else 's')]


def fix_gears_scrapers():
    """The Gears ships with every scraper off - provider.external=false and no scraper module -
    so it returns nothing anywhere. The setting lives in a sqlite db under addon_data, and
    Update preserves every .db there on purpose, so this fix can never ride the payload: it has
    to be applied on the device. Returns human lines, empty if it was already right or absent.
    """
    import sqlite3
    path = os.path.join(HOME, *GEARS_DB_REL.split('/'))
    if not os.path.exists(path):
        return []
    changed = []
    try:
        con = sqlite3.connect(path)
        try:
            for sid, want, broken in GEARS_SCRAPER_FIX:
                row = con.execute(
                    'select setting_value from settings where setting_id=?', (sid,)).fetchone()
                if row is None:
                    continue
                cur = (row[0] or '').strip()
                # Only correct the shipped-broken value. A different scraper module the owner
                # chose on purpose is left alone.
                if sid == 'provider.external':
                    if cur.lower() in broken:
                        continue
                elif cur not in broken:
                    continue
                con.execute('update settings set setting_value=? where setting_id=?', (want, sid))
                changed.append(sid)
            con.commit()
        finally:
            con.close()
    except Exception as exc:  # noqa: BLE001
        log('could not fix Gears scrapers: %s' % exc, xbmc.LOGWARNING)
        return []
    if not changed:
        return []
    log('Gears scrapers fixed: %s' % ', '.join(changed))
    return ['Turned The Gears\' scrapers back on - it shipped with them all disabled, so it '
            'was finding nothing.']


def flatpak_instructions():
    """The one-line host command plus how to run it, for the textviewer."""
    return (
        'RUN THIS ONCE, THEN RESTART KODI\n\n'
        'On the Steam Deck: switch to Desktop Mode, open Konsole (the terminal), and paste '
        'this single line:\n\n'
        '%s\n\n'
        'Then fully close Kodi and reopen it.\n\n'
        '--- what it does ---\n'
        'It grants Kodi\'s sandbox the host security certificates (SSL_CERT_DIR) and the '
        'network and inter-process permissions live streams need. It is the command-line '
        'equivalent of the Flatseal changes, and it only has to be done once on this device - '
        'it survives Kodi updates and StarWave installs.\n\n'
        'If "flatpak override" reports it is not found, drop the "--user" so it reads '
        '"flatpak override --env=...", which some setups need.' % flatpak_command())


def do_fix_live():
    # on_disk=False: Kodi keeps running here and would write its in-memory settings back over
    # the file on exit, so these have to go through Kodi itself.
    lines = live_fix_kodi_side() + tune_this_device(on_disk=False) + fix_gears_scrapers()
    # Kept deliberately tight. Past ~6 rendered lines show_message falls back to textviewer,
    # which has no OK button - and every other dialog in the wizard has one, so the result
    # screen looking different was jarring rather than informative.
    body = 'Done inside Kodi:\n- ' + '\n- '.join(lines)

    if not is_flatpak():
        body += '\n\nIf streams still will not play, fully close and reopen Kodi.'
        return show_message(body)

    if flatpak_fix_applied():
        body += ('\n\nThe sandbox fix is already in place on this device (SSL_CERT_DIR is set), '
                 'so there is nothing to run outside Kodi.')
        return show_message(body)

    # The one thing Kodi cannot do to itself: the sandbox settings.
    body += ('\n\nThis is a Flatpak install (%s). The last step lets encrypted streams '
             'authenticate, and it MUST be run outside Kodi - a sandboxed app cannot change '
             'its own sandbox.' % flatpak_app_id())
    show_message(body)
    xbmcgui.Dialog().textviewer(ADDON_NAME, flatpak_instructions())
    xbmcgui.Dialog().ok(
        ADDON_NAME,
        'The Kodi-side changes are already applied. Once you have run that one command in '
        'Konsole and restarted Kodi, live streams should play.')


def _capture_skip(rel):
    if rel in CAPTURE_EXCLUDE_FILES:
        return True
    if rel.startswith(CAPTURE_EXCLUDE_DIRS) and (
            rel in CAPTURE_EXCLUDE_DIRS or any(rel.startswith(d + '/')
                                               for d in CAPTURE_EXCLUDE_DIRS)):
        return True
    parts = rel.split('/')
    if any(n in parts for n in CAPTURE_EXCLUDE_NAME):
        return True
    if rel.endswith(CAPTURE_EXCLUDE_SUFFIX) or 'health_backup' in parts[-1]:
        return True
    if rel.startswith('userdata/addon_data/') and (
            parts[-1] in CAPTURE_EXCLUDE_CACHE or
            any(parts[-1].endswith(c.lstrip('*')) for c in CAPTURE_EXCLUDE_CACHE if '*' in c)):
        return True
    return False


def _sanitise_xml(text):
    """Blank credential-shaped values. Returns (text, count)."""
    n = [0]

    def repl(m):
        sid, attrs, val = m.group(1), m.group(2), m.group(3)
        if CRED_RE.search(sid) and val.strip().lower() not in CRED_KEEP:
            n[0] += 1
            return '<setting id="%s"%s></setting>' % (sid, attrs)
        return m.group(0)

    return re.sub(r'<setting id="([^"]+)"([^>]*)>([^<]*)</setting>', repl, text), n[0]


def _sanitise_gears_db(src, dest):
    """Copy the Gears settings database with its credential rows reset."""
    import sqlite3
    shutil.copy2(src, dest)
    try:
        con = sqlite3.connect(dest)
        for sid in GEARS_CREDS:
            con.execute('UPDATE settings SET setting_value = setting_default '
                        'WHERE setting_id = ?', (sid,))
        con.commit()
        con.close()
        return True
    except Exception as exc:  # noqa: BLE001
        log('could not sanitise the Gears database: %s' % exc, xbmc.LOGWARNING)
        return False


def do_backup():
    name = xbmcgui.Dialog().input('Name this build (e.g. Living Room, Bedroom, Deck)')
    if not name:
        return
    slug = re.sub(r'[^A-Za-z0-9_-]+', '-', name).strip('-').lower() or 'mybuild'
    asset_name = 'StarWave-%s-kodi.zip' % slug
    token = gh_token()
    repo = gh_repo()

    # Logins are kept only on the route that ends in the private repository. A zip written to
    # a folder can be copied anywhere, so that one is always stripped -  the same rule the
    # published build follows.
    upload = False
    if token:
        pick = xbmcgui.Dialog().select('Where should this build go?', [
            'My private repo, %s (keeps my logins)' % repo,
            'A folder on this device (logins removed)',
        ])
        if pick < 0:
            return
        upload = pick == 0

    if upload:
        ok = xbmcgui.Dialog().yesno(
            ADDON_NAME,
            'This build will carry your Trakt and debrid logins.\n\nThat is only safe '
            'because %s is private - anyone who can read it could use them.' % repo,
            nolabel='Cancel', yeslabel='Upload')
        if not ok:
            return
        out = os.path.join(TEMP_DIR, asset_name)
    else:
        folder = xbmcgui.Dialog().browseSingle(
            3, 'Where should the zip be written?', 'files', '', False, False, '')
        if not folder:
            return
        out = os.path.join(xbmcvfs.translatePath(folder), asset_name)

    keep_logins = upload
    tag = PERSONAL_TAG + slug
    release = None
    if upload:
        # Claim the release first. Creating one needs write access, packaging needs none, so
        # doing it in this order turns "your token cannot write here" into a two-second answer
        # instead of one that arrives after 400 MB and a minute and a half of zipping.
        probe = xbmcgui.DialogProgress()
        probe.create(ADDON_NAME, 'Checking %s' % repo)
        try:
            release = _release_for_tag(repo, token, tag, 'Personal build: %s' % name)
            if not release:
                raise IOError('could not create the %s release' % tag)
        except Exception as exc:  # noqa: BLE001
            probe.close()
            log('release check failed: %s' % exc, xbmc.LOGERROR)
            return xbmcgui.Dialog().ok(
                ADDON_NAME, 'Cannot upload to %s, so nothing was packaged.\n\n%s' % (repo, exc))
        probe.close()

    dialog = xbmcgui.DialogProgress()
    dialog.create(ADDON_NAME, 'Packaging %s' % name)

    import zipfile
    creds = 0
    written = 0
    tmp_db = os.path.join(TEMP_DIR, 'starwave-gears.db')
    try:
        files = []
        for dirpath, dirnames, filenames in os.walk(HOME):
            dirnames[:] = [d for d in dirnames if not _capture_skip(
                os.path.relpath(os.path.join(dirpath, d), HOME).replace(os.sep, '/'))]
            for f in filenames:
                full = os.path.join(dirpath, f)
                rel = os.path.relpath(full, HOME).replace(os.sep, '/')
                if not _capture_skip(rel):
                    files.append((full, rel))

        total = max(len(files), 1)
        with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as zf:
            for i, (full, rel) in enumerate(files):
                if dialog.iscanceled():
                    dialog.close()
                    try:
                        os.remove(out)
                    except OSError:
                        pass
                    return notify('Backup cancelled')
                if i % 40 == 0:
                    dialog.update(int(i * 100 / total),
                                  'Packaging\n%d of %d files' % (i + 1, total))
                try:
                    if rel == GEARS_DB_REL and not keep_logins:
                        if _sanitise_gears_db(full, tmp_db):
                            zf.write(tmp_db, rel)
                            written += 1
                            continue
                    if (not keep_logins and rel.startswith('userdata/addon_data/')
                            and rel.endswith('.xml')):
                        with open(full, encoding='utf-8', errors='replace') as fh:
                            clean, n = _sanitise_xml(fh.read())
                        creds += n
                        zf.writestr(rel, clean)
                    else:
                        zf.write(full, rel)
                    written += 1
                except (OSError, ValueError) as exc:
                    log('skipped %s: %s' % (rel, exc), xbmc.LOGWARNING)
            zf.writestr('version.txt', 'StarWave - %s\n' % name)
        dialog.close()
    except Exception as exc:  # noqa: BLE001
        dialog.close()
        log('backup failed: %s' % exc, xbmc.LOGERROR)
        return xbmcgui.Dialog().ok(ADDON_NAME, 'Could not write the backup.\n\n%s' % exc)
    finally:
        try:
            os.remove(tmp_db)
        except OSError:
            pass

    size = os.path.getsize(out) / 1048576.0
    if not upload:
        return xbmcgui.Dialog().ok(
            ADDON_NAME,
            'Backed up to:\n%s\n\n%d files, %.0f MB. %d saved logins were removed -  a zip in '
            'a folder can be copied anywhere, so each device signs in once via Trakt > '
            'Setup.\n\nUpload this file to the StarWave release and add it to builds.json, '
            'and it will appear on every device under Install or update a build.'
            % (out, written, size, creds),
        )

    while True:
        dialog = xbmcgui.DialogProgress()
        dialog.create(ADDON_NAME, 'Uploading to %s' % repo)
        try:
            asset = upload_asset(repo, token, release, out, asset_name, dialog)
            dialog.close()
            break
        except Exception as exc:  # noqa: BLE001
            dialog.close()
            log('upload failed: %s' % exc, xbmc.LOGERROR)
            # The packaging is the slow part and it is already done, so offer the upload again
            # rather than making someone sit through 400 MB of zipping twice.
            if not xbmcgui.Dialog().yesno(
                    ADDON_NAME, 'Packaged, but the upload failed.\n\n%s' % exc,
                    nolabel='Give up', yeslabel='Try again'):
                return xbmcgui.Dialog().ok(
                    ADDON_NAME, 'The zip is still on this device:\n\n%s' % out)
            release = _release_for_tag(repo, token, tag, 'Personal build: %s' % name) or release

    # Only now -  GitHub has confirmed the stored size matches what was sent.
    try:
        os.remove(out)
    except OSError as exc:
        log('could not remove the uploaded zip: %s' % exc, xbmc.LOGWARNING)

    xbmcgui.Dialog().ok(
        ADDON_NAME,
        'Uploaded to %s as %s.\n\n%d files, %.0f MB, verified by GitHub. Your logins are in '
        'it.\n\nOn your other devices: set the same token under My GitHub token, then pick '
        '%s under Install or update a build.'
        % (repo, tag, written, asset.get('size', 0) / 1048576.0, name),
    )


# ----------------------------------------------------------------------------- router


def router(qs):
    p = dict(parse_qsl(qs.lstrip('?')))
    action = p.get('action')
    if action == 'builds':
        builds_menu()
    elif action == 'build':
        build_menu(p.get('id'))
    elif action == 'layouts':
        layouts_menu()
    elif action == 'layout':
        do_layout(p.get('id'))
    elif action == 'install':
        do_build(p.get('id'), update=False)
    elif action == 'update':
        do_build(p.get('id'), update=True)
    elif action == 'backup':
        do_backup()
    elif action == 'resetdevice':
        do_reset_device()
    elif action == 'freshwipe':
        do_fresh_wipe()
    elif action == 'fixlive':
        do_fix_live()
    elif action == 'version':
        do_version()
    elif action == 'token':
        do_token()
    elif action == 'accounts':
        accounts_menu()
    elif action == 'auth_rd':
        af = _get_account_fanout()
        af.auth_realdebrid()
        xbmc.executebuiltin('Container.Refresh')
    elif action == 'auth_pm':
        af = _get_account_fanout()
        af.auth_premiumize()
        xbmc.executebuiltin('Container.Refresh')
    elif action == 'auth_ad':
        af = _get_account_fanout()
        af.auth_alldebrid()
        xbmc.executebuiltin('Container.Refresh')
    elif action == 'auth_trakt':
        af = _get_account_fanout()
        af.auth_trakt()
        xbmc.executebuiltin('Container.Refresh')
    elif action == 'auth_youtube':
        auth_youtube()
    elif action == 'fanout_targets':
        af = _get_account_fanout()
        af.select_fanout_targets_dialog()
        xbmc.executebuiltin('Container.Refresh')
    elif action == 'clear_logins':
        show_clear_logins_dialog()
    elif action == 'accounts_status':
        show_accounts_status()
    elif action == 'refresh_skin':
        xbmc.executebuiltin('Dialog.Close(all, true)')
        xbmc.executebuiltin('ActivateWindow(home)')
        xbmc.executebuiltin('ReloadSkin()')
        xbmcgui.Dialog().notification(ADDON_NAME, 'Returned to Home: Widgets & Skin Reloaded!', ICON, 3000)
    elif action == 'refresh_repos':
        xbmc.executebuiltin('UpdateAddonRepos')
        xbmc.executebuiltin('UpdateLocalAddons')
        remote_ver = check_remote_wizard_version()
        cur_ver = addon_disk_version(ADDON_ID) or VERSION
        if remote_ver and _version_tuple(remote_ver) > _version_tuple(cur_ver):
            xbmcgui.Dialog().notification(
                'StarWave Update',
                'Found update v%s (Current: v%s) - downloading!' % (remote_ver, cur_ver),
                ICON, 6000
            )
        else:
            xbmcgui.Dialog().notification(
                'StarWave Wizard',
                'Repository checked: Up to date (v%s)' % cur_ver,
                ICON, 4000
            )
    elif action == 'sports':
        sports_menu(hero_only=False, sport_filter=_norm_sport(p.get('sport')),
                    skip_hero=p.get('skip_hero') in ('1', 'true', 'True'))
    elif action == 'sports_hero':
        sports_menu(hero_only=True, sport_filter=_norm_sport(p.get('sport')))
    elif action == 'play_sport':
        play_sport(p)
    elif action == 'view_error_log' or action == 'diagnostics':
        view_error_log()
    elif action == 'info':
        show_info()
    else:
        menu()


def _version_tuple(v_str):
    if not v_str:
        return (0,)
    parts = []
    for x in str(v_str).split('.'):
        digits = ''.join(c for c in x if c.isdigit())
        parts.append(int(digits) if digits else 0)
    return tuple(parts)


def check_remote_wizard_version():
    """Query the StarWave repository on GitHub to find the latest published wizard version."""
    try:
        import urllib.request
        import xml.etree.ElementTree as ET
        url = 'https://strfck3r.github.io/starwave/addons.xml'
        req = urllib.request.Request(url, headers={'User-Agent': 'StarWave-Wizard'})
        with urllib.request.urlopen(req, timeout=5) as resp:
            xml_data = resp.read()
        root = ET.fromstring(xml_data)
        for addon in root.findall('addon'):
            if addon.get('id') == ADDON_ID:
                return addon.get('version')
    except Exception:
        pass
    return None


def ensure_tmdbhelper_sync_patch(home=None):
    """Ensure TMDb Helper's datasync.py, container.py, and lists_sync.py have guards to prevent widget crashes."""
    fixes = []
    try:
        base_home = home or (xbmcvfs.translatePath('special://home') if KODI_AVAILABLE else HOME)
        addons_dir = os.path.join(base_home, 'addons')
        datasync_path = os.path.join(addons_dir, 'plugin.video.themoviedb.helper', 'resources', 'tmdbhelper', 'lib', 'sync', 'datasync.py')
        if os.path.isfile(datasync_path):
            with open(datasync_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()

            needs_patch = False
            # 1. Factory resolution check
            if "importmodule(*route)(self, item_type).sync(forced=forced)" in content:
                content = content.replace(
                    "importmodule(*route)(self, item_type).sync(forced=forced)",
                    "func = importmodule(*route)\n            factory = func() if (callable(func) and not isinstance(func, type)) else func\n            factory(self, item_type).sync(forced=forced)"
                )
                needs_patch = True
                fixes.append('TMDb Helper sync factory resolution patched')

            # 2. Null guard check in get_items
            if "def get_items(self):\n        sd = self.parent_getter\n        return [" in content:
                content = content.replace(
                    "def get_items(self):\n        sd = self.parent_getter\n        return [",
                    "def get_items(self):\n        sd = self.parent_getter\n        if not sd or not sd.items:\n            return []\n        return ["
                )
                needs_patch = True
                fixes.append('TMDb Helper datasync null guard patched')

            if needs_patch:
                with open(datasync_path, 'w', encoding='utf-8') as f:
                    f.write(content)

        # 3. Graceful container exit on empty directory items (prevents GetDirectory error dialogs on empty widgets)
        container_path = os.path.join(addons_dir, 'plugin.video.themoviedb.helper', 'resources', 'tmdbhelper', 'lib', 'items', 'container.py')
        if os.path.isfile(container_path):
            with open(container_path, 'r', encoding='utf-8', errors='ignore') as f:
                c_content = f.read()
            old_c = "            items = self.get_directory_items()\n\n            if not items:\n                return"
            new_c = "            items = self.get_directory_items()\n\n            if not items:\n                if not items_only:\n                    self.finish_container()\n                return"
            if old_c in c_content:
                with open(container_path, 'w', encoding='utf-8') as f:
                    f.write(c_content.replace(old_c, new_c, 1))
                fixes.append('TMDb Helper container empty items guard patched')

        # 4. Optional tmdb_type parameter in lists_sync (prevents TypeError on info=trakt_nextepisodes & trakt_ondeck)
        lists_sync_path = os.path.join(addons_dir, 'plugin.video.themoviedb.helper', 'resources', 'tmdbhelper', 'lib', 'items', 'directories', 'trakt', 'lists_sync.py')
        if os.path.isfile(lists_sync_path):
            with open(lists_sync_path, 'r', encoding='utf-8', errors='ignore') as f:
                ls_content = f.read()
            old_ls1 = "def get_items(self, tmdb_type, page=1, sort_by=None, sort_how=None, tmdb_id=None, **kwargs):"
            new_ls1 = "def get_items(self, tmdb_type=None, page=1, sort_by=None, sort_how=None, tmdb_id=None, **kwargs):\n        tmdb_type = tmdb_type or ('tv' if getattr(self.list_properties, 'item_type', '') in ('episode', 'season', 'show') else 'movie')"
            old_ls2 = "    def get_items(self, tmdb_type, **kwargs):\n        self.list_properties.container_content = 'episodes' if tmdb_type == 'tv' else 'movies'"
            new_ls2 = "    def get_items(self, tmdb_type=None, **kwargs):\n        tmdb_type = tmdb_type or 'tv'\n        self.list_properties.container_content = 'episodes' if tmdb_type == 'tv' else 'movies'"
            ls_modified = False
            if old_ls1 in ls_content:
                ls_content = ls_content.replace(old_ls1, new_ls1, 1)
                ls_modified = True
            if old_ls2 in ls_content:
                ls_content = ls_content.replace(old_ls2, new_ls2, 1)
                ls_modified = True
            if ls_modified:
                with open(lists_sync_path, 'w', encoding='utf-8') as f:
                    f.write(ls_content)
                fixes.append('TMDb Helper lists_sync optional tmdb_type patched')
    except Exception as exc:
        pass
    return fixes


def ensure_tmdbhelper_db_health(home=None):
    """Ensure TMDb Helper's SQLite databases are not corrupted, auto-purging any corrupt database so TMDb Helper regenerates cleanly."""
    fixes = []
    try:
        base_home = home or (xbmcvfs.translatePath('special://home') if KODI_AVAILABLE else HOME)
        db_dir = os.path.join(base_home, 'userdata', 'addon_data', 'plugin.video.themoviedb.helper', 'database_07')
        if not os.path.isdir(db_dir):
            return fixes

        # Check all SQLite databases in TMDb Helper's database directory
        db_names = ('ItemDetails.db', 'ItemQueries.db', 'ItemContainer.db')
        for db_name in db_names:
            db_path = os.path.join(db_dir, db_name)
            if not os.path.isfile(db_path):
                continue
            is_corrupt = False
            err_msg = ''
            try:
                conn = sqlite3.connect(db_path, timeout=1.0)
                cursor = conn.cursor()
                res = cursor.execute("PRAGMA quick_check").fetchone()
                conn.close()
                if not res or res[0] != 'ok':
                    is_corrupt = True
                    err_msg = str(res) if res else 'no quick_check result'
            except Exception as exc:
                is_corrupt = True
                err_msg = str(exc)

            if is_corrupt:
                for ext in ('', '-wal', '-shm'):
                    f = db_path + ext
                    if os.path.isfile(f):
                        try:
                            os.remove(f)
                        except Exception:
                            pass
                fixes.append(f'TMDb Helper corrupted {db_name} purged: {err_msg}')
    except Exception as exc:
        pass
    return fixes


def ensure_trailer_resolution(home=None):
    """Ensure context.trailer.mod, umbrella, and plugin.video.youtube have clean TMDb resolution and direct streaming."""
    fixes = []
    base_home = home or HOME
    try:
        addons_dir = os.path.join(base_home, 'addons')

        # 1. Patch context.trailer.mod/resources/lib/modules/trailer.py
        trailer_mod_path = os.path.join(addons_dir, 'context.trailer.mod', 'resources', 'lib', 'modules', 'trailer.py')
        if os.path.isfile(trailer_mod_path):
            with open(trailer_mod_path, 'r', encoding='utf-8', errors='ignore') as f:
                mod_content = f.read()
            if 'AIzaSy' in mod_content or 'tmdb_trailer' not in mod_content:
                clean_trailer_mod = '''# -*- coding: utf-8 -*-

import json
import xbmc
import xbmcaddon
import xbmcgui
try:
	import urllib.request as _urllib_req
	import urllib.parse as _urllib_parse
	quote_plus = _urllib_parse.quote_plus
	urlopen = _urllib_req.urlopen
	Request = _urllib_req.Request
except ImportError:
	import urllib2 as _urllib_req
	import urllib as _urllib_parse
	quote_plus = _urllib_parse.quote_plus
	urlopen = _urllib_req.urlopen
	Request = _urllib_req.Request

from resources.lib.modules import tools


class Trailer:
	def __init__(self):
		try:
			self.key = xbmcaddon.Addon('plugin.video.youtube').getSetting('youtube.api.key')
		except Exception:
			self.key = ''
		self.tmdb_key = '0049795edb57568b95240bc9e61a9dfc'
		if self.key:
			self.key_link = '&key=%s' % self.key
			self.search_link = 'https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=15&q=%s' + self.key_link
		else:
			self.key_link = ''
			self.search_link = ''


	def play(self, type, name, year, windowedtrailer=0):
		tools.busy()
		try:
			url = self.worker(type, name, year)
			tools.hide()
			if not url: return
			xbmc.executebuiltin("PlayMedia(%s)" % (url))
			if windowedtrailer == 1:
				xbmc.sleep(100)
				while xbmc.Player().isPlayingVideo():
					xbmc.sleep(100)
				xbmc.executebuiltin("Dialog.Close(%s, true)" % xbmcgui.getCurrentWindowDialogId())
		except:
			tools.hide()
			import traceback
			traceback.print_exc()


	def worker(self, type, name, year):
		# 1. Primary path: TMDb video metadata (Zero Google API key required)
		url = self.tmdb_trailer(type, name, year)
		if url:
			return url

		# 2. Fallback path: YouTube v3 Search API (if user configured a personal API key)
		if self.key and self.search_link:
			query = name + ' ' + str(year) + ' trailer'
			query = self.search_link % quote_plus(query)
			url = self.search(query)
			if url:
				return url

		# 3. If no trailer was found
		tools.hide()
		try:
			icon = xbmcaddon.Addon('plugin.video.youtube').getAddonInfo('icon')
		except Exception:
			icon = None
		xbmcgui.Dialog().notification('Trailers', 'No trailer found for %s' % name, icon=icon)
		return None


	def _fetch_json(self, url, timeout=8):
		try:
			req = Request(url, headers={'User-Agent': 'Kodi/StarWave'})
			with urlopen(req, timeout=timeout) as resp:
				return json.loads(resp.read().decode('utf-8'))
		except Exception:
			return {}


	def tmdb_trailer(self, mediatype, name, year):
		"""Fetch official trailer videos directly from TMDb without consuming YouTube API quota."""
		try:
			is_tv = mediatype in ('tvshow', 'tv', 'show', 'season', 'episode')
			search_type = 'tv' if is_tv else 'movie'
			year_param = ('&first_air_date_year=%s' % year) if (is_tv and year) else (('&year=%s' % year) if year else '')
			search_url = 'https://api.themoviedb.org/3/search/%s?api_key=%s&query=%s%s' % (
				search_type, self.tmdb_key, quote_plus(name), year_param
			)
			resp = self._fetch_json(search_url, timeout=8)
			results = resp.get('results', [])

			# If year filter produced no match, retry without year
			if not results and year:
				search_url_noyear = 'https://api.themoviedb.org/3/search/%s?api_key=%s&query=%s' % (
					search_type, self.tmdb_key, quote_plus(name)
				)
				resp = self._fetch_json(search_url_noyear, timeout=8)
				results = resp.get('results', [])

			if not results:
				return None

			item_id = results[0].get('id')
			v_url = 'https://api.themoviedb.org/3/%s/%s/videos?api_key=%s' % (search_type, item_id, self.tmdb_key)
			v_resp = self._fetch_json(v_url, timeout=8)
			raw_videos = [v for v in v_resp.get('results', []) if (v.get('site', '').lower() == 'youtube' and v.get('key'))]

			if not raw_videos:
				return None

			def _rank(v):
				t = (v.get('type') or '').lower()
				if t == 'trailer': return 0
				if t == 'teaser': return 1
				if t == 'clip': return 2
				return 3

			sorted_vids = sorted(raw_videos, key=_rank)

			if len(sorted_vids) > 1:
				tools.hide()
				labels = ['[%s] %s' % (v.get('type', 'Trailer'), tools.replaceHTMLCodes(v.get('name', 'Trailer'))) for v in sorted_vids]
				sel = xbmcgui.Dialog().select('SELECT TRAILER:', labels)
				tools.busy()
				if sel == -1:
					return None
				vid_id = sorted_vids[sel]['key']
			else:
				vid_id = sorted_vids[0]['key']

			return 'plugin://plugin.video.youtube/play/?video_id=%s' % vid_id
		except Exception:
			import traceback
			traceback.print_exc()
			return None


	def search(self, url):
		try:
			apiLang = tools.apiLanguage().get('youtube', 'en')
			if apiLang != 'en': url += "&relevanceLanguage=%s" % apiLang
			response = self._fetch_json(url, timeout=8)
			error = response.get('error', {})
			if error:
				tools.hide()
				message = error.get('message', 'YouTube API error')
				try:
					icon = xbmcaddon.Addon('plugin.video.youtube').getAddonInfo('icon')
				except Exception:
					icon = None
				xbmcgui.Dialog().notification('YouTube', str(message), icon=icon)
				return None

			json_items = response.get('items', [])
			items = [i.get('id', {}).get('videoId') for i in json_items if i.get('id', {}).get('videoId')]
			labels = [i.get('snippet', {}).get('title', 'Trailer') for i in json_items if i.get('id', {}).get('videoId')]
			labels = [tools.replaceHTMLCodes(i) for i in labels]

			if not items:
				return None

			tools.hide()
			select = xbmcgui.Dialog().select('YOUTUBE TRAILERS:', labels)
			tools.busy()
			if select == -1: return None
			return 'plugin://plugin.video.youtube/play/?video_id=%s' % items[select]
		except Exception:
			import traceback
			traceback.print_exc()
			tools.hide()
			return None
'''
                with open(trailer_mod_path, 'w', encoding='utf-8') as f:
                    f.write(clean_trailer_mod)
                fixes.append('context.trailer.mod updated with TMDb resolution engine')

        # 2. Patch plugin.video.youtube settings: youtube.http.stream_redirect = true
        yt_settings_path = os.path.join(base_home, 'userdata', 'addon_data', 'plugin.video.youtube', 'settings.xml')
        if os.path.isfile(yt_settings_path):
            try:
                import xml.etree.ElementTree as ET
                tree = ET.parse(yt_settings_path)
                root = tree.getroot()
                found = False
                for s in root.findall('setting'):
                    if s.get('id') == 'youtube.http.stream_redirect':
                        if s.text != 'true':
                            s.text = 'true'
                            s.attrib.pop('default', None)
                            fixes.append('plugin.video.youtube stream_redirect enabled')
                        found = True
                        break
                if not found:
                    elem = ET.SubElement(root, 'setting', {'id': 'youtube.http.stream_redirect'})
                    elem.text = 'true'
                    fixes.append('plugin.video.youtube stream_redirect created')
                tree.write(yt_settings_path, encoding='utf-8', xml_declaration=True)
            except Exception:
                pass
    except Exception:
        pass
    return fixes


def ensure_arctic_fuse_update_lock(home=None):
    """Ensure skin.arctic.fuse.3 is pinned against auto-updates in Addons33.db.

    Kodi's update_rules table controls per-addon update policies:
      0 = default/any
      1 = user disabled auto update
      2 = pin version / never auto-update
    Locking to 2 prevents Kodi from silently downloading and extracting upstream
    releases over the skin directory, which would destroy StarWave's XML hooks.
    Returns a list of status strings.
    """
    fixes = []
    base_home = home or (xbmcvfs.translatePath('special://home') if KODI_AVAILABLE else HOME)
    addons_db = os.path.join(base_home, 'userdata', 'Database', 'Addons33.db')
    if not os.path.isfile(addons_db):
        return fixes

    try:
        con = sqlite3.connect(addons_db, timeout=2.0)
        cur = con.cursor()
        cur.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='update_rules'")
        if not cur.fetchone():
            con.close()
            return fixes

        cur.execute("SELECT updateRule FROM update_rules WHERE addonID = ?", ('skin.arctic.fuse.3',))
        row = cur.fetchone()
        if not row or row[0] != 2:
            cur.execute("INSERT OR REPLACE INTO update_rules (addonID, updateRule) VALUES (?, ?)",
                        ('skin.arctic.fuse.3', 2))
            con.commit()
            log("locked skin.arctic.fuse.3 auto-updates in Addons33.db (updateRule=2)")
            fixes.append("Arctic Fuse 3: locked against upstream auto-updates")
        con.close()
    except Exception as exc:  # noqa: BLE001
        log("could not lock arctic fuse update rules: %s" % exc, xbmc.LOGWARNING)

    return fixes


def ensure_arctic_fuse_patches(home=None):
    """Self-heal StarWave XML hooks in skin.arctic.fuse.3 if an update or re-install clobbered them.

    Checks for StarWave landing focus marker in 1080i/Home.xml.
    If missing, re-applies Home.xml and Includes_Actions.xml from wizard bundled
    resources or staged layouts and triggers force_arctic_fuse_rebuild().
    Returns a list of status strings.
    """
    fixes = []
    base_home = home or (xbmcvfs.translatePath('special://home') if KODI_AVAILABLE else HOME)
    af_dir = os.path.join(base_home, 'addons', 'skin.arctic.fuse.3')
    if not os.path.isdir(af_dir):
        return fixes

    home_xml = os.path.join(af_dir, '1080i', 'Home.xml')
    inc_xml = os.path.join(af_dir, '1080i', 'Includes_Actions.xml')
    if not os.path.isfile(home_xml):
        return fixes

    needs_patch = False
    try:
        with open(home_xml, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            if 'af_first_focus' not in content:
                needs_patch = True
    except Exception as exc:  # noqa: BLE001
        log("could not inspect Home.xml: %s" % exc, xbmc.LOGWARNING)
        return fixes

    if needs_patch:
        wiz_dir = os.path.dirname(os.path.abspath(__file__))
        patch_home = os.path.join(wiz_dir, 'resources', 'patches', 'skin.arctic.fuse.3', '1080i', 'Home.xml')
        patch_inc = os.path.join(wiz_dir, 'resources', 'patches', 'skin.arctic.fuse.3', '1080i', 'Includes_Actions.xml')

        restored = False
        if os.path.isfile(patch_home) and os.path.isfile(patch_inc):
            try:
                shutil.copyfile(patch_home, home_xml)
                shutil.copyfile(patch_inc, inc_xml)
                restored = True
            except Exception as exc:  # noqa: BLE001
                log("could not copy patches from resources: %s" % exc, xbmc.LOGWARNING)

        if restored:
            log("CORRECTED: restored StarWave XML hooks to skin.arctic.fuse.3 (Home.xml & Includes_Actions.xml)")
            try:
                force_arctic_fuse_rebuild()
            except Exception:  # noqa: BLE001
                pass
            fixes.append("Arctic Fuse 3: restored StarWave XML hooks after external update")

    return fixes


def ensure_thecrew_trakt_clean(home=None):
    """Ensure The Crew does not hold incompatible Trakt tokens that trigger false session expired popups.

    The Crew hardcodes its own Trakt API client ID (keys.trakt_id) and rejects tokens
    issued under StarWave / TMDb Helper's client ID with HTTP 401 Unauthorized, popping
    a recurring 'TRAKT SESSION EXPIRED' dialog at startup. Sports and replays in The Crew
    do not use Trakt. Purging these tokens and stamping trakt.revoked=true silences the
    dialog across the fleet.

    WHY THE FLAG AND NOT JUST BLANKING THE KEYS. Read from The Crew's own source on the
    Shield, 2026-09-06 (script.module.thecrew .../modules/trakt.py):

        has_trakt_token()                 -> calls _purge_stale_credentials_if_revoked(),
                                             then returns False if is_trakt_revoked()
        is_trakt_revoked()                -> reads setting 'trakt.revoked'
        _purge_stale_credentials_if_revoked() docstring: "settings_repair can restore
                                             tokens from .bak while keeping
                                             trakt.revoked=true"

    So The Crew RE-HYDRATES Trakt tokens from its own backups via settings_repair
    (purge_trakt_credentials_from_backups / sync_trakt_credentials_into_backups). Blanking
    settings.xml alone would be undone. The flag is the durable half: with it set, The Crew
    purges restored credentials itself and has_trakt_token() is False, so the boot check
    never runs. That is also why the .bak / settings.xml.* siblings are in `targets`.

    THE CONSEQUENCE IS INTENDED AND IS NOT A SIDE EFFECT: if Trakt is ever signed into
    inside The Crew natively - which WOULD work, because that flow uses The Crew's own
    client ID - this invariant clears it again on the next boot. Accepted knowingly, for
    the owner's reason first:
       1. "All devices need to be running the exact same setup" (owner, 2026-09-05). A
          fleet whose Trakt wiring depends on which box someone happened to log into by
          hand is not one setup.
       2. In StarWave The Crew serves live sports and replays only (NFL/NHL/NBA/MLB/UFC/
          boxing routes, bluehat, sreplays). None of them touch Trakt. All movie and TV
          tracking is TMDb Helper, Umbrella, Seren and The Gears, which DO accept a custom
          client ID and are still fanned out to.
    Anyone who wants The Crew on Trakt removes this call from service.py; there is
    deliberately no per-device escape hatch.

    NOT A VALID GATE: 'trakt.revoked' being explicitly false. It is written by
    clear_trakt_revoked() on ANY successful token write including a plain refresh, not
    only on a deliberate native sign-in. Measured on the Shield 2026-09-06: revoked=false
    sitting beside a live wizard-issued token that 401s. Gating on it would skip exactly
    the devices that need this.
    """
    fixes = []
    base_home = home or (xbmcvfs.translatePath('special://home') if KODI_AVAILABLE else HOME)
    crew_dir = os.path.join(base_home, 'userdata', 'addon_data', 'plugin.video.thecrew')
    settings_file = os.path.join(crew_dir, 'settings.xml')

    # Candidate files that can store or resurrect The Crew's Trakt tokens.
    #
    # THE BACKUP DIR IS NOT UNDER special://home, AND GUESSING COST A HARDWARE GATE. Read from
    # The Crew's own settings_repair.py on the Deck 2026-09-06, which keeps TWO copies:
    #   external_settings_backup_dir()  -> PARENT of special://home ("Kodi install root,
    #                                      sibling to userdata/"), so it survives an uninstall
    #                                      of plugin.video.thecrew, which wipes addon_data
    #   profile_settings_backup_path()  -> special://profile + thecrew_settings_backup
    # Joining 'thecrew_settings_backup' onto special://home itself - which is what this did
    # until the gate - finds NEITHER. On the Deck the real file is at
    # ~/.var/app/tv.kodi.Kodi/thecrew_settings_backup/settings.xml while special://home is
    # ~/.var/app/tv.kodi.Kodi/data/, one level down. The armed credential survived there with
    # revoked=false, which is the disarming case: if settings_repair restores that file it
    # restores revoked=false too, undoing the protection along with the purge.
    kodi_root = os.path.dirname(base_home.rstrip('/\\'))
    targets = [
        settings_file,
        os.path.join(kodi_root, 'thecrew_settings_backup', 'settings.xml'),           # external
        os.path.join(base_home, 'userdata', 'thecrew_settings_backup', 'settings.xml'),  # profile
        os.path.join(base_home, 'thecrew_settings_backup', 'settings.xml'),           # legacy guess
    ]
    if os.path.isdir(crew_dir):
        try:
            for fname in os.listdir(crew_dir):
                if fname.startswith('settings.xml.') or fname.endswith('.bak'):
                    targets.append(os.path.join(crew_dir, fname))
        except OSError:
            pass

    keys_to_clear = {'trakt.user', 'trakt.token', 'trakt.refresh', 'trakt.expires_at', 'trakt.expires', 'trakt.auth'}
    cleaned_any = False

    for target in targets:
        if not os.path.isfile(target):
            continue
        try:
            tree = ET.parse(target)
            root = tree.getroot()
            # ONLY a settings document. The sibling glob below matches by filename, and an
            # unrelated parseable .bak in this directory would otherwise have a <setting> node
            # appended into a document where it means nothing - reproduced by review against a
            # sources.bak, which came back with <setting id="trakt.revoked"> inside <sources>.
            if root.tag != 'settings':
                continue
            modified = False
            seen_revoked = False
            for s in root.findall('setting'):
                sid = s.get('id')
                if sid in keys_to_clear:
                    if (s.text and s.text.strip()) or (s.get('value') and s.get('value').strip()):
                        s.text = ''
                        if 'value' in s.attrib:
                            s.attrib['value'] = ''
                        s.attrib.pop('default', None)
                        modified = True
                elif sid == 'trakt.revoked':
                    seen_revoked = True
                    val = (s.text or s.get('value') or '').strip().lower()
                    if val != 'true':
                        # BOTH SHAPES, mirroring the blanking branch above. Writing only the
                        # text on an attribute-shaped node produces
                        #   <setting id="trakt.revoked" value="false">true</setting>
                        # - a file that says two contradictory things - and because the read
                        # on the line above is `text or value`, the next pass sees 'true' and
                        # reports nothing to do. A self-satisfying no-op.
                        s.text = 'true'
                        if 'value' in s.attrib:
                            s.attrib['value'] = 'true'
                        s.attrib.pop('default', None)
                        modified = True
            if not seen_revoked:
                rev = ET.SubElement(root, 'setting', {'id': 'trakt.revoked'})
                rev.text = 'true'
                # Match the shape the document already uses rather than forcing the text form.
                if any('value' in n.attrib for n in root.findall('setting')):
                    rev.attrib['value'] = 'true'
                modified = True

            if modified:
                # ATOMIC. ET.write truncates before writing, and this runs at boot at the same
                # time as The Crew's own settings_repair rewrites the same file. A kill in that
                # window leaves a 0-byte settings.xml and The Crew loses its scrapers, resolver
                # and debrid config - a far worse outcome than the toast being fixed.
                tmp = target + '.starwave-tmp'
                tree.write(tmp, encoding='utf-8', xml_declaration=True)
                os.replace(tmp, target)
                cleaned_any = True
        except Exception as exc:  # noqa: BLE001
            log("could not clean thecrew settings %s: %s" % (target, exc), xbmc.LOGWARNING)

    # If running live inside Kodi, update in-memory settings to avoid shutdown write races
    if KODI_AVAILABLE:
        try:
            crew_addon = xbmcaddon.Addon('plugin.video.thecrew')
            cur_tok = crew_addon.getSetting('trakt.token')
            cur_usr = crew_addon.getSetting('trakt.user')
            if cur_tok or cur_usr:
                crew_addon.setSetting('trakt.token', '')
                crew_addon.setSetting('trakt.user', '')
                crew_addon.setSetting('trakt.refresh', '')
                crew_addon.setSetting('trakt.expires_at', '')
                cleaned_any = True
            # THE REVOKED STAMP IS NOT GATED ON A TOKEN BEING PRESENT, and that is the whole
            # point. The failure it fixes, observed on the Steam Deck 2026-09-06 and diagnosed
            # in review: disk already clean from a previous boot, but Kodi's in-memory copy
            # still holds trakt.revoked='false' - The Crew's clear_trakt_revoked() writes false
            # on ANY successful token write, including a plain refresh. With the old
            # `if cur_tok or cur_usr` guard around this line, both reads are empty, the branch
            # is skipped, and Kodi's settings flush writes false back over the file on exit.
            # The invariant then repairs the file on the next boot and the cycle repeats: one
            # toast every boot, forever, with the log claiming CORRECTED each time. Measured:
            # after a repair pass the Deck's four files came back armed with revoked=false
            # once Kodi exited.
            if (crew_addon.getSetting('trakt.revoked') or '').strip().lower() != 'true':
                crew_addon.setSetting('trakt.revoked', 'true')
                cleaned_any = True
        except Exception as exc:  # noqa: BLE001
            # NOT silent. This branch is what makes the on-disk purge survive Kodi's exit
            # write, so a failure here is the difference between a fix and a fix that is
            # undone by the session that applied it.
            log('could not update The Crew settings in memory (%s); the on-disk purge may be '
                'overwritten when Kodi exits' % exc, xbmc.LOGWARNING)

    if cleaned_any:
        msg = "CORRECTED: purged incompatible Trakt credentials from The Crew (prevents false 'Trakt session expired' on boot)"
        log(msg)
        fixes.append(msg)

    return fixes


def ensure_unpausejumpback_settings(home=None):
    """Ensure script.xbmc.unpausejumpback excludes LiveTV and HTTP streams from jumpback.

    When active on live HLS streams, Unpause Jumpback issues a backward seek 5s into playback.
    Live rolling HLS manifests have narrow segment windows (e.g. 20s); seeking backward triggers
    HTTP 404s, pipeline stalls, and dropped frames. ExcludeLiveTV and ExcludeHTTP must remain true.
    """
    base_home = home or HOME
    target = os.path.join(base_home, 'userdata', 'addon_data', 'script.xbmc.unpausejumpback', 'settings.xml')
    if not os.path.exists(target):
        return []

    fixes = []
    cleaned_any = False

    try:
        import xml.etree.ElementTree as ET
        tree = ET.parse(target)
        root = tree.getroot()
        needed = {'ExcludeLiveTV': 'true', 'ExcludeHTTP': 'true'}
        found = set()

        for s in root.findall('setting'):
            sid = s.get('id', '')
            if sid in needed:
                found.add(sid)
                if (s.text or '').strip().lower() != needed[sid]:
                    s.text = needed[sid]
                    if 'default' in s.attrib:
                        del s.attrib['default']
                    cleaned_any = True

        for sid, val in needed.items():
            if sid not in found:
                elem = ET.SubElement(root, 'setting', {'id': sid})
                elem.text = val
                cleaned_any = True

        if cleaned_any:
            tmp = target + '.tmp'
            tree.write(tmp, encoding='utf-8', xml_declaration=True)
            os.replace(tmp, target)
    except Exception as exc:  # noqa: BLE001
        log("could not update unpausejumpback settings %s: %s" % (target, exc), xbmc.LOGWARNING)

    # If running live inside Kodi, update in-memory settings to avoid shutdown write races
    if KODI_AVAILABLE:
        try:
            upjb = xbmcaddon.Addon('script.xbmc.unpausejumpback')
            for sid in ('ExcludeLiveTV', 'ExcludeHTTP'):
                if (upjb.getSetting(sid) or '').strip().lower() != 'true':
                    upjb.setSetting(sid, 'true')
                    cleaned_any = True
        except Exception as exc:  # noqa: BLE001
            log('could not update unpausejumpback settings in memory (%s)' % exc, xbmc.LOGWARNING)

    if cleaned_any:
        msg = "CORRECTED: forced ExcludeLiveTV/ExcludeHTTP true in script.xbmc.unpausejumpback (prevents live stream freeze)"
        log(msg)
        fixes.append(msg)

    return fixes


if __name__ == '__main__':
    router(sys.argv[2] if len(sys.argv) > 2 else '')
