# -*- coding: utf-8 -*-
"""StarWave Wizard - bring-your-own Live TV provider (Xtream Codes).

Each user signs in to their OWN provider; their channels then appear in Kodi's TV guide as
"My TV · ..." groups beside StarWave's free channels. Nothing here knows any provider: no name,
no host, no default. Off by default, and off costs one file-exists check at boot.

HOW IT IS WIRED, AND WHY (plans/2026-11-03-byo-iptv.md; Aegis, Neo, Trinity consults):

  - A SECOND pvr.iptvsimple instance, instance-settings-<N>.xml with N >= 2 (the first free
    one), that holds ONLY LOCAL PATHS - no login. It is not routed through IPTV Merge: Merge
    re-merges every 2 hours and would put the provider inside the free guide's fate.
  - The wizard downloads the provider's catalogue (player_api.php), filters it to the user's
    picks and writes playlist.m3u8 into the wizard's OWN addon_data/live_tv/ folder. That file
    cannot be login-free - Xtream puts the login in every stream path - which is exactly why it
    lives in the one folder every capture path already leaves out. Folder 0700, files 0600.
  - The login itself lives in the wizard's settings.xml, beside gh_token. Typed once per device;
    no build ever carries it, the owner's personal build included.
  - Refreshed at most once a day, from the service, in the background. pvr.iptvsimple is NEVER
    disabled and re-enabled to pick up a change: that drags inputstream.ffmpegdirect back on as
    a dependency (see restart_pvr in default.py). A change takes effect on the next Kodi start.
  - Catch-up is off: it needs ffmpegdirect, which StarWave turns off at every boot.

Pure Python, no Kodi import, so it is tested offline against a fake server
(scripts/test-live-tv-provider.py). default.py owns the dialogs and passes in the paths, the
login, a log function and its own atomic writer.

LOGGING: host only, never a URL, never an exception's text. kodi.log is the file people paste
into forums, and an exception message (`unknown url type: 'htp://..'`) can carry the whole URL.
"""

import gzip
import http.client
import json
import os
import re
import shutil
import socket
import tempfile
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
import zlib
import xml.etree.ElementTree as ET
from xml.parsers import expat

WIZARD_ID = 'plugin.program.starwave.wizard'
PVR_ID = 'pvr.iptvsimple'

LIVE_TV_DIR = 'live_tv'
PLAYLIST_NAME = 'playlist.m3u8'
STATE_NAME = 'live_tv.json'
# What the instance file points IPTV Simple at. special://profile worked on Kodi 21.3 (Deck
# prototype, 2026-11-03: 13,366 channels parsed in 227 ms).
PLAYLIST_SPECIAL = 'special://profile/addon_data/%s/%s/%s' % (WIZARD_ID, LIVE_TV_DIR, PLAYLIST_NAME)
GUIDE_NAME = 'epg.xml.gz'
# The provider's guide, filtered to the picked channels. The instance file points IPTV Simple at
# this LOCAL file (epgPathType 0), never at xmltv.php: that URL carries the login.
GUIDE_SPECIAL = 'special://profile/addon_data/%s/%s/%s' % (WIZARD_ID, LIVE_TV_DIR, GUIDE_NAME)
# What live_tv.json's guide_url holds for "Provider's guide": a marker, never a link. The
# xmltv.php URL is built in memory from the saved login at each fetch and is never stored.
GUIDE_PROVIDER = 'provider'
INSTANCE_RE = re.compile(r'^instance-settings-(\d+)\.xml$')
INSTANCE_NAME = 'My TV'
GROUP_PREFIX = 'My TV \u00b7 '
FAVOURITES_GROUP = GROUP_PREFIX + 'Favorites'
# Provider channels number from here so StarWave's free channels keep the numbers people know.
START_NUM = 1000

DIR_MODE = 0o700
FILE_MODE = 0o600
REFRESH_SECONDS = 24 * 3600
EXPIRY_WARN_SECONDS = 3 * 24 * 3600
LOGIN_TIMEOUT = 20
CATALOGUE_TIMEOUT = 120
USER_AGENT = 'Mozilla/5.0'
# The guide feed is third-party input of any size (Aegis a6b82f7 B2). The size cap counts
# DECOMPRESSED bytes, so a gzip bomb trips it; the deadline is ONE wall clock for the whole fetch,
# because urllib's timeout covers each read separately and a drip-feeding server would beat it.
GUIDE_MAX_BYTES = 500 * 1024 * 1024
GUIDE_DEADLINE = 300
GUIDE_READ_TIMEOUT = 15
GUIDE_CHUNK = 64 * 1024
# A guide that is chosen but missing (first fill cancelled or failed) is retried at the next start
# at most this often, rather than waiting for the daily refresh.
GUIDE_RETRY_SECONDS = 3600
TMP_SUFFIX = '.starwave-tmp'
# A leftover temp file older than this is from a killed write and is swept at each guide fetch.
# Anything younger may be a live write in the other process (the wizard UI and the service).
TMP_SWEEP_AGE = 60

# The five answers a login check can give - each one is its own screen in the wizard.
OK = 'ok'
AUTH_FAILED = 'auth_failed'
EXPIRED = 'expired'
UNREACHABLE = 'unreachable'
TIMEOUT = 'timeout'
# ...and the ways a guide fetch can fail on top of those. Every one keeps the previous guide.
TOO_LARGE = 'too_large'
REFUSED = 'refused_dtd'
BAD_XML = 'bad_xml'
NOT_A_GUIDE = 'not_a_guide'
EMPTY = 'empty'
CANCELLED = 'cancelled'
NO_IDS = 'no_guide_ids'

MONTHS = ('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec')


def _nolog(msg):
    pass


# ----------------------------------------------------------------------------- the server


# Stray punctuation a pasted address picks up from a message or a web page.
_STRIP = ' \t\r\n,;\'"<>()[]'


def normalise_server(text):
    """What the user typed or pasted -> (server, username, password).

    Accepts a bare `host:port`, a full `http://host:port/`, or a whole pasted M3U / player_api
    link, in which case the username and password are lifted out of it so the user does not
    type them twice (they come back '' when the link did not carry them). The server is always
    `scheme://host[:port]` - the path, query and any `user:pass@` are dropped. Returns
    ('', '', '') when there is no usable host.
    """
    text = (text or '').strip(_STRIP)
    if not text:
        return '', '', ''
    if not re.match(r'^[a-z][a-z0-9+.-]*://', text, re.I):
        text = 'http://' + text
    try:
        parts = urllib.parse.urlsplit(text)
        host = (parts.hostname or '').strip(_STRIP + '.')
        port = parts.port
    except ValueError:
        return '', '', ''
    scheme = parts.scheme.lower()
    if scheme not in ('http', 'https') or not host or not re.match(r'^[A-Za-z0-9.:-]+$', host):
        return '', '', ''
    if ':' in host:
        host = '[%s]' % host
    server = '%s://%s%s' % (scheme, host, ':%d' % port if port else '')
    q = urllib.parse.parse_qs(parts.query)
    user = (q.get('username') or [''])[0].strip()
    password = (q.get('password') or [''])[0].strip()
    return server, user, password


def host_of(server):
    """The ONLY form of a provider address that is ever logged or shown in a log line."""
    try:
        return urllib.parse.urlsplit(server or '').hostname or 'unknown-host'
    except ValueError:
        return 'unknown-host'


def _api_url(server, username, password, action=None):
    q = {'username': username, 'password': password}
    if action:
        q['action'] = action
    return '%s/player_api.php?%s' % (server, urllib.parse.urlencode(q))


class ProviderError(Exception):
    """A request failed; `.state` is one of the five login states. Carries no URL."""

    def __init__(self, state):
        Exception.__init__(self, state)
        self.state = state


def _get_json(url, timeout):
    req = urllib.request.Request(url, headers={'User-Agent': USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read()
    except urllib.error.HTTPError as exc:
        # Panels answer a wrong login with 401/403 as often as with auth:0 in a 200.
        raise ProviderError(AUTH_FAILED if exc.code in (401, 403) else UNREACHABLE)
    except urllib.error.URLError as exc:
        reason = getattr(exc, 'reason', None)
        raise ProviderError(TIMEOUT if isinstance(reason, (socket.timeout, TimeoutError))
                       else UNREACHABLE)
    except (socket.timeout, TimeoutError):
        raise ProviderError(TIMEOUT)
    except (OSError, ValueError):
        raise ProviderError(UNREACHABLE)
    try:
        return json.loads(body.decode('utf-8', 'replace'))
    except ValueError:
        raise ProviderError(UNREACHABLE)


def _int_or_none(value):
    try:
        value = int(str(value).strip())
    except (TypeError, ValueError):
        return None
    return value or None


def check_login(server, username, password, timeout=LOGIN_TIMEOUT, now=None):
    """Ask the provider whether this login works, before anything is saved.

    Returns {'state', 'exp_date', 'max_connections', 'ext'}. Deliberately NOT the provider's
    user_info: that object echoes the username and password back, and nothing downstream needs
    them from here. exp_date is epoch seconds, None when the line has no expiry.
    """
    out = {'state': UNREACHABLE, 'exp_date': None, 'max_connections': None, 'ext': 'ts'}
    if not (server and username and password):
        out['state'] = AUTH_FAILED if server else UNREACHABLE
        return out
    try:
        info = _get_json(_api_url(server, username, password), timeout)
    except ProviderError as exc:
        out['state'] = exc.state
        return out
    ui = (info or {}).get('user_info') if isinstance(info, dict) else None
    if not isinstance(ui, dict):
        out['state'] = AUTH_FAILED
        return out
    now = time.time() if now is None else now
    exp = _int_or_none(ui.get('exp_date'))
    status = str(ui.get('status') or '').strip().lower()
    out['exp_date'] = exp
    out['max_connections'] = _int_or_none(ui.get('max_connections'))
    formats = [str(f).lower() for f in (ui.get('allowed_output_formats') or [])]
    out['ext'] = 'm3u8' if formats and 'ts' not in formats and 'm3u8' in formats else 'ts'
    if status == 'expired' or (exp and exp < now):
        out['state'] = EXPIRED
    elif str(ui.get('auth')) != '1' or status not in ('active', ''):
        out['state'] = AUTH_FAILED
    else:
        out['state'] = OK
    return out


# ----------------------------------------------------------------------------- the catalogue


def clean_name(text):
    """Strip the decoration providers put in names: superscript and modifier letters (ᴴᴰ ᵁᴴᴰ ³),
    variation selectors and other invisible format characters, and symbols (★ ⚽). Real letters
    in any script - accents included - are kept."""
    text = unicodedata.normalize('NFC', text or '')
    keep = []
    for ch in text:
        cat = unicodedata.category(ch)
        name = unicodedata.name(ch, '')
        if 'SUPERSCRIPT' in name or 'MODIFIER LETTER' in name or name.startswith('VARIATION SELECTOR'):
            continue
        if cat in ('Cf', 'So', 'Cc', 'Co', 'Cs'):
            continue
        keep.append(ch)
    return re.sub(r'\s+', ' ', ''.join(keep)).strip(' ./|-')


def region_of(category_name):
    """'US| SPORTS' -> 'US', '4K: MOVIES' -> '4K'; no prefix -> 'Other'."""
    m = re.match(r'\s*([^|:]{1,12}?)\s*[|:]', category_name or '')
    region = clean_name(m.group(1)).upper() if m else ''
    return region or 'Other'


def fetch_catalogue(server, username, password, timeout=CATALOGUE_TIMEOUT):
    """(categories, streams) for the provider's LIVE channels. Raises ProviderError.

    categories: [{'id', 'name', 'region'}]; streams: [{'id', 'name', 'category_id', 'epg_id',
    'icon'}]. Neither holds the login - only the playlist built from them does.
    """
    cats_raw = _get_json(_api_url(server, username, password, 'get_live_categories'), timeout)
    streams_raw = _get_json(_api_url(server, username, password, 'get_live_streams'), timeout)
    if not isinstance(cats_raw, list) or not isinstance(streams_raw, list):
        raise ProviderError(AUTH_FAILED)
    categories = []
    for c in cats_raw:
        if not isinstance(c, dict) or c.get('category_id') is None:
            continue
        name = str(c.get('category_name') or '')
        categories.append({'id': str(c['category_id']), 'name': name, 'region': region_of(name)})
    streams = []
    for s in streams_raw:
        if not isinstance(s, dict) or s.get('stream_id') is None:
            continue
        cid = s.get('category_id')
        if cid is None and s.get('category_ids'):
            cid = s['category_ids'][0]
        streams.append({'id': str(s['stream_id']), 'name': str(s.get('name') or ''),
                        'category_id': str(cid) if cid is not None else '',
                        'epg_id': str(s.get('epg_channel_id') or ''),
                        'icon': str(s.get('stream_icon') or '')})
    return categories, streams


def channel_counts(streams):
    counts = {}
    for s in streams:
        counts[s['category_id']] = counts.get(s['category_id'], 0) + 1
    return counts


def regions(categories, streams):
    """[(region, groups, channels)], biggest first - the first screen of the picker."""
    counts = channel_counts(streams)
    agg = {}
    for c in categories:
        n = counts.get(c['id'], 0)
        if not n:
            continue
        g, ch = agg.get(c['region'], (0, 0))
        agg[c['region']] = (g + 1, ch + n)
    return sorted(((r, g, ch) for r, (g, ch) in agg.items()), key=lambda t: (-t[2], t[0]))


def picked_category_ids(categories, picks):
    """The category ids a stored pick resolves to TODAY.

    "All groups in these regions" is stored as regions, not ids, so a group the provider adds
    later in a picked region is picked up by the next daily refresh. Hand-picked groups are
    matched by id or, if the provider renumbered them, by name.
    """
    picks = picks or {}
    if picks.get('all_in_regions'):
        wanted = set(picks.get('regions') or [])
        return {c['id'] for c in categories if c['region'] in wanted}
    ids = set(picks.get('categories') or [])
    names = set(picks.get('category_names') or [])
    return {c['id'] for c in categories if c['id'] in ids or c['name'] in names}


def login_shaped(value, password, login_res=()):
    """True when a value carries the login (Aegis a6b82f7 B1): the password raw or
    percent-encoded, or any Xtream shape in login_res. default.py passes its XTREAM_VALUE_RE and
    XTREAM_RE, so the patterns have one home and this module still imports no Kodi."""
    if not value:
        return False
    if password and (password in value or password in urllib.parse.unquote(value)
                     or password in urllib.parse.unquote_plus(value)):
        return True
    return any(r.search(value) for r in login_res)


def _attr(text):
    # IPTV Simple splits group-title on ';' (that is how a channel sits in two groups), so a
    # ';' inside one name would invent a group.
    return text.replace('"', "'").replace(';', ',')


def stream_url(server, username, password, stream_id, ext='ts'):
    return '%s/live/%s/%s/%s.%s' % (server, urllib.parse.quote(username, safe=''),
                                    urllib.parse.quote(password, safe=''), stream_id, ext)


def build_playlist(server, username, password, categories, streams, picks, favourites=(),
                   ext='ts', login_res=()):
    """The filtered M3U. Returns (text, channels, groups).

    Every group is prefixed 'My TV · ' so the provider's 'Sports' can never be confused with
    StarWave's free 'Sports'. Favourites are listed FIRST, so they take the lowest numbers
    (1000 up), and also appear in a 'My TV · Favorites' group - kept even when their own group
    is not picked, because choosing one means wanting it.

    A stream_icon carrying the login is left out of tvg-logo (the B1 scrub, Aegis a6b82f7): the
    stream URLs keep the login in this file by design, but a logo URL is fetched by Kodi's image
    loader, cached in Textures13.db and written to kodi.log when it fails.
    """
    by_id = {c['id']: c for c in categories}
    wanted = picked_category_ids(categories, picks)
    fav = [str(f) for f in (favourites or [])]
    fav_set = set(fav)
    chosen = [s for s in streams if s['category_id'] in wanted or s['id'] in fav_set]
    order = {sid: i for i, sid in enumerate(fav)}
    chosen.sort(key=lambda s: (0, order[s['id']]) if s['id'] in order else (1, 0))
    lines = ['#EXTM3U']
    groups = set()
    seen = set()
    for s in chosen:
        if s['id'] in seen:
            continue
        seen.add(s['id'])
        gl = []
        if s['id'] in fav_set:
            gl.append(FAVOURITES_GROUP)
        cat = by_id.get(s['category_id'])
        if cat and s['category_id'] in wanted:
            gl.append(GROUP_PREFIX + (clean_name(cat['name']) or 'Other'))
        groups.update(gl)
        name = clean_name(s['name']) or s['id']
        lines.append('#EXTINF:-1 tvg-id="%s" tvg-name="%s" tvg-logo="%s" group-title="%s",%s' % (
            _attr(s['epg_id']), _attr(name),
            '' if login_shaped(s['icon'], password, login_res) else _attr(s['icon']),
            ';'.join(_attr(g) for g in gl), name))
        lines.append(stream_url(server, username, password, s['id'], ext))
    return '\n'.join(lines) + '\n', len(seen), len(groups)


# ----------------------------------------------------------------------------- files


def paths(home):
    live = os.path.join(home, 'userdata', 'addon_data', WIZARD_ID, LIVE_TV_DIR)
    return {'dir': live,
            'playlist': os.path.join(live, PLAYLIST_NAME),
            'guide': os.path.join(live, GUIDE_NAME),
            'state': os.path.join(live, STATE_NAME),
            'pvr_dir': os.path.join(home, 'userdata', 'addon_data', PVR_ID)}


def is_configured(home):
    """THE boot check. One file-exists test: no read, no network, no log line."""
    return os.path.exists(os.path.join(home, 'userdata', 'addon_data', WIZARD_ID, LIVE_TV_DIR,
                                       STATE_NAME))


def _ensure_private_dir(path):
    os.makedirs(path, mode=DIR_MODE, exist_ok=True)
    os.chmod(path, DIR_MODE)


def write_private(path, text, write_text):
    """Atomic write through default.py's _atomic_write_text, landing at 0600.

    _atomic_write_text keeps an existing target's mode, so a missing target is created empty
    at 0600 first; the rename then never exposes the content at the umask's 0644. The folder is
    made 0700 in the same step, which is the real fence: nothing else can enter it.
    """
    _ensure_private_dir(os.path.dirname(path))
    if not os.path.exists(path):
        os.close(os.open(path, os.O_WRONLY | os.O_CREAT, FILE_MODE))
    os.chmod(path, FILE_MODE)
    write_text(path, text)
    os.chmod(path, FILE_MODE)


def read_state(home):
    try:
        with open(paths(home)['state'], 'r', encoding='utf-8') as fh:
            state = json.load(fh)
        return state if isinstance(state, dict) else {}
    except (OSError, ValueError):
        return {}


def write_state(home, state, write_text):
    """The non-secret half of the setup: picks, favourites, guide link, counts, expiry. No login."""
    write_private(paths(home)['state'], json.dumps(state, indent=1, sort_keys=True), write_text)


def _xml(text):
    return (text or '').replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


def instance_xml(guide_url=''):
    """The second IPTV Simple instance. LOCAL PATHS ONLY - there is no login in here.

    m3uRefreshMode 0: IPTV Simple reads the local file at its own start; the wizard rewrites it
    at most daily. Playlist cache off (it would only be a second copy of the login); guide cache
    on for a custom link. Catch-up off (it needs inputstream.ffmpegdirect, which StarWave
    disables).

    guide_url GUIDE_PROVIDER is the provider's own guide: epgPathType 0 and the LOCAL
    live_tv/epg.xml.gz, epgUrl empty. The marker itself is never written in here, and neither is
    the xmltv.php link - writing that remote URL into the instance is A2's kill line K3.
    """
    if guide_url == GUIDE_PROVIDER:
        path_type, path, url, cache = '0', GUIDE_SPECIAL, '', 'false'
    else:
        path_type, path, url, cache = '1', '', guide_url, 'true' if guide_url else 'false'
    return ('<settings version="2">\n'
            '    <setting id="kodi_addon_instance_name">%s</setting>\n'
            '    <setting id="kodi_addon_instance_enabled">true</setting>\n'
            '    <setting id="m3uPathType">0</setting>\n'
            '    <setting id="m3uPath">%s</setting>\n'
            '    <setting id="m3uRefreshMode">0</setting>\n'
            '    <setting id="m3uCache">false</setting>\n'
            '    <setting id="startNum">%d</setting>\n'
            '    <setting id="epgPathType">%s</setting>\n'
            '    <setting id="epgPath">%s</setting>\n'
            '    <setting id="epgUrl">%s</setting>\n'
            '    <setting id="epgCache">%s</setting>\n'
            '    <setting id="catchupEnabled">false</setting>\n'
            '</settings>\n' % (INSTANCE_NAME, PLAYLIST_SPECIAL, START_NUM, path_type, _xml(path),
                               _xml(url), cache))


def _instances(pvr_dir):
    """{N: path} for every instance-settings-N.xml present."""
    out = {}
    if os.path.isdir(pvr_dir):
        for f in os.listdir(pvr_dir):
            m = INSTANCE_RE.match(f)
            if m:
                out[int(m.group(1))] = os.path.join(pvr_dir, f)
    return out


def _is_ours(path):
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as fh:
            return PLAYLIST_SPECIAL in fh.read()
    except OSError:
        return False


def find_instance(home):
    """N of the instance file pointing at OUR playlist, or None. Never instance 1."""
    for n, p in sorted(_instances(paths(home)['pvr_dir']).items()):
        if n >= 2 and _is_ours(p):
            return n
    return None


def write_instance(home, guide_url, write_text):
    """Write (or rewrite) our instance file; returns its N. Reuses ours, else the first free
    N >= 2, so an instance the user made by hand is never overwritten."""
    pvr_dir = paths(home)['pvr_dir']
    n = find_instance(home)
    if n is None:
        taken = _instances(pvr_dir)
        n = 2
        while n in taken:
            n += 1
    os.makedirs(pvr_dir, exist_ok=True)
    write_text(os.path.join(pvr_dir, 'instance-settings-%d.xml' % n), instance_xml(guide_url))
    return n


def remove_instance(home):
    """Delete every instance file pointing at our playlist. Idempotent; returns how many."""
    n = 0
    for num, p in _instances(paths(home)['pvr_dir']).items():
        if num >= 2 and _is_ours(p):
            try:
                os.remove(p)
                n += 1
            except OSError:
                pass
    return n


def remove_all(home):
    """Turn the feature off for good on this device: instance file and the WHOLE live_tv/ folder.
    The login in settings.xml is the caller's to blank. Idempotent; returns how many files went.

    The whole folder, not two named files: a refresh killed mid-write leaves
    playlist.m3u8.<random>.starwave-tmp behind - a full copy of the login - and "removed" has
    to mean every copy.
    """
    removed = remove_instance(home)
    live = paths(home)['dir']
    if os.path.isdir(live):
        removed += sum(len(files) for _, _, files in os.walk(live))
        shutil.rmtree(live, ignore_errors=True)
    return removed


# ----------------------------------------------------------------------------- the provider's guide
#
# xmltv.php is the provider's whole guide - every channel it has, up to hundreds of MB - with
# the login in its URL. The wizard fetches it and keeps only the entries for the picked
# channels, in live_tv/epg.xml.gz. Security requirements (Aegis a6b82f7):
#
#   - The URL is built here, in memory, from the saved login, and is never stored or logged.
#   - The feed is hostile input (B2). Parsed straight from the download by expat - no raw temp
#     file, so the unfiltered feed never touches disk. A DOCTYPE that only NAMES an outside DTD
#     (`<!DOCTYPE tv SYSTEM "xmltv.dtd">`, as real XMLTV feeds open) is allowed, and that DTD
#     is never read: parameter-entity parsing is NEVER and nothing here loads an outside entity.
#     A DOCTYPE with an internal subset - any [...], even an empty one - is refused, decided on
#     has_internal_subset alone, never on the DOCTYPE's name or ids; every entity, unparsed-entity
#     and notation declaration is refused as a second layer. The refusal is raised at the
#     opening `[`; nothing here relies on pyexpat stopping mid-buffer, and any expansion in the
#     rest of that chunk is capped by expat 2.4.0+'s own amplification limit (Aegis b86a5e2).
#     Aegis 0dace81 narrowed a6b82f7's "refuse any DOCTYPE" to this. The size cap counts
#     decompressed bytes; one wall-clock deadline covers the download (connecting and the
#     response headers run on urlopen's own timeout).
#   - The guide is scrubbed of the login before writing (B1): once IPTV Simple loads it, its
#     contents leave live_tv/ - Kodi's EPG database, IPTV Simple's cache, icon failures in
#     kodi.log. Entries for unpicked channels are never built at all, so memory stays flat.
#   - Any failure keeps the previous guide: the new one is written to a .starwave-tmp file
#     (0600, from mkstemp) and renamed over the old one only when it is complete.
#   - Certificate checks are never turned off, and a redirect target or parse error's text is
#     never logged - host only, via host_of.


class _GuideAbort(Exception):
    """Raised out of an expat handler or the read loop; `.state` says why. Carries no URL."""

    def __init__(self, state):
        Exception.__init__(self, state)
        self.state = state


def _refuse_dtd(*args):
    raise _GuideAbort(REFUSED)


def _doctype(name, system_id, public_id, has_internal_subset):
    """An outside-DTD-only DOCTYPE passes; one with an internal subset is refused. Decided on
    has_internal_subset ONLY (Aegis 0dace81) - never on the name or the ids."""
    if has_internal_subset:
        raise _GuideAbort(REFUSED)


def guide_key(channel_id):
    """How a guide channel id and a playlist tvg-id are compared: the same _attr() the playlist
    applied, case-insensitive (as IPTV Simple matches them)."""
    return _attr(channel_id or '').strip().casefold()


def playlist_guide_ids(path):
    """The tvg-ids in our playlist - the channels whose guide entries are kept."""
    ids = set()
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as fh:
            for line in fh:
                m = re.match(r'#EXTINF:[^\n]*?\btvg-id="([^"]*)"', line)
                if m and m.group(1).strip():
                    ids.add(guide_key(m.group(1)))
    except OSError:
        pass
    return ids


class _GuideFilter(object):
    """expat handlers. Builds a small tree for each <channel>/<programme> whose id is picked,
    scrubs it and writes it out; anything else is skipped without being built."""

    def __init__(self, keep, password, login_res, write):
        self.keep = keep
        self.password = password
        self.login_res = login_res
        self.write = write
        self.depth = 0
        self.root = None
        self.skip = 0          # > 0 while inside an entry that is not kept
        self.stack = []        # the kept entry being built, outermost first
        self.text = []         # character data per level of self.stack
        self.channels = self.programmes = self.dropped = 0

    def start(self, name, attrs):
        self.depth += 1
        if self.depth == 1:
            if name != 'tv':
                raise _GuideAbort(NOT_A_GUIDE)
            self.root = name
        elif self.stack:
            self.stack.append(ET.SubElement(self.stack[-1], name, attrs))
            self.text.append([])
        elif self.skip:
            self.skip += 1
        elif (name in ('channel', 'programme')
              and guide_key(attrs.get('id' if name == 'channel' else 'channel')) in self.keep):
            self.stack = [ET.Element(name, attrs)]
            self.text = [[]]
        else:
            self.skip = 1

    def end(self, name):
        self.depth -= 1
        if self.stack:
            el = self.stack.pop()
            text = ''.join(self.text.pop())
            if text.strip():
                el.text = text
            if not self.stack:
                self._emit(el)
        elif self.skip:
            self.skip -= 1

    def data(self, text):
        if self.stack:
            self.text[-1].append(text)

    def _bad(self, el):
        return (login_shaped(el.text, self.password, self.login_res)
                or any(login_shaped(v, self.password, self.login_res) for v in el.attrib.values()))

    def _scrub(self, el):
        """Drop every descendant element whose text or any attribute carries the login."""
        for child in list(el):
            if self._bad(child):
                el.remove(child)
                self.dropped += 1
            else:
                self._scrub(child)

    def _emit(self, el):
        # The entry's own id / channel / start carrying the login: the whole entry goes.
        if self._bad(el):
            self.dropped += 1
            return
        self._scrub(el)
        self.write(ET.tostring(el, encoding='utf-8') + b'\n')
        if el.tag == 'channel':
            self.channels += 1
        else:
            self.programmes += 1


def _guide_url(server, username, password):
    """In memory only. Never stored, never logged, never written into the instance file."""
    return '%s/xmltv.php?%s' % (server, urllib.parse.urlencode({'username': username,
                                                                'password': password}))


def _set_read_timeout(resp, seconds):
    """Shorten the socket's per-read timeout to what is left of the deadline. Best effort: if
    the socket cannot be reached, each read still waits at most GUIDE_READ_TIMEOUT."""
    try:
        resp.fp.raw._sock.settimeout(max(seconds, 0.05))
    except (AttributeError, OSError, ValueError):
        pass


def sweep_temp(folder, age=TMP_SWEEP_AGE, now=None):
    """Delete *.starwave-tmp files in folder older than `age` seconds - what a killed write left.
    Returns how many went."""
    now = time.time() if now is None else now
    n = 0
    try:
        names = os.listdir(folder)
    except OSError:
        return 0
    for f in names:
        if not f.endswith(TMP_SUFFIX):
            continue
        p = os.path.join(folder, f)
        try:
            if now - os.path.getmtime(p) >= age:
                os.remove(p)
                n += 1
        except OSError:
            pass
    return n


def fetch_provider_guide(login, keep_ids, dest, login_res, log=_nolog, progress=None,
                         max_bytes=GUIDE_MAX_BYTES, deadline=GUIDE_DEADLINE,
                         read_timeout=GUIDE_READ_TIMEOUT, sweep_age=TMP_SWEEP_AGE):
    """Fetch the provider's XMLTV guide, keep only keep_ids, scrub it, and write dest atomically.

    keep_ids: guide_key() values of the picked channels. login_res: the wizard's Xtream patterns
    (see login_shaped). progress(decompressed_bytes) may return True to cancel. Never raises.
    Returns {'state', 'channels', 'programmes', 'dropped'}; on any state but OK, dest is exactly
    as it was. Logs one line, host only.
    """
    out = {'state': UNREACHABLE, 'channels': 0, 'programmes': 0, 'dropped': 0}
    server = login.get('server') or ''
    host = host_of(server)
    folder = os.path.dirname(dest)
    end = time.monotonic() + deadline
    resp = fh = gz = None
    tmp = None
    try:
        _ensure_private_dir(folder)
        sweep_temp(folder, sweep_age)
        if not keep_ids:
            raise _GuideAbort(NO_IDS)
        if not (server and login.get('username') and login.get('password')):
            raise _GuideAbort(AUTH_FAILED)
        req = urllib.request.Request(
            _guide_url(server, login['username'], login['password']),
            headers={'User-Agent': USER_AGENT, 'Accept-Encoding': 'gzip'})
        try:
            resp = urllib.request.urlopen(req, timeout=min(read_timeout, deadline))
        except urllib.error.HTTPError as exc:
            exc.close()
            raise _GuideAbort(AUTH_FAILED if exc.code in (401, 403) else UNREACHABLE)
        except urllib.error.URLError as exc:
            raise _GuideAbort(TIMEOUT if isinstance(getattr(exc, 'reason', None),
                                                     (socket.timeout, TimeoutError))
                              else UNREACHABLE)

        fd, tmp = tempfile.mkstemp(dir=folder, prefix=GUIDE_NAME + '.', suffix=TMP_SUFFIX)
        fh = os.fdopen(fd, 'wb')
        gz = gzip.GzipFile(fileobj=fh, mode='wb', compresslevel=6, mtime=0)
        # Our own <tv> root: the feed's root attributes (a generator-info-url can be the panel's
        # address) are never copied.
        buf = [b'<?xml version="1.0" encoding="UTF-8"?>\n<tv generator-info-name="StarWave">\n']

        def write(b):
            buf.append(b)
            if len(buf) >= 512:
                gz.write(b''.join(buf))
                buf[:] = []

        filt = _GuideFilter(set(keep_ids), login['password'], tuple(login_res), write)
        parser = expat.ParserCreate()
        parser.buffer_text = True
        parser.SetParamEntityParsing(expat.XML_PARAM_ENTITY_PARSING_NEVER)
        parser.StartDoctypeDeclHandler = _doctype
        parser.EntityDeclHandler = _refuse_dtd
        parser.UnparsedEntityDeclHandler = _refuse_dtd
        parser.NotationDeclHandler = _refuse_dtd
        parser.StartElementHandler = filt.start
        parser.EndElementHandler = filt.end
        parser.CharacterDataHandler = filt.data

        total = [0]

        def feed(xml_bytes):
            total[0] += len(xml_bytes)
            if total[0] > max_bytes:
                raise _GuideAbort(TOO_LARGE)
            if time.monotonic() > end:
                raise _GuideAbort(TIMEOUT)
            parser.Parse(xml_bytes, False)
            if progress and progress(total[0]):
                raise _GuideAbort(CANCELLED)

        inflate = None   # a zlib decompressor once the first bytes say gzip
        head = b''
        while True:
            left = end - time.monotonic()
            if left <= 0:
                raise _GuideAbort(TIMEOUT)
            _set_read_timeout(resp, min(read_timeout, left))
            try:
                chunk = resp.read1(GUIDE_CHUNK)
            except (socket.timeout, TimeoutError):
                raise _GuideAbort(TIMEOUT)
            if inflate is None and head is not None:
                head += chunk
                if len(head) < 2 and chunk:
                    continue
                chunk, head = head, None
                if chunk[:2] == b'\x1f\x8b':
                    inflate = zlib.decompressobj(16 + zlib.MAX_WBITS)
            if not chunk:
                break
            if inflate is None:
                feed(chunk)
                continue
            data = chunk
            while data:
                # max_length keeps one small compressed chunk from inflating all at once.
                xml_bytes = inflate.decompress(data, GUIDE_CHUNK * 4)
                if xml_bytes:
                    feed(xml_bytes)
                data = inflate.unconsumed_tail
                if inflate.eof:
                    rest = inflate.unused_data
                    if rest.strip(b'\x00'):          # a second gzip member
                        inflate = zlib.decompressobj(16 + zlib.MAX_WBITS)
                        data = rest
                    else:
                        data = b''
        if inflate is not None and not inflate.eof:
            raise _GuideAbort(BAD_XML)               # the gzip stream was cut off
        parser.Parse(b'', True)
        if filt.root != 'tv':
            raise _GuideAbort(NOT_A_GUIDE)
        if not (filt.channels or filt.programmes):
            raise _GuideAbort(EMPTY)
        buf.append(b'</tv>\n')
        gz.write(b''.join(buf))
        gz.close()
        fh.flush()
        os.fsync(fh.fileno())
        fh.close()
        gz = fh = None
        os.chmod(tmp, FILE_MODE)
        # The temp file is mkstemp's 0600 and the rename carries its mode, so a brand-new guide
        # is never readable at the umask's 0644, not even for a moment.
        os.replace(tmp, dest)
        tmp = None
        os.chmod(dest, FILE_MODE)
        out.update({'state': OK, 'channels': filt.channels, 'programmes': filt.programmes,
                    'dropped': filt.dropped})
    except _GuideAbort as exc:
        out['state'] = exc.state
    except expat.ExpatError:
        out['state'] = BAD_XML        # its text names a line and column; never logged
    except (socket.timeout, TimeoutError):
        out['state'] = TIMEOUT
    except (OSError, http.client.HTTPException):
        out['state'] = UNREACHABLE    # a connection cut mid-download, or a full disk
    except Exception as exc:  # noqa: BLE001 - a guide fetch must never raise
        out['state'] = 'failed (%s)' % type(exc).__name__
    finally:
        for closer in (gz, fh, resp):
            try:
                if closer is not None:
                    closer.close()
            except Exception:  # noqa: BLE001
                pass
        if tmp:
            try:
                os.remove(tmp)
            except OSError:
                pass
    if out['state'] == OK:
        line = 'Live TV provider guide: %d channels, %d programmes from %s' % (
            out['channels'], out['programmes'], host)
        if out['dropped']:
            line += '; %d login-shaped values dropped' % out['dropped']
    else:
        line = 'Live TV provider guide: %s at %s - kept the existing guide' % (out['state'], host)
    log(line)
    return out


def guide_due(home, state, now=None):
    """The provider's guide is chosen but missing, and nothing was tried within the hour (a
    failed login check counts as a try, so a dead provider is not re-asked at every start)."""
    if not state.get('enabled') or state.get('guide_url') != GUIDE_PROVIDER:
        return False
    if os.path.exists(paths(home)['guide']):
        return False
    now = time.time() if now is None else now
    tried = max(float(state.get('guide_attempt') or 0), float(state.get('last_attempt') or 0))
    return now - tried >= GUIDE_RETRY_SECONDS


def refresh_guide(home, login, state, login_res, log=_nolog, progress=None, now=None, **caps):
    """Fetch the provider's guide for the channels in our playlist and record the attempt in
    state (the caller writes it). Returns fetch_provider_guide's result."""
    p = paths(home)
    state['guide_attempt'] = time.time() if now is None else now
    res = fetch_provider_guide(login, playlist_guide_ids(p['playlist']), p['guide'], login_res,
                               log, progress, **caps)
    state['guide_check'] = res['state']
    if res['state'] == OK:
        state['guide_refresh'] = state['guide_attempt']
    return res


def remove_guide(home):
    """Delete epg.xml.gz (feature off, or the guide switched away from the provider's)."""
    try:
        os.remove(paths(home)['guide'])
        return 1
    except OSError:
        return 0


# ----------------------------------------------------------------------------- refresh


def refresh_due(home, state, now=None):
    if not state.get('enabled'):
        return False
    now = time.time() if now is None else now
    if not os.path.exists(paths(home)['playlist']):
        return True
    if guide_due(home, state, now):
        return True
    return now - float(state.get('last_attempt') or 0) >= REFRESH_SECONDS


def apply(home, login, state, catalogue, ext, write_text, login_res=()):
    """Build and write the playlist from a fetched catalogue, and record the result in state.

    Refuses to replace a working playlist with an empty one (a provider that renamed every
    category overnight): the old channels stay and the reason is returned instead.
    Returns (ok, channels, groups).
    """
    categories, streams = catalogue
    text, channels, groups = build_playlist(
        login['server'], login['username'], login['password'], categories, streams,
        state.get('picks'), state.get('favourites'), ext, login_res)
    if not channels and os.path.exists(paths(home)['playlist']):
        return False, 0, 0
    write_private(paths(home)['playlist'], text, write_text)
    state.update({'channels': channels, 'groups': groups})
    return True, channels, groups


def refresh(home, login, write_text, log=_nolog, now=None, login_res=(), stop=None):
    """The daily refresh. Re-checks the login, re-fetches the catalogue, rewrites the playlist,
    and, when the provider's guide is chosen, re-fetches that too (it logs its own line).

    Never raises and never touches a working playlist or guide on failure. Returns a one-line,
    credential-free result. stop() returning True (Kodi shutting down) abandons a guide fetch.
    """
    now = time.time() if now is None else now
    state = read_state(home)
    host = host_of(login.get('server'))
    state['last_attempt'] = now
    try:
        chk = check_login(login.get('server'), login.get('username'), login.get('password'))
        state['last_check'] = chk['state']
        if chk['state'] != OK:
            raise ProviderError(chk['state'])
        state.update({'exp_date': chk['exp_date'], 'max_connections': chk['max_connections']})
        catalogue = fetch_catalogue(login['server'], login['username'], login['password'])
        ok, channels, groups = apply(home, login, state, catalogue, chk['ext'], write_text,
                                     login_res)
        if ok and state.get('guide_url') == GUIDE_PROVIDER:
            refresh_guide(home, login, state, login_res, log,
                          (lambda n: stop()) if stop else None, now)
        if not ok:
            line = ('Live TV provider: none of your picked groups exist at %s any more - kept '
                    'the existing channels' % host)
        else:
            state['last_refresh'] = now
            line = 'Live TV provider: %d channels in %d groups refreshed from %s' % (
                channels, groups, host)
    except ProviderError as exc:
        line = 'Live TV provider: %s at %s - kept the existing channels' % (exc.state, host)
    except Exception as exc:  # noqa: BLE001 - a background refresh must never raise
        line = 'Live TV provider: refresh failed (%s) - kept the existing channels' % (
            type(exc).__name__)
    try:
        write_state(home, state, write_text)
    except Exception as exc:  # noqa: BLE001
        line += '; could not save its state (%s)' % type(exc).__name__
    log(line)
    return line


def format_day(epoch, now=None):
    """'17 Nov', or '17 Nov 2027' when it is not this year."""
    t = time.localtime(epoch)
    this_year = time.localtime(time.time() if now is None else now).tm_year
    day = '%d %s' % (t.tm_mday, MONTHS[t.tm_mon - 1])
    return day if t.tm_year == this_year else '%s %d' % (day, t.tm_year)


def expiry_warning(state, now=None):
    """The one notification, 3 days out, once per expiry date - never on every boot.
    Returns the text, or '' when there is nothing to say (or it was already said)."""
    exp = _int_or_none(state.get('exp_date'))
    now = time.time() if now is None else now
    if not exp or not state.get('enabled') or state.get('expiry_warned_for') == exp:
        return ''
    if exp - now > EXPIRY_WARN_SECONDS:
        return ''
    state['expiry_warned_for'] = exp
    if exp <= now:
        return 'Your Live TV provider line has expired (%s)' % format_day(exp, now)
    return 'Your Live TV provider line expires %s' % format_day(exp, now)
