# -*- coding: utf-8 -*-
"""StarWave Wizard — installs builds and switches layouts on this Kodi."""

import os
import re
import sys
import json
import shutil
import time
from urllib.parse import urlencode, parse_qsl
from urllib.request import Request, urlopen

import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ICON = ADDON.getAddonInfo('icon')
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1

BASE_URL = 'https://strfck3r.github.io/starwave/'
MANIFEST_URL = BASE_URL + 'builds.json'

# Used when the manifest cannot be fetched, so a broken or missing manifest never leaves
# someone with no way to install. 'latest' resolves to the newest release carrying the asset.
FALLBACK_BUILD = {
    'id': 'starwave',
    'name': 'StarWave',
    'url': 'https://github.com/strfck3r/starwave/releases/latest/download/StarWave-V1-kodi.zip',
    'description': 'The StarWave build: skin, home menu, widgets and add-ons.',
}

HOME = xbmcvfs.translatePath('special://home/')
PACKAGES = os.path.join(HOME, 'addons', 'packages')
TEMP_DIR = xbmcvfs.translatePath('special://temp/')
TEMP_ZIP = os.path.join(TEMP_DIR, 'starwave-build.zip')
GUISETTINGS = os.path.join(HOME, 'userdata', 'guisettings.xml')
ADDONS_DB = os.path.join(HOME, 'userdata', 'Database', 'Addons33.db')

# The build is assembled on an NVIDIA Shield, so these two ship as android-aarch64 binaries.
# They cannot load anywhere else, and installing them would replace whatever the host Kodi
# already has. Everything else in the build is Python, skin XML or images and is portable.
ANDROID_ONLY = ('inputstream.adaptive', 'vfs.libarchive')

# Update mode leaves these alone when they already exist on the device. They hold the user's
# own state — Kodi's system/player/media/skin settings and their sources, favourites, logins
# and profiles — none of which an update should reset.
USER_FILES = (
    'userdata/guisettings.xml',
    'userdata/sources.xml',
    'userdata/favourites.xml',
    'userdata/passwords.xml',
    'userdata/profiles.xml',
)

# The add-on database is never extracted in update mode: the device's copy also registers
# add-ons the user installed themselves, which the build's copy knows nothing about. New
# build add-ons are merged into it instead (see merge_installed).
ADDONS_DB_MEMBER = 'userdata/Database/Addons33.db'

# Layouts are skins plus their menu/widget configuration. They are deliberately independent
# of builds: no Kodi setting, add-on setting or saved login lives in either skin's data, so
# switching between them never disturbs credentials or preferences.
FALLBACK_LAYOUTS = [
    {
        'id': 'starwave',
        'name': 'StarWave',
        'skin': 'skin.NTVaura',
        'description': 'The original StarWave layout.',
    },
    {
        'id': 'arcticfuse',
        'name': 'Arctic Fuse',
        'skin': 'skin.arctic.fuse.3',
        'config': BASE_URL + 'layouts/arctic-fuse-config.zip',
        'description': 'Arctic Fuse 3, configured against your Trakt lists and add-ons.',
    },
]


def is_android():
    return xbmc.getCondVisibility('System.Platform.Android')


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), level)


def notify(msg, ms=4000):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, ICON, ms)


def build_url(**kwargs):
    return '%s?%s' % (sys.argv[0], urlencode(kwargs))


def add_item(label, description, folder=False, **params):
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': ICON, 'thumb': ICON})
    li.setInfo('video', {'title': label, 'plot': description})
    xbmcplugin.addDirectoryItem(HANDLE, build_url(**params), li, folder)


def fetch(url, timeout=20):
    req = Request(url, headers={'User-Agent': 'StarWave-Wizard'})
    return urlopen(req, timeout=timeout).read()


def get_manifest():
    """Builds and layouts, published alongside the repository.

    Keeping this in a manifest means a new build or layout needs only a new file and a
    manifest line — no wizard update on any device.
    """
    try:
        data = json.loads(fetch(MANIFEST_URL).decode('utf-8'))
        builds = [b for b in data.get('builds', []) if b.get('url') and b.get('name')]
        layouts = [l for l in data.get('layouts', []) if l.get('skin') and l.get('name')]
        return (builds or [FALLBACK_BUILD]), (layouts or FALLBACK_LAYOUTS)
    except Exception as exc:  # noqa: BLE001
        log('could not read the build manifest (%s); using built-in defaults' % exc,
            xbmc.LOGWARNING)
        return [FALLBACK_BUILD], FALLBACK_LAYOUTS


# ----------------------------------------------------------------------------- menus


def menu():
    add_item(
        'Install or update a build',
        'Choose which StarWave build to put on this device, then whether to keep your '
        'existing settings or reset to that build\'s defaults.',
        folder=True, action='builds',
    )
    add_item(
        'Switch layout',
        'Change the look of the build without touching anything else. Your Kodi settings, '
        'sources, favourites and every add-on login stay exactly as they are.',
        folder=True, action='layouts',
    )
    add_item('What this installs', 'Details of what each option changes.', action='info')
    xbmcplugin.endOfDirectory(HANDLE)


def builds_menu():
    builds, _ = get_manifest()
    for b in builds:
        add_item(b['name'], b.get('description', ''), folder=True,
                 action='build', id=b['id'])
    xbmcplugin.endOfDirectory(HANDLE)


def build_menu(build_id):
    builds, _ = get_manifest()
    b = next((x for x in builds if x['id'] == build_id), None)
    if not b:
        return xbmcplugin.endOfDirectory(HANDLE)
    add_item(
        'Update (keep my settings)',
        'Brings %s up to date: skin, menus, widgets and add-ons.\n\n'
        'Your Kodi settings, sources, favourites and every add-on login and configuration '
        'are kept. Nothing has to be signed in again.' % b['name'],
        action='update', id=build_id,
    )
    add_item(
        'Fresh Install (reset to defaults)',
        'Applies %s clean. Everything resets to that build\'s defaults, including add-on '
        'configuration and saved logins.\n\nUse for a first install, or to put a broken '
        'setup back to a known-good state.' % b['name'],
        action='install', id=build_id,
    )
    xbmcplugin.endOfDirectory(HANDLE)


def layouts_menu():
    _, layouts = get_manifest()
    current = xbmc.getSkinDir()
    for l in layouts:
        active = ' [COLOR limegreen](current)[/COLOR]' if l['skin'] == current else ''
        add_item(l['name'] + active, l.get('description', ''),
                 action='layout', id=l['id'])
    xbmcplugin.endOfDirectory(HANDLE)


def show_info():
    xbmcgui.Dialog().textviewer(
        ADDON_NAME,
        'StarWave — a Kodi 21 "Omega" build.\n\n'
        'INSTALL OR UPDATE A BUILD\n'
        '  Update keeps your Kodi settings, sources, favourites and every add-on setting, '
        'including saved Trakt, Real-Debrid and Premiumize logins. Add-ons you installed '
        'yourself stay installed and enabled.\n'
        '  Fresh Install replaces all of that with the build defaults. No credentials are '
        'included in any build — sign in afterwards via Trakt > Setup.\n\n'
        'SWITCH LAYOUT\n'
        '  Changes only the skin and its menu. Credentials and settings are untouched, '
        'because no skin stores them. Switching back and forth is free and repeatable.\n\n'
        'AFTERWARDS\n'
        '  Kodi closes so it cannot write its old settings back over the new ones. Reopen '
        'Kodi to finish.',
    )


# ----------------------------------------------------------------------------- shared


def _cleanup_temp():
    try:
        if os.path.exists(TEMP_ZIP):
            os.remove(TEMP_ZIP)
    except OSError as exc:
        log('could not remove temp zip: %s' % exc, xbmc.LOGWARNING)


def download(url, dest, dialog, what='the build'):
    """Stream url to dest, driving the progress dialog. Returns False if cancelled."""
    resp = urlopen(Request(url, headers={'User-Agent': 'StarWave-Wizard'}), timeout=30)
    total = resp.getheader('content-length')
    total = int(total) if total and total.isdigit() else 0
    total_mb = total / 1048576.0
    got = 0

    with open(dest, 'wb') as fh:
        while True:
            if dialog.iscanceled():
                return False
            chunk = resp.read(1024 * 256)
            if not chunk:
                break
            fh.write(chunk)
            got += len(chunk)
            if total:
                dialog.update(int(got * 100 / total),
                              'Downloading %s\n%.0f of %.0f MB'
                              % (what, got / 1048576.0, total_mb))
            else:
                dialog.update(0, 'Downloading %s\n%.0f MB' % (what, got / 1048576.0))

    if total and got < total:
        raise IOError('download truncated: got %d of %d bytes' % (got, total))
    return True


def _skip_addon(name, skip_ids):
    return any(name.startswith('addons/%s/' % a) for a in skip_ids)


def _preserved(name, dest):
    """True when update mode must leave this zip member alone."""
    if name == ADDONS_DB_MEMBER:
        return True
    if not os.path.exists(os.path.join(dest, name.replace('/', os.sep))):
        # Nothing on the device to protect — ship the build's copy so the file is at
        # least present (a missing settings.xml would break the add-on).
        return False
    if name in USER_FILES:
        return True
    parts = name.split('/')
    if not (len(parts) > 2 and parts[0] == 'userdata' and parts[1] == 'addon_data'):
        return False
    # userdata/addon_data/<id>/settings.xml — the user's own add-on configuration.
    if len(parts) == 4 and parts[3] == 'settings.xml':
        return True
    # Some add-ons keep settings in a database instead — The Gears holds its debrid logins
    # in addon_data/plugin.video.gears/databases/settings.db. Every .db under addon_data is
    # user state (settings, caches, watched history).
    if parts[-1].endswith('.db'):
        return True
    # Layout menus the user has customised: skinshortcuts writes *.DATA.xml and .properties,
    # skinvariables writes nodes/<skinid>/*.json. Overwriting either would silently discard
    # a rearranged home screen.
    if parts[2] == 'script.skinvariables' and parts[-1].endswith('.json'):
        return True
    if parts[2] == 'script.skinshortcuts' and parts[-1].endswith(('.DATA.xml', '.properties')):
        return True
    return False


def extract(zip_path, dest, dialog, skip_ids=(), preserve=False, only_missing=False):
    """Extract into dest. Returns False if cancelled.

    preserve=True (update mode) skips members carrying user state — see _preserved.
    only_missing=True writes a member only when it is not already on disk, which is how a
    layout's configuration is applied without discarding one the user has customised.
    """
    import zipfile

    with zipfile.ZipFile(zip_path) as zf:
        members = [m for m in zf.infolist() if not _skip_addon(m.filename, skip_ids)]
        if preserve:
            members = [m for m in members if not _preserved(m.filename, dest)]
        if only_missing:
            members = [m for m in members
                       if not os.path.exists(os.path.join(dest, m.filename.replace('/', os.sep)))]
        count = len(members)
        for i, member in enumerate(members):
            if dialog.iscanceled():
                return False
            zf.extract(member, dest)
            if i % 25 == 0 or i == count - 1:
                dialog.update(int(i * 100 / max(count, 1)),
                              'Installing\n%d of %d files' % (i + 1, count))
    return True


def build_addon_ids(zip_path, skip_ids=()):
    """Top-level add-on ids the build zip carries."""
    import zipfile

    ids = set()
    with zipfile.ZipFile(zip_path) as zf:
        for name in zf.namelist():
            parts = name.split('/')
            if len(parts) > 1 and parts[0] == 'addons' and parts[1] and parts[1] != 'packages':
                ids.add(parts[1])
    return sorted(ids - set(skip_ids))


def merge_installed(addon_ids):
    """Register the build's add-ons in the device's own add-on database.

    Update mode keeps the device's Addons33.db so add-ons the user installed themselves stay
    registered. Any build add-on it does not know yet is inserted enabled; the metadata rows
    for every build add-on are dropped so Kodi re-reads each addon.xml at the next start —
    that is what picks up same-version content changes.
    """
    if not addon_ids or not os.path.exists(ADDONS_DB):
        return
    import sqlite3
    now = time.strftime('%Y-%m-%d %H:%M:%S')
    try:
        con = sqlite3.connect(ADDONS_DB)
        for addon_id in addon_ids:
            con.execute(
                'INSERT INTO installed (addonID, enabled, installDate) '
                'SELECT ?, 1, ? WHERE NOT EXISTS '
                '(SELECT 1 FROM installed WHERE addonID = ?)',
                (addon_id, now, addon_id),
            )
            con.execute('DELETE FROM addons WHERE addonID = ?', (addon_id,))
        con.commit()
        con.close()
        log('merged %d build add-ons into the add-on database' % len(addon_ids))
    except Exception as exc:  # noqa: BLE001
        log('could not merge the add-on database: %s' % exc, xbmc.LOGWARNING)


def drop_from_db(addon_ids):
    """Remove add-ons from the add-on database.

    On a platform where their binaries cannot load, leaving those rows in tells Kodi to load
    them anyway.
    """
    if not addon_ids or not os.path.exists(ADDONS_DB):
        return
    import sqlite3
    try:
        con = sqlite3.connect(ADDONS_DB)
        for addon_id in addon_ids:
            for row in list(con.execute('SELECT id FROM addons WHERE addonID = ?', (addon_id,))):
                con.execute('DELETE FROM addonlinkrepo WHERE idAddon = ?', (row[0],))
            for table in ('addons', 'installed', 'update_rules', 'package'):
                con.execute('DELETE FROM %s WHERE addonID = ?' % table, (addon_id,))
        con.commit()
        con.close()
        log('dropped from add-on database: %s' % ', '.join(addon_ids))
    except Exception as exc:  # noqa: BLE001
        log('could not patch the add-on database: %s' % exc, xbmc.LOGWARNING)


def clear_packages():
    """Drop cached add-on packages so Kodi does not reinstall stale versions."""
    if not os.path.isdir(PACKAGES):
        return
    for name in os.listdir(PACKAGES):
        path = os.path.join(PACKAGES, name)
        try:
            if os.path.isfile(path) or os.path.islink(path):
                os.remove(path)
            else:
                shutil.rmtree(path, ignore_errors=True)
        except OSError as exc:
            log('could not clear %s: %s' % (path, exc), xbmc.LOGWARNING)


def set_skin_on_disk(skin_id):
    """Write lookandfeel.skin straight into guisettings.xml.

    Deliberately not done through JSON-RPC. Setting it on a running Kodi swaps the skin
    live, which raises the "Keep this skin?" prompt and, on Android, has been seen to
    background the app until the system reclaims it. Writing the file and hard-exiting is
    deterministic: the change is already on disk, and Kodi comes up on the new skin.
    """
    if not os.path.exists(GUISETTINGS):
        raise IOError('guisettings.xml not found')
    with open(GUISETTINGS, 'r', encoding='utf-8') as fh:
        text = fh.read()
    new, n = re.subn(r'(<setting id="lookandfeel\.skin">)[^<]*(</setting>)',
                     r'\g<1>%s\g<2>' % skin_id, text)
    if not n:
        raise IOError('lookandfeel.skin not present in guisettings.xml')
    with open(GUISETTINGS, 'w', encoding='utf-8') as fh:
        fh.write(new)
    log('skin set to %s in guisettings.xml' % skin_id)


def _finish(message, tail=''):
    xbmcgui.Dialog().ok(
        ADDON_NAME,
        '%s\n\nKodi will now close so it cannot write its old settings back over the new '
        'ones.\n\nReopen Kodi to finish.%s' % (message, tail),
    )
    # Hard exit on purpose. A normal Quit() makes Kodi save its in-memory settings on the
    # way out, which would overwrite the configuration just written.
    log('done, hard-exiting so Kodi cannot rewrite userdata')
    xbmc.executebuiltin('InhibitIdleShutdown(true)')
    os._exit(1)


# ----------------------------------------------------------------------------- builds


def _apply(build, update):
    skip_ids = () if is_android() else ANDROID_ONLY
    dialog = xbmcgui.DialogProgress()
    dialog.create(ADDON_NAME, 'Starting')
    _cleanup_temp()

    try:
        if not download(build['url'], TEMP_ZIP, dialog, build['name']):
            dialog.close()
            _cleanup_temp()
            notify('Cancelled')
            return

        dialog.update(0, 'Installing')
        if not extract(TEMP_ZIP, HOME, dialog, skip_ids, preserve=update):
            dialog.close()
            _cleanup_temp()
            xbmcgui.Dialog().ok(
                ADDON_NAME,
                'Cancelled part-way through installing, so this Kodi is now a mix of the old '
                'setup and the new one.\n\nRun the wizard again and let it finish.',
            )
            return

        dialog.update(100, 'Tidying up')
        if update:
            merge_installed(build_addon_ids(TEMP_ZIP, skip_ids))
        drop_from_db(skip_ids)
        clear_packages()
        _cleanup_temp()
        dialog.close()

    except Exception as exc:  # noqa: BLE001 - surface anything that goes wrong to the user
        dialog.close()
        _cleanup_temp()
        log('apply failed: %s' % exc, xbmc.LOGERROR)
        xbmcgui.Dialog().ok(
            ADDON_NAME,
            'The install did not finish.\n\n%s\n\nYour Kodi has not been fully changed. Check '
            'your connection and try again.' % exc,
        )
        return

    tail = ''
    if skip_ids:
        tail = (
            '\n\nTwo add-ons were skipped because this build carries the Android versions and '
            'they cannot run here: %s. Kodi\'s own copies are untouched. If streams will not '
            'play, install InputStream Adaptive from the Kodi Add-on repository.'
            % ', '.join(skip_ids)
        )
    what = 'updated — your settings and logins were kept' if update else 'installed'
    _finish('%s is %s.' % (build['name'], what), tail)


def do_build(build_id, update):
    builds, _ = get_manifest()
    build = next((b for b in builds if b['id'] == build_id), None)
    if not build:
        return notify('That build is no longer published')

    if update and not os.path.isdir(os.path.join(HOME, 'addons', 'skin.NTVaura')):
        xbmcgui.Dialog().ok(
            ADDON_NAME,
            'No StarWave install was found on this Kodi, so there are no settings to keep.\n\n'
            'Use Fresh Install instead.',
        )
        return

    if update:
        prompt = ('Update brings %s up to the current build. Your Kodi settings, sources, '
                  'favourites and add-on logins are kept.' % build['name'])
        yes = 'Update'
    else:
        prompt = ('Fresh Install replaces your current setup — skin, home menu, widgets, '
                  'settings and the configuration of every add-on %s ships, including saved '
                  'logins.' % build['name'])
        yes = 'Install'

    if xbmcgui.Dialog().yesno(ADDON_NAME, prompt + '\n\nKodi will close when it finishes. '
                              'Continue?', nolabel='Cancel', yeslabel=yes):
        _apply(build, update)


# ----------------------------------------------------------------------------- layouts


def do_layout(layout_id):
    _, layouts = get_manifest()
    layout = next((l for l in layouts if l['id'] == layout_id), None)
    if not layout:
        return notify('That layout is no longer published')

    skin_id = layout['skin']
    if xbmc.getSkinDir() == skin_id:
        return notify('%s is already in use' % layout['name'])

    installed = os.path.isdir(os.path.join(HOME, 'addons', skin_id))
    if not installed:
        ok = xbmcgui.Dialog().yesno(
            ADDON_NAME,
            '%s is not installed yet. It will be downloaded from the StarWave repository '
            'first.\n\nYour settings and logins are not affected either way. Continue?'
            % layout['name'],
            nolabel='Cancel', yeslabel='Install',
        )
        if not ok:
            return
        xbmc.executebuiltin('InstallAddon(%s)' % skin_id, True)
        if not os.path.isdir(os.path.join(HOME, 'addons', skin_id)):
            xbmcgui.Dialog().ok(
                ADDON_NAME,
                'Could not install %s.\n\nCheck that the StarWave repository is installed '
                'and that you are online, then try again.' % layout['name'],
            )
            return

    dialog = xbmcgui.DialogProgress()
    dialog.create(ADDON_NAME, 'Applying %s' % layout['name'])
    cfg_zip = os.path.join(TEMP_DIR, 'starwave-layout.zip')
    try:
        if layout.get('config'):
            # only_missing: a layout the user has already rearranged is theirs, not ours.
            if download(layout['config'], cfg_zip, dialog, '%s settings' % layout['name']):
                extract(cfg_zip, HOME, dialog, only_missing=True)
            try:
                os.remove(cfg_zip)
            except OSError:
                pass
        set_skin_on_disk(skin_id)
        dialog.close()
    except Exception as exc:  # noqa: BLE001
        dialog.close()
        log('layout switch failed: %s' % exc, xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, 'Could not switch layout.\n\n%s' % exc)
        return

    _finish('%s is ready.\n\nYour settings, sources and logins were not touched.'
            % layout['name'])


# ----------------------------------------------------------------------------- router


def router(qs):
    p = dict(parse_qsl(qs.lstrip('?')))
    action = p.get('action')
    if action == 'builds':
        builds_menu()
    elif action == 'build':
        build_menu(p.get('id'))
    elif action == 'layouts':
        layouts_menu()
    elif action == 'layout':
        do_layout(p.get('id'))
    elif action == 'install':
        do_build(p.get('id'), update=False)
    elif action == 'update':
        do_build(p.get('id'), update=True)
    elif action == 'info':
        show_info()
    else:
        menu()


if __name__ == '__main__':
    router(sys.argv[2] if len(sys.argv) > 2 else '')
