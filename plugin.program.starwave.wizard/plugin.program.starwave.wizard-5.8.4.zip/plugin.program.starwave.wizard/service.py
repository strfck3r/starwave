# -*- coding: utf-8 -*-
"""StarWave background service.

Two jobs, both of which exist because the owner should not have to chase updates:

1. FORCE A REPOSITORY CHECK AT EVERY START.
   Kodi keeps a per-repository timer and skips any repo whose timer has not elapsed, so
   restarting Kodi does NOT reliably pick up a new add-on version. That is why a published
   wizard sat unnoticed on a device that had been restarted several times. `UpdateAddonRepos`
   forces the check, so a published update lands on the next launch rather than within 24h.

2. APPLY THE PER-DEVICE FIXES ONCE PER WIZARD VERSION.
   Menu icons, the display/audio tuning and The Gears' scrapers all live in files an Update
   deliberately preserves, so they cannot travel in the payload. Running them here means a
   device fixes itself with no build download and nobody pressing anything.

   Gated on a marker holding the wizard version they last ran for, so this is not redone at
   every boot and does not fight an owner who deliberately changed one of these back.

Deliberately quiet: no modal dialog is ever opened. The skin can strand itself on
"Initialising Skin..." if a modal is up about a second after boot, so the service waits for
Kodi to settle first and only ever posts a notification.
"""

import os
import json

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon('plugin.program.starwave.wizard')
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
VERSION = ADDON.getAddonInfo('version')

PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
MARKER = os.path.join(PROFILE, 'autofix.json')

# Let Kodi finish starting before touching anything. The startup skin race is real and the
# cost of waiting is nothing - none of this is time critical.
SETTLE_SECONDS = 45

SKIN_UPDATED = []


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[%s.service] %s' % (ADDON_ID, msg), level)


def _repo_installed():
    """True when repository.starwave is present and enabled - i.e. this device has an update
    source. Installing the wizard straight from its zip skips the repository entirely."""
    try:
        xbmcaddon.Addon('repository.starwave')
        return True
    except Exception:  # noqa: BLE001 - Addon() raises for an id that is not installed
        return False


def _already_done():
    try:
        with open(MARKER, 'r', encoding='utf-8') as fh:
            return json.load(fh).get('version')
    except Exception:  # noqa: BLE001 - absent or unreadable both mean "not done"
        return None


def _mark(applied, pending_menu=False):
    try:
        if not os.path.isdir(PROFILE):
            os.makedirs(PROFILE)
        with open(MARKER, 'w', encoding='utf-8') as fh:
            json.dump({'version': VERSION, 'applied': applied,
                       'menu_rebuild_pending': bool(pending_menu)}, fh, indent=2)
    except Exception as exc:  # noqa: BLE001
        log('could not write the marker: %s' % exc, xbmc.LOGWARNING)


def _menu_pending():
    try:
        with open(MARKER, 'r', encoding='utf-8') as fh:
            return bool(json.load(fh).get('menu_rebuild_pending'))
    except Exception:  # noqa: BLE001
        return False


def _clear_pending():
    try:
        with open(MARKER, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        data['menu_rebuild_pending'] = False
        with open(MARKER, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, indent=2)
    except Exception:  # noqa: BLE001
        pass


def set_window_properties():
    """Set Window(10000) properties for Home skin rules: StarWave.BuildVersion and StarWave.WizardVersion."""
    try:
        import xbmcgui
        import default as wizard
        win = xbmcgui.Window(10000)
        b_ver = wizard.get_build_version()
        w_ver = wizard.get_wizard_version()
        win.setProperty('StarWave.BuildVersion', b_ver)
        win.setProperty('StarWave.WizardVersion', w_ver)
        log('set window properties: StarWave.BuildVersion=%s, StarWave.WizardVersion=%s' % (b_ver, w_ver))
    except Exception as exc:  # noqa: BLE001
        log('could not set window properties: %s' % exc, xbmc.LOGWARNING)


def run():
    # 0. Always set Home window properties for version rules at startup
    set_window_properties()

    monitor = xbmc.Monitor()
    if monitor.waitForAbort(SETTLE_SECONDS):
        return

    # 1. Always force the repository check - this is the whole point of running at startup.
    log('forcing a repository check')
    xbmc.executebuiltin('UpdateAddonRepos')

    # A device can end up with the wizard but NOT the repository, because the repo's datadir is
    # the site root, so every add-on folder is browsable in "Install from zip" and any of them
    # can be installed directly. That works, and then nothing ever updates again - there is no
    # repository offering newer versions. Silent, and exactly the failure this service exists to
    # prevent, so say it out loud once.
    # A skin whose record disagrees with the files on disk will never update itself, silently.
    try:
        import default as _w
        fixed = _w.ensure_skin_current()
        if fixed:
            log(fixed)
            SKIN_UPDATED.append(fixed)
        af_fixed = _w.ensure_arctic_fuse_settings()
        if af_fixed:
            log(af_fixed)
            SKIN_UPDATED.append(af_fixed)
    except Exception as exc:  # noqa: BLE001 - never break startup over this
        log('skin repair check failed: %s' % exc, xbmc.LOGWARNING)

    try:
        import default as _w
        lines = _w.ensure_addons_current()
        for line in (lines or []):
            log(line)
    except Exception as exc:  # noqa: BLE001 - never break startup over this
        log('add-on self-update check failed: %s' % exc, xbmc.LOGWARNING)

    # The live-stream stack is an invariant, not a one-shot. It is re-asserted here on EVERY
    # start rather than in the once-per-version section below, because ffmpegdirect was found
    # enabled again on the Deck a week after the fix was applied and nothing noticed. Logged at
    # WARNING on purpose: ensure_live_stack returns nothing when all is well, so any line here
    # means a regression was just repaired and it has to be findable in the log.
    try:
        import default as _w
        live_lines = _w.ensure_live_stack()
        for line in (live_lines or []):
            log(line, xbmc.LOGWARNING)
    except Exception as exc:   # noqa: BLE001 - never break startup over this
        log('live stack check failed: %s' % exc, xbmc.LOGWARNING)

    # GUIDE FRESHNESS IS A BOOT INVARIANT, NOT A ONE-SHOT.
    #
    # The force-merge used to live only inside ensure_iptv_guide(), which is called from section
    # 2 below - so it fired once per wizard RELEASE rather than once per boot. A device sat on an
    # 8h-old merge through a cold boot and two Kodi launches, logging `per-device fixes already
    # applied for 5.7.7` each time, against a guide whose Samsung two thirds live ~4.6h. The
    # version gate stays exactly as it is; freshness simply does not belong behind it.
    #
    # This is NOT a force-merge on every start: ensure_guide_fresh only triggers when the merged
    # epg.xml is actually older than the budget, so a quick restart merges nothing.
    try:
        import default as _w
        guide_lines = _w.ensure_guide_fresh()
        for line in (guide_lines or []):
            log(line)
    except Exception as exc:  # noqa: BLE001 - never break startup over this
        log('guide freshness check failed: %s' % exc, xbmc.LOGWARNING)

    # Sports Hub widget path is a boot invariant, not a one-shot.
    try:
        import default as _w
        sports_lines = _w.ensure_canonical_sports()
        for line in (sports_lines or []):
            log(line, xbmc.LOGWARNING)
    except Exception as exc:  # noqa: BLE001 - never break startup over this
        log('sports hub check failed: %s' % exc, xbmc.LOGWARNING)

    # TMDb Helper sync patch is a boot invariant to guarantee no in-progress widget crashes
    try:
        import default as _w
        tmdb_lines = _w.ensure_tmdbhelper_sync_patch()
        for line in (tmdb_lines or []):
            log(line)
    except Exception as exc:  # noqa: BLE001 - never break startup over this
        log('tmdbhelper sync patch check failed: %s' % exc, xbmc.LOGWARNING)

    # TMDb Helper database health check is a boot invariant to prevent corrupt SQLite blocking syncs
    try:
        import default as _w
        db_lines = _w.ensure_tmdbhelper_db_health()
        for line in (db_lines or []):
            log(line, xbmc.LOGWARNING)
    except Exception as exc:  # noqa: BLE001 - never break startup over this
        log('tmdbhelper db health check failed: %s' % exc, xbmc.LOGWARNING)

    # SlyGuy proxy SO_REUSEADDR and dynamic port recovery is a boot invariant
    try:
        import default as _w
        sly_proxy_lines = _w.ensure_slyguy_proxy()
        for line in (sly_proxy_lines or []):
            log(line)
    except Exception as exc:  # noqa: BLE001 - never break startup over this
        log('slyguy proxy check failed: %s' % exc, xbmc.LOGWARNING)

    # Trailer resolution engine and YouTube stream redirect is a boot invariant
    try:
        import default as _w
        trailer_lines = _w.ensure_trailer_resolution()
        for line in (trailer_lines or []):
            log(line)
    except Exception as exc:  # noqa: BLE001 - never break startup over this
        log('trailer resolution check failed: %s' % exc, xbmc.LOGWARNING)

    # Diagnostic error report is generated/refreshed at boot
    try:
        import default as _w
        _w.generate_error_report()
    except Exception as exc:  # noqa: BLE001 - never break startup over this
        log('diagnostic error report check failed: %s' % exc, xbmc.LOGWARNING)

    # Arctic Fuse 3 update lock and self-healing XML hooks are boot invariants
    try:
        import default as _w
        af_lock_lines = _w.ensure_arctic_fuse_update_lock()
        for line in (af_lock_lines or []):
            log(line)
        af_patch_lines = _w.ensure_arctic_fuse_patches()
        for line in (af_patch_lines or []):
            log(line)
    except Exception as exc:  # noqa: BLE001 - never break startup over this
        log('arctic fuse boot invariants failed: %s' % exc, xbmc.LOGWARNING)

    if not _repo_installed():
        log('repository.starwave is NOT installed - this device cannot receive updates',
            xbmc.LOGWARNING)
        import xbmcgui
        xbmcgui.Dialog().notification(
            ADDON_NAME, 'StarWave Repository missing - updates are off',
            ADDON.getAddonInfo('icon'), 9000)

    last_version = _already_done()
    if last_version and last_version != VERSION:
        import xbmcgui
        xbmcgui.Dialog().notification(
            ADDON_NAME, 'Updated to v%s!' % VERSION,
            ADDON.getAddonInfo('icon'), 6000)

    # 2. The per-device fixes, once per wizard version.
    if last_version == VERSION and not _menu_pending():
        log('per-device fixes already applied for %s' % VERSION)
        return

    try:
        import default as wizard
    except Exception as exc:  # noqa: BLE001
        log('could not load the wizard: %s' % exc, xbmc.LOGERROR)
        return

    applied = []
    menu = []
    sly_ok = True
    try:
        # Writing the .DATA.xml / .properties is safe at runtime: nothing reads them while Kodi
        # runs, only skinshortcuts during a rebuild.
        menu = wizard.sync_menu_icons()
        applied += [l for l in menu if not l.startswith('[COLOR red]')]
        applied += [l for l in wizard.tune_this_device(on_disk=False) if not l.startswith('[COLOR red]')]
        applied += [l for l in wizard.fix_gears_scrapers() if not l.startswith('[COLOR red]')]
        sly_lines, sly_ok = wizard.ensure_slyguy()
        applied += [l for l in sly_lines if not l.startswith('[COLOR red]')]
        guide_lines = wizard.ensure_iptv_guide()
        applied += [l for l in guide_lines if not l.startswith('[COLOR red]')]
    except Exception as exc:  # noqa: BLE001 - a failed autofix must never break Kodi startup
        log('autofix failed: %s' % exc, xbmc.LOGERROR)
        return

    applied += SKIN_UPDATED
    if sly_ok:
        _mark(applied, pending_menu=bool(menu) or bool(SKIN_UPDATED))
    else:
        log('ensure_slyguy did not complete successfully; pass will retry on next start',
            xbmc.LOGWARNING)

    if applied:
        log('applied: %s' % ' | '.join(applied))
        import xbmcgui
        xbmcgui.Dialog().notification(
            ADDON_NAME,
            'Applied %d fix%s for this device' % (len(applied), '' if len(applied) == 1 else 'es'),
            ADDON.getAddonInfo('icon'), 6000)
        if menu:
            xbmcgui.Dialog().notification(
                ADDON_NAME, 'New menu icons apply next time Kodi starts',
                ADDON.getAddonInfo('icon'), 8000)
    else:
        log('nothing needed fixing for %s' % VERSION)

    # THE MENU REBUILD IS DEFERRED TO SHUTDOWN, ON PURPOSE.
    #
    # force_menu_rebuild() deletes the skin's generated script-skinshortcuts-includes.xml, which
    # is the file the RUNNING skin draws its menu from. Doing that mid-session pulls the rug from
    # under a live skin, and this skin is already known to strand itself on "Initialising Skin..."
    # Waiting for abort costs nothing - a Kodi service is expected to live until shutdown - and
    # at that point nothing is drawing the menu, so the next start regenerates cleanly.
    #
    # If Kodi is force-killed the hook never runs, the pending flag survives, and the next
    # shutdown picks it up. That is why the flag is on disk rather than in memory.
    monitor.waitForAbort()
    if _menu_pending():
        try:
            wizard.force_menu_rebuild()
            wizard.force_arctic_fuse_rebuild()
            _clear_pending()
            log('menu rebuild armed at shutdown; it regenerates on the next start')
        except Exception as exc:  # noqa: BLE001
            log('could not arm the menu rebuild: %s' % exc, xbmc.LOGWARNING)


if __name__ == '__main__':
    run()
