# -*- coding: utf-8 -*-
"""StarWave Wizard - Account authentication and fan-out engine.

Enables 'Sign In Once' across Real-Debrid, Premiumize, AllDebrid, and Trakt.
Authenticates once via OAuth device-code flows and fans out credentials to all
installed add-ons (Umbrella, Seren, The Crew/ResolveURL, The Gears, Otaku, TMDb Helper).
"""

import os
import sys
import json
import time
import sqlite3
import urllib.request
import urllib.parse
import urllib.error

# Ensure resources/lib is in path for vendored pyqrcode
_lib_dir = os.path.dirname(os.path.abspath(__file__))
if _lib_dir not in sys.path:
    sys.path.insert(0, _lib_dir)

try:
    import pyqrcode
    PYQRCODE_AVAILABLE = True
except Exception:
    PYQRCODE_AVAILABLE = False

try:
    import xbmc
    import xbmcgui
    import xbmcaddon
    import xbmcvfs
    KODI_AVAILABLE = True
except ImportError:
    KODI_AVAILABLE = False


# Universal Trakt App Client ID compatible with TMDb Helper, Seren, Umbrella, and The Crew
STARWAVE_TRAKT_CLIENT_ID = 'e6fde6173adf3c6af8fd1b0694b9b84d7c519cefc24482310e1de06c6abe5467'
STARWAVE_TRAKT_CLIENT_SECRET = '15119384341d9a61c751d8d515acbc0dd801001d4ebe85d3eef9885df80ee4d9'
# Trakt scope asked for in the device-code flow. 'offline_access' is what makes a token
# refreshable for the long term; a 'public'-only token stops working after about a week, which
# is why a wizard-authorized device silently lost Trakt sync while a TMDb-Helper-authorized one
# did not. Trakt's documented device endpoint takes only client_id and ignores unknown
# parameters, so asking is free - the granted scope is checked after the exchange either way.
STARWAVE_TRAKT_SCOPE = 'public offline_access'

# Standard Debrid App IDs
RD_APP_ID = 'X245A4XAIBGVM'
PM_CLIENT_ID = '149408327'
AD_AGENT = 'StarWave'

ALL_FANOUT_TARGETS = [
    'Umbrella',
    'Seren',
    'ResolveURL (The Crew)',
    'The Gears',
    'Otaku',
    'TMDb Helper',
]


def _get_home():
    if KODI_AVAILABLE:
        return xbmcvfs.translatePath('special://home/')
    return os.environ.get('KODI_HOME', '/tmp/fakehome')


def _log(msg, level=None):
    if KODI_AVAILABLE:
        if level is None:
            level = xbmc.LOGINFO
        xbmc.log(f'[StarWave AccountFanout] {msg}', level)
    else:
        print(f'[StarWave AccountFanout] {msg}')


def _safe_set_addon_setting(addon_id, key, value, home_dir=None):
    """Set setting via xbmcaddon if Kodi is live AND persist directly to settings.xml on disk."""
    val_str = str(value)
    if KODI_AVAILABLE:
        try:
            addon = xbmcaddon.Addon(addon_id)
            addon.setSetting(key, val_str)
        except Exception:
            pass

    # File-level persistence fallback (or offline mode)
    if home_dir is None:
        home_dir = _get_home()
    settings_xml = os.path.join(home_dir, 'userdata', 'addon_data', addon_id, 'settings.xml')
    try:
        _update_settings_xml(settings_xml, key, val_str)
        return True
    except Exception as exc:
        _log(f'Failed updating {settings_xml} for {key}: {exc}')
    return False


def _clean_val(val, default=''):
    if not val:
        return default
    val_str = str(val).strip()
    if val_str.lower() in ('empty_setting', 'none', 'false', '0', 'default', 'null', '""', "''"):
        return default
    return val_str


def _safe_get_addon_setting(addon_id, key, default='', home_dir=None):
    if KODI_AVAILABLE:
        try:
            val = xbmcaddon.Addon(addon_id).getSetting(key)
            cleaned = _clean_val(val)
            if cleaned:
                return cleaned
        except Exception:
            pass

    if home_dir is None:
        home_dir = _get_home()
    settings_xml = os.path.join(home_dir, 'userdata', 'addon_data', addon_id, 'settings.xml')
    if os.path.exists(settings_xml):
        val = _read_setting_xml(settings_xml, key, default)
        return _clean_val(val, default)
    return default


def _update_settings_xml(filepath, key, value):
    """Update or insert a setting in Kodi settings.xml format."""
    import xml.etree.ElementTree as ET
    if os.path.exists(filepath) and os.path.getsize(filepath) > 0:
        try:
            tree = ET.parse(filepath)
            root = tree.getroot()
        except Exception as exc:
            _log(f'Settings file {filepath} is not valid XML: {exc}')
            return
    else:
        if not value:
            return
        root = ET.Element('settings')
        tree = ET.ElementTree(root)

    found = False
    for setting in root.findall('setting'):
        if setting.get('id') == key:
            found = True
            if setting.text is not None or setting.get('value') is None:
                setting.text = value
                if 'default' in setting.attrib:
                    setting.attrib['default'] = 'false'
            else:
                setting.set('value', value)
            break

    if not found:
        if not value:
            return
        is_v2 = root.get('version') == '2' or any(s.text for s in root.findall('setting'))
        new_elem = ET.SubElement(root, 'setting', {'id': key})
        if is_v2 or root.get('version') == '2':
            new_elem.text = value
            new_elem.set('default', 'false')
        else:
            new_elem.set('value', value)

    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    tree.write(filepath, encoding='utf-8', xml_declaration=True)


def _read_setting_xml(filepath, key, default=''):
    import xml.etree.ElementTree as ET
    try:
        tree = ET.parse(filepath)
        root = tree.getroot()
        for setting in root.findall('setting'):
            if setting.get('id') == key:
                if setting.text:
                    return setting.text.strip()
                if setting.get('value'):
                    return setting.get('value').strip()
    except Exception:
        pass
    return default


def _update_gears_db(key, value, setting_type='string', home_dir=None):
    """Update The Gears settings in userdata/addon_data/plugin.video.gears/databases/settings.db."""
    if home_dir is None:
        home_dir = _get_home()
    gears_db = os.path.join(home_dir, 'userdata', 'addon_data', 'plugin.video.gears', 'databases', 'settings.db')
    os.makedirs(os.path.dirname(gears_db), exist_ok=True)
    try:
        conn = sqlite3.connect(gears_db)
        cursor = conn.cursor()
        cursor.execute(
            'CREATE TABLE IF NOT EXISTS settings '
            '(setting_id text not null unique, setting_type text, setting_default text, setting_value text)'
        )
        default_val = 'false' if setting_type == 'boolean' else ''
        cursor.execute(
            'INSERT OR REPLACE INTO settings (setting_id, setting_type, setting_default, setting_value) '
            'VALUES (?, ?, ?, ?)',
            (key, setting_type, default_val, str(value))
        )
        conn.commit()
        conn.close()

        # Update in-memory property if running inside Kodi
        if KODI_AVAILABLE:
            try:
                xbmcgui.Window(10000).setProperty(f'gears.{key}', str(value))
            except Exception:
                pass
        return True
    except Exception as exc:
        _log(f'Failed updating Gears db for {key}: {exc}')
        return False


def _read_gears_db(key, default='', home_dir=None):
    if home_dir is None:
        home_dir = _get_home()
    gears_db = os.path.join(home_dir, 'userdata', 'addon_data', 'plugin.video.gears', 'databases', 'settings.db')
    if not os.path.exists(gears_db):
        return default
    try:
        conn = sqlite3.connect(gears_db)
        cursor = conn.cursor()
        cursor.execute('SELECT setting_value FROM settings WHERE setting_id = ?', (key,))
        row = cursor.fetchone()
        conn.close()
        val = row[0] if row and row[0] is not None else default
        return _clean_val(val, default)
    except Exception:
        return default


# -----------------------------------------------------------------------------
# Target Selection Configuration
# -----------------------------------------------------------------------------

def get_enabled_targets(home_dir=None):
    """Retrieve list of enabled target add-ons for credential fan-out.
    Defaults to empty (unchecked) so the user explicitly opts in.
    """
    raw = _safe_get_addon_setting('plugin.program.starwave.wizard', 'fanout_targets', '', home_dir)
    if not raw or raw == '__NONE__':
        return []
    targets = [t.strip() for t in raw.split(',') if t.strip() in ALL_FANOUT_TARGETS]
    return targets


def set_enabled_targets(targets, home_dir=None):
    """Persist list of enabled target add-ons for credential fan-out."""
    val = ','.join(targets) if targets else '__NONE__'
    _safe_set_addon_setting('plugin.program.starwave.wizard', 'fanout_targets', val, home_dir)


def get_targets_summary(home_dir=None):
    """Return a comma-separated summary of enabled targets or fallback description."""
    targets = get_enabled_targets(home_dir)
    return ', '.join(targets) if targets else 'None selected'


def select_fanout_targets_dialog():
    """Interactive multi-select dialog for choosing fan-out add-on destinations."""
    if not KODI_AVAILABLE:
        return []
    current = get_enabled_targets()
    preselect = [i for i, t in enumerate(ALL_FANOUT_TARGETS) if t in current]
    chosen_indices = xbmcgui.Dialog().multiselect('Select Fan-Out Target Add-ons', ALL_FANOUT_TARGETS, preselect=preselect)
    if chosen_indices is None:
        return current
    selected = [ALL_FANOUT_TARGETS[i] for i in chosen_indices]
    set_enabled_targets(selected)
    msg = 'Fan-out targets updated:\n• ' + '\n• '.join(selected) if selected else 'No target add-ons selected.'
    xbmcgui.Dialog().ok('StarWave Wizard', msg)
    return selected


# -----------------------------------------------------------------------------
# QR Code Generator & UI Dialog
# -----------------------------------------------------------------------------

def make_qr_file(url, out_path=None, tag='auth'):
    """Generate a clean QR code PNG file for a given URL with unique tag to prevent texture caching."""
    if not PYQRCODE_AVAILABLE:
        return ''
    try:
        if not out_path:
            home = _get_home()
            out_dir = os.path.join(home, 'userdata', 'addon_data', 'plugin.program.starwave.wizard')
            os.makedirs(out_dir, exist_ok=True)
            try:
                for fname in os.listdir(out_dir):
                    if fname.startswith('qr_') and fname.endswith('.png'):
                        try:
                            os.remove(os.path.join(out_dir, fname))
                        except Exception:
                            pass
            except Exception:
                pass
            out_path = os.path.join(out_dir, f'qr_{tag}_{int(time.time() * 1000)}.png')
        qr = pyqrcode.create(url)
        qr.png(out_path, scale=6)
        return out_path
    except Exception as exc:
        _log(f'QR generation error: {exc}')
        return ''


class QRCodeProgressDialog(object):
    """Progress dialog with integrated QR code display and fallback support."""

    def __init__(self, heading, line1='', line2='', line3='', image=''):
        self.heading = heading
        self.line1 = line1
        self.line2 = line2
        self.line3 = line3
        self.image = image
        self.xml_dialog = None
        self.fallback_dialog = None
        self.cancelled = False

        if KODI_AVAILABLE and hasattr(xbmcgui, 'WindowXMLDialog'):
            try:
                addon = xbmcaddon.Addon('plugin.program.starwave.wizard')
                addon_path = addon.getAddonInfo('path')
                xml_file = 'AuthProgress.xml'
                self.xml_dialog = _WindowXMLDialogAuth(xml_file, addon_path, 'Default', '720p')
                self.xml_dialog.set_parent(self)
                self.xml_dialog.set_initial_data(heading, line1, line2, line3, image)
                self.xml_dialog.show()
                self.xml_dialog.update_ui(100, line1, line2, line3, image)
            except Exception as exc:
                _log(f'WindowXMLDialog failed ({exc}); using DialogProgress fallback')
                self.xml_dialog = None
                if hasattr(xbmcgui, 'DialogProgress'):
                    try:
                        self.fallback_dialog = xbmcgui.DialogProgress()
                        self.fallback_dialog.create(heading, f'{line1}\n{line2}\n{line3}')
                    except Exception:
                        self.fallback_dialog = None
        elif KODI_AVAILABLE and hasattr(xbmcgui, 'DialogProgress'):
            try:
                self.fallback_dialog = xbmcgui.DialogProgress()
                self.fallback_dialog.create(heading, f'{line1}\n{line2}\n{line3}')
            except Exception:
                self.fallback_dialog = None

    def update(self, percent, line1='', line2='', line3='', image=''):
        if line1: self.line1 = line1
        if line2: self.line2 = line2
        if line3: self.line3 = line3
        if image: self.image = image

        if self.xml_dialog:
            self.xml_dialog.update_ui(percent, self.line1, self.line2, self.line3, self.image)
        elif self.fallback_dialog:
            try:
                msg = f'{self.line1}\n{self.line2}\n{self.line3}'
                self.fallback_dialog.update(int(percent), msg)
            except Exception:
                pass

    def iscanceled(self):
        if self.cancelled:
            return True
        if self.xml_dialog:
            return self.xml_dialog.cancel
        if self.fallback_dialog:
            try:
                return bool(self.fallback_dialog.iscanceled())
            except Exception:
                return False
        return False

    def close(self):
        if self.xml_dialog:
            try:
                self.xml_dialog.close()
            except Exception:
                pass
            self.xml_dialog = None
        if self.fallback_dialog:
            try:
                self.fallback_dialog.close()
            except Exception:
                pass
            self.fallback_dialog = None


if KODI_AVAILABLE and hasattr(xbmcgui, 'WindowXMLDialog'):
    class _WindowXMLDialogAuth(xbmcgui.WindowXMLDialog):
        HEADING_CTRL = 100
        LINE1_CTRL = 10
        LINE2_CTRL = 11
        LINE3_CTRL = 12
        QRIMAGE_CTRL = 13
        PROGRESS_CTRL = 20
        CANCEL_BUTTON = 200

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.cancel = False
            self._parent = None
            self._heading = ''
            self._line1 = ''
            self._line2 = ''
            self._line3 = ''
            self._image = ''
            self._percent = 100
            self._ready = False

        def set_parent(self, parent):
            self._parent = parent

        def set_initial_data(self, heading, line1, line2, line3, image):
            self._heading = heading
            self._line1 = line1
            self._line2 = line2
            self._line3 = line3
            self._image = image

        def onInit(self):
            try:
                self.setFocusId(self.CANCEL_BUTTON)
            except Exception:
                pass
            self._render()

        def _render(self):
            try:
                if self._heading:
                    self.getControl(self.HEADING_CTRL).setLabel(self._heading)
            except Exception:
                pass
            try:
                if self._line1:
                    self.getControl(self.LINE1_CTRL).setLabel(self._line1)
            except Exception:
                pass
            try:
                if self._line2:
                    self.getControl(self.LINE2_CTRL).setLabel(self._line2)
            except Exception:
                pass
            try:
                if self._line3:
                    self.getControl(self.LINE3_CTRL).setLabel(self._line3)
            except Exception:
                pass
            try:
                if self._image:
                    self.getControl(self.QRIMAGE_CTRL).setImage(self._image, False)
            except Exception:
                pass
            try:
                self.getControl(self.PROGRESS_CTRL).setPercent(int(self._percent))
            except Exception:
                pass

        def update_ui(self, percent, line1='', line2='', line3='', image=''):
            self._percent = percent
            if line1: self._line1 = line1
            if line2: self._line2 = line2
            if line3: self._line3 = line3
            if image: self._image = image
            self._render()

        def onAction(self, action):
            action_id = action.getId()
            # 9=ParentDir, 10=PreviousMenu, 13=Stop, 92=NavBack, 110=Back, 216=ESC, 247=Back
            # 1=Enter/OK, 7=Select, 100=MouseClick
            if action_id in (1, 7, 9, 10, 13, 92, 100, 110, 216, 247):
                self.cancel = True
                if self._parent: self._parent.cancelled = True
                self.close()

        def onClick(self, controlId):
            self.cancel = True
            if self._parent: self._parent.cancelled = True
            self.close()
else:
    class _WindowXMLDialogAuth(object):
        pass


def _wait_dialog(dialog, seconds):
    """Wait for specified seconds while checking dialog cancellation every 100ms."""
    steps = max(1, int(seconds * 10))
    for _ in range(steps):
        if dialog and dialog.iscanceled():
            return True
        if KODI_AVAILABLE and hasattr(xbmc, 'sleep'):
            xbmc.sleep(100)
        else:
            time.sleep(0.1)
    return dialog.iscanceled() if dialog else False


# -----------------------------------------------------------------------------
# Fan-out Core Functions
# -----------------------------------------------------------------------------

def fanout_realdebrid(token, refresh='', client_id='', secret='', username='', home_dir=None):
    """Fan out Real-Debrid credentials to enabled target add-ons."""
    updated = []
    if not token:
        return updated
    targets = get_enabled_targets(home_dir)

    # 1. Umbrella
    if 'Umbrella' in targets and _safe_set_addon_setting('plugin.video.umbrella', 'realdebridtoken', token, home_dir):
        _safe_set_addon_setting('plugin.video.umbrella', 'realdebridrefresh', refresh, home_dir)
        _safe_set_addon_setting('plugin.video.umbrella', 'realdebrid.clientid', client_id, home_dir)
        _safe_set_addon_setting('plugin.video.umbrella', 'realdebridsecret', secret, home_dir)
        if username:
            _safe_set_addon_setting('plugin.video.umbrella', 'realdebridusername', username, home_dir)
        updated.append('Umbrella')

    # 2. Seren
    if 'Seren' in targets and _safe_set_addon_setting('plugin.video.seren', 'rd.auth', token, home_dir):
        _safe_set_addon_setting('plugin.video.seren', 'rd.refresh', refresh, home_dir)
        _safe_set_addon_setting('plugin.video.seren', 'rd.client_id', client_id, home_dir)
        _safe_set_addon_setting('plugin.video.seren', 'rd.secret', secret, home_dir)
        _safe_set_addon_setting('plugin.video.seren', 'rd.enabled', 'true', home_dir)
        if username:
            _safe_set_addon_setting('plugin.video.seren', 'rd.username', username, home_dir)
        updated.append('Seren')

    # 3. ResolveURL (for The Crew and common scrapers)
    if 'ResolveURL (The Crew)' in targets and _safe_set_addon_setting('script.module.resolveurl', 'RealDebridResolver_token', token, home_dir):
        _safe_set_addon_setting('script.module.resolveurl', 'RealDebridResolver_enabled', 'true', home_dir)
        _safe_set_addon_setting('script.module.resolveurl', 'RealDebridResolver_refresh', refresh, home_dir)
        _safe_set_addon_setting('script.module.resolveurl', 'RealDebridResolver_client_id', client_id, home_dir)
        _safe_set_addon_setting('script.module.resolveurl', 'RealDebridResolver_client_secret', secret, home_dir)
        if username:
            _safe_set_addon_setting('script.module.resolveurl', 'RealDebridResolver_user', username, home_dir)
        updated.append('ResolveURL (The Crew)')

    # 4. The Gears
    if 'The Gears' in targets and _update_gears_db('rd.token', token, 'string', home_dir):
        _update_gears_db('rd.enabled', 'true', 'boolean', home_dir)
        _update_gears_db('rd.refresh', refresh, 'string', home_dir)
        _update_gears_db('rd.client_id', client_id, 'string', home_dir)
        _update_gears_db('rd.secret', secret, 'string', home_dir)
        if username:
            _update_gears_db('rd.account_id', username, 'string', home_dir)
        updated.append('The Gears')

    # 5. Otaku
    if 'Otaku' in targets and _safe_set_addon_setting('plugin.video.otaku.testing', 'realdebrid.token', token, home_dir):
        _safe_set_addon_setting('plugin.video.otaku.testing', 'realdebrid.refresh', refresh, home_dir)
        _safe_set_addon_setting('plugin.video.otaku.testing', 'realdebrid.client_id', client_id, home_dir)
        _safe_set_addon_setting('plugin.video.otaku.testing', 'realdebrid.secret', secret, home_dir)
        if username:
            _safe_set_addon_setting('plugin.video.otaku.testing', 'realdebrid.username', username, home_dir)
        updated.append('Otaku')

    return updated


def fanout_premiumize(token, username='', home_dir=None):
    """Fan out Premiumize credentials to enabled target add-ons."""
    updated = []
    if not token:
        return updated
    targets = get_enabled_targets(home_dir)

    # 1. Umbrella
    if 'Umbrella' in targets and _safe_set_addon_setting('plugin.video.umbrella', 'premiumizetoken', token, home_dir):
        if username:
            _safe_set_addon_setting('plugin.video.umbrella', 'premiumize.username', username, home_dir)
        updated.append('Umbrella')

    # 2. Seren
    if 'Seren' in targets and _safe_set_addon_setting('plugin.video.seren', 'premiumize.token', token, home_dir):
        _safe_set_addon_setting('plugin.video.seren', 'premiumize.enabled', 'true', home_dir)
        _safe_set_addon_setting('plugin.video.seren', 'premiumize.status', 'Premium', home_dir)
        if username:
            _safe_set_addon_setting('plugin.video.seren', 'premiumize.username', username, home_dir)
        updated.append('Seren')

    # 3. ResolveURL
    if 'ResolveURL (The Crew)' in targets and _safe_set_addon_setting('script.module.resolveurl', 'PremiumizeMeResolver_token', token, home_dir):
        _safe_set_addon_setting('script.module.resolveurl', 'PremiumizeMeResolver_enabled', 'true', home_dir)
        updated.append('ResolveURL (The Crew)')

    # 4. The Gears
    if 'The Gears' in targets and _update_gears_db('pm.token', token, 'string', home_dir):
        _update_gears_db('pm.enabled', 'true', 'boolean', home_dir)
        if username:
            _update_gears_db('pm.account_id', username, 'string', home_dir)
        updated.append('The Gears')

    # 5. Otaku
    if 'Otaku' in targets and _safe_set_addon_setting('plugin.video.otaku.testing', 'premiumize.token', token, home_dir):
        if username:
            _safe_set_addon_setting('plugin.video.otaku.testing', 'premiumize.username', username, home_dir)
        updated.append('Otaku')

    return updated


def fanout_alldebrid(token, username='', home_dir=None):
    """Fan out AllDebrid credentials to enabled target add-ons."""
    updated = []
    if not token:
        return updated
    targets = get_enabled_targets(home_dir)

    # 1. Umbrella
    if 'Umbrella' in targets and _safe_set_addon_setting('plugin.video.umbrella', 'alldebridtoken', token, home_dir):
        if username:
            _safe_set_addon_setting('plugin.video.umbrella', 'alldebridusername', username, home_dir)
        updated.append('Umbrella')

    # 2. Seren
    if 'Seren' in targets and _safe_set_addon_setting('plugin.video.seren', 'alldebrid.token', token, home_dir):
        _safe_set_addon_setting('plugin.video.seren', 'alldebrid.enabled', 'true', home_dir)
        if username:
            _safe_set_addon_setting('plugin.video.seren', 'alldebrid.username', username, home_dir)
        updated.append('Seren')

    # 3. ResolveURL
    if 'ResolveURL (The Crew)' in targets and _safe_set_addon_setting('script.module.resolveurl', 'AllDebridResolver_token', token, home_dir):
        _safe_set_addon_setting('script.module.resolveurl', 'AllDebridResolver_enabled', 'true', home_dir)
        updated.append('ResolveURL (The Crew)')

    # 4. The Gears
    if 'The Gears' in targets and _update_gears_db('ad.token', token, 'string', home_dir):
        _update_gears_db('ad.enabled', 'true', 'boolean', home_dir)
        if username:
            _update_gears_db('ad.account_id', username, 'string', home_dir)
        updated.append('The Gears')

    # 5. Otaku
    if 'Otaku' in targets and _safe_set_addon_setting('plugin.video.otaku.testing', 'alldebrid.token', token, home_dir):
        if username:
            _safe_set_addon_setting('plugin.video.otaku.testing', 'alldebrid.username', username, home_dir)
        updated.append('Otaku')

    return updated


def fanout_trakt(token, refresh='', expires_at=0, client_id=None, secret=None, username='', home_dir=None):
    """Fan out Trakt credentials to enabled target add-ons."""
    updated = []
    if not token:
        return updated
    targets = get_enabled_targets(home_dir)

    if client_id is None:
        client_id = STARWAVE_TRAKT_CLIENT_ID
    if secret is None:
        secret = STARWAVE_TRAKT_CLIENT_SECRET
    if not expires_at:
        expires_at = int(time.time()) + (90 * 86400)

    # 1. Umbrella
    if 'Umbrella' in targets and _safe_set_addon_setting('plugin.video.umbrella', 'trakt.user.token', token, home_dir):
        _safe_set_addon_setting('plugin.video.umbrella', 'trakt.refreshtoken', refresh, home_dir)
        _safe_set_addon_setting('plugin.video.umbrella', 'trakt.token.expires', str(expires_at), home_dir)
        _safe_set_addon_setting('plugin.video.umbrella', 'trakt.authed.clientid', client_id, home_dir)
        if secret:
            _safe_set_addon_setting('plugin.video.umbrella', 'trakt.authed.secret', secret, home_dir)
        _safe_set_addon_setting('plugin.video.umbrella', 'trakt.isauthed', 'true', home_dir)
        if username:
            _safe_set_addon_setting('plugin.video.umbrella', 'trakt.username', username, home_dir)
        updated.append('Umbrella')

    # 2. Seren
    if 'Seren' in targets and _safe_set_addon_setting('plugin.video.seren', 'trakt.auth', token, home_dir):
        _safe_set_addon_setting('plugin.video.seren', 'trakt.refresh', refresh, home_dir)
        _safe_set_addon_setting('plugin.video.seren', 'trakt.expires', str(expires_at), home_dir)
        _safe_set_addon_setting('plugin.video.seren', 'trakt.clientid', client_id, home_dir)
        if secret:
            _safe_set_addon_setting('plugin.video.seren', 'trakt.secret', secret, home_dir)
        if username:
            _safe_set_addon_setting('plugin.video.seren', 'trakt.username', username, home_dir)
        updated.append('Seren')

    # 3. The Gears
    if 'The Gears' in targets and _update_gears_db('trakt.token', token, 'string', home_dir):
        _update_gears_db('trakt.refresh', refresh, 'string', home_dir)
        _update_gears_db('trakt.expires', str(expires_at), 'string', home_dir)
        _update_gears_db('trakt.client', client_id, 'string', home_dir)
        if secret:
            _update_gears_db('trakt.secret', secret, 'string', home_dir)
        if username:
            _update_gears_db('trakt.user', username, 'string', home_dir)
        updated.append('The Gears')

    # 4. TMDb Helper
    if 'TMDb Helper' in targets:
        token_json = json.dumps({
            'access_token': token,
            'refresh_token': refresh,
            'expires_in': max(0, int(expires_at - time.time())),
            'created_at': int(time.time()),
            'token_type': 'bearer',
            'scope': 'public'
        })
        _safe_set_addon_setting('plugin.video.themoviedb.helper', 'trakt_token', token_json, home_dir)
        _safe_set_addon_setting('plugin.video.themoviedb.helper', 'trakt_token_access', 'true', home_dir)
        _safe_set_addon_setting('plugin.video.themoviedb.helper', 'sync_source_upnext', 'Trakt', home_dir)
        _safe_set_addon_setting('plugin.video.themoviedb.helper', 'trakt_watchedinprogress', 'true', home_dir)
        if username:
            _safe_set_addon_setting('plugin.video.themoviedb.helper', 'trakt_username', username, home_dir)
        updated.append('TMDb Helper')

    # Note: The Crew (script.module.thecrew) is deliberately excluded from Trakt fan-out.
    # The Crew hardcodes its own API client ID (keys.trakt_id) and rejects tokens issued
    # under StarWave / TMDb Helper's client ID with HTTP 401 Unauthorized, popping a recurring
    # 'TRAKT SESSION EXPIRED' dialog at startup. Sports and replays in The Crew do not use Trakt.

    return updated


def fanout_youtube(api_key='', client_id='', client_secret='', home_dir=None):
    """Fan out YouTube API credentials to YouTube add-on and trailer modules."""
    updated = []
    if api_key:
        _safe_set_addon_setting('plugin.video.youtube', 'youtube.api.key', api_key, home_dir)
        _safe_set_addon_setting('plugin.video.youtube', 'youtube.allow.dev.keys', 'true', home_dir)
        if 'YouTube' not in updated:
            updated.append('YouTube')
    if client_id:
        _safe_set_addon_setting('plugin.video.youtube', 'youtube.api.id', client_id, home_dir)
        if 'YouTube' not in updated:
            updated.append('YouTube')
    if client_secret:
        _safe_set_addon_setting('plugin.video.youtube', 'youtube.api.secret', client_secret, home_dir)
        if 'YouTube' not in updated:
            updated.append('YouTube')
    return updated


def clear_youtube_credentials(home_dir=None):
    """Wipe YouTube API key, Client ID, and Client Secret."""
    cleared = []
    _safe_set_addon_setting('plugin.video.youtube', 'youtube.api.key', '', home_dir)
    _safe_set_addon_setting('plugin.video.youtube', 'youtube.api.id', '', home_dir)
    _safe_set_addon_setting('plugin.video.youtube', 'youtube.api.secret', '', home_dir)
    cleared.append('YouTube')
    return cleared


def clear_realdebrid_credentials(home_dir=None):
    """Wipe Real-Debrid tokens and logins across Umbrella, Seren, ResolveURL, The Gears, and Otaku."""
    cleared = []
    _safe_set_addon_setting('plugin.video.umbrella', 'realdebridtoken', '', home_dir)
    _safe_set_addon_setting('plugin.video.umbrella', 'realdebridusername', '', home_dir)
    _safe_set_addon_setting('plugin.video.umbrella', 'realdebridrefresh', '', home_dir)
    _safe_set_addon_setting('plugin.video.umbrella', 'realdebrid.clientid', '', home_dir)
    _safe_set_addon_setting('plugin.video.umbrella', 'realdebridsecret', '', home_dir)
    cleared.append('Umbrella')

    _safe_set_addon_setting('plugin.video.seren', 'rd.auth', '', home_dir)
    _safe_set_addon_setting('plugin.video.seren', 'rd.username', '', home_dir)
    _safe_set_addon_setting('plugin.video.seren', 'rd.secret', '', home_dir)
    _safe_set_addon_setting('plugin.video.seren', 'rd.clientid', '', home_dir)
    _safe_set_addon_setting('plugin.video.seren', 'rd.refresh', '', home_dir)
    _safe_set_addon_setting('plugin.video.seren', 'rd.enabled', 'false', home_dir)
    cleared.append('Seren')

    _safe_set_addon_setting('script.module.resolveurl', 'RealDebridResolver_token', '', home_dir)
    _safe_set_addon_setting('script.module.resolveurl', 'RealDebridResolver_user', '', home_dir)
    _safe_set_addon_setting('script.module.resolveurl', 'RealDebridResolver_refresh', '', home_dir)
    _safe_set_addon_setting('script.module.resolveurl', 'RealDebridResolver_client_id', '', home_dir)
    _safe_set_addon_setting('script.module.resolveurl', 'RealDebridResolver_secret', '', home_dir)
    cleared.append('ResolveURL')

    _update_gears_db('rd.token', '', 'string', home_dir)
    _update_gears_db('rd.account_id', '', 'string', home_dir)
    _update_gears_db('rd.secret', '', 'string', home_dir)
    _update_gears_db('rd.client', '', 'string', home_dir)
    _update_gears_db('rd.refresh', '', 'string', home_dir)
    _update_gears_db('rd.enabled', 'false', 'bool', home_dir)
    cleared.append('The Gears')

    _safe_set_addon_setting('plugin.video.otaku.testing', 'realdebrid.token', '', home_dir)
    _safe_set_addon_setting('plugin.video.otaku.testing', 'realdebrid.username', '', home_dir)
    _safe_set_addon_setting('plugin.video.otaku.testing', 'realdebrid.refresh', '', home_dir)
    cleared.append('Otaku')

    return cleared


def clear_premiumize_credentials(home_dir=None):
    """Wipe Premiumize tokens across Umbrella, Seren, ResolveURL, The Gears, and Otaku."""
    cleared = []
    _safe_set_addon_setting('plugin.video.umbrella', 'premiumizetoken', '', home_dir)
    _safe_set_addon_setting('plugin.video.umbrella', 'premiumize.username', '', home_dir)
    cleared.append('Umbrella')

    _safe_set_addon_setting('plugin.video.seren', 'premiumize.token', '', home_dir)
    _safe_set_addon_setting('plugin.video.seren', 'premiumize.username', '', home_dir)
    _safe_set_addon_setting('plugin.video.seren', 'premiumize.enabled', 'false', home_dir)
    cleared.append('Seren')

    _safe_set_addon_setting('script.module.resolveurl', 'PremiumizeMeResolver_token', '', home_dir)
    cleared.append('ResolveURL')

    _update_gears_db('pm.token', '', 'string', home_dir)
    _update_gears_db('pm.account_id', '', 'string', home_dir)
    _update_gears_db('pm.enabled', 'false', 'bool', home_dir)
    cleared.append('The Gears')

    _safe_set_addon_setting('plugin.video.otaku.testing', 'premiumize.token', '', home_dir)
    cleared.append('Otaku')

    return cleared


def clear_alldebrid_credentials(home_dir=None):
    """Wipe AllDebrid tokens across Umbrella, Seren, ResolveURL, The Gears, and Otaku."""
    cleared = []
    _safe_set_addon_setting('plugin.video.umbrella', 'alldebridtoken', '', home_dir)
    _safe_set_addon_setting('plugin.video.umbrella', 'alldebridusername', '', home_dir)
    cleared.append('Umbrella')

    _safe_set_addon_setting('plugin.video.seren', 'alldebrid.token', '', home_dir)
    _safe_set_addon_setting('plugin.video.seren', 'alldebrid.username', '', home_dir)
    _safe_set_addon_setting('plugin.video.seren', 'alldebrid.enabled', 'false', home_dir)
    cleared.append('Seren')

    _safe_set_addon_setting('script.module.resolveurl', 'AllDebridResolver_token', '', home_dir)
    cleared.append('ResolveURL')

    _update_gears_db('ad.token', '', 'string', home_dir)
    _update_gears_db('ad.account_id', '', 'string', home_dir)
    _update_gears_db('ad.enabled', 'false', 'bool', home_dir)
    cleared.append('The Gears')

    _safe_set_addon_setting('plugin.video.otaku.testing', 'alldebrid.token', '', home_dir)
    cleared.append('Otaku')

    return cleared


def clear_trakt_credentials(home_dir=None):
    """Wipe Trakt tokens across TMDb Helper, Umbrella, Seren, The Gears, and The Crew."""
    cleared = []
    _safe_set_addon_setting('plugin.video.umbrella', 'trakt.user.token', '', home_dir)
    _safe_set_addon_setting('plugin.video.umbrella', 'trakt.username', '', home_dir)
    _safe_set_addon_setting('plugin.video.umbrella', 'trakt.refreshtoken', '', home_dir)
    _safe_set_addon_setting('plugin.video.umbrella', 'trakt.isauthed', 'false', home_dir)
    cleared.append('Umbrella')

    _safe_set_addon_setting('plugin.video.seren', 'trakt.auth', '', home_dir)
    _safe_set_addon_setting('plugin.video.seren', 'trakt.username', '', home_dir)
    _safe_set_addon_setting('plugin.video.seren', 'trakt.refresh', '', home_dir)
    cleared.append('Seren')

    _update_gears_db('trakt.token', '', 'string', home_dir)
    _update_gears_db('trakt.user', '', 'string', home_dir)
    _update_gears_db('trakt.refresh', '', 'string', home_dir)
    cleared.append('The Gears')

    _safe_set_addon_setting('plugin.video.themoviedb.helper', 'trakt_token', '', home_dir)
    _safe_set_addon_setting('plugin.video.themoviedb.helper', 'trakt_username', '', home_dir)
    _safe_set_addon_setting('plugin.video.themoviedb.helper', 'trakt_token_access', 'false', home_dir)
    cleared.append('TMDb Helper')

    _safe_set_addon_setting('plugin.video.thecrew', 'trakt.token', '', home_dir)
    _safe_set_addon_setting('plugin.video.thecrew', 'trakt.user', '', home_dir)
    _safe_set_addon_setting('plugin.video.thecrew', 'trakt.auth', '', home_dir)
    _safe_set_addon_setting('plugin.video.thecrew', 'trakt.refresh', '', home_dir)
    _safe_set_addon_setting('plugin.video.thecrew', 'trakt.expires_at', '', home_dir)
    cleared.append('The Crew')

    return cleared


def clear_github_credentials(home_dir=None):
    """Wipe GitHub Build Unlock token from StarWave Wizard."""
    _safe_set_addon_setting('plugin.program.starwave.wizard', 'gh_token', '', home_dir)
    return ['StarWave Wizard']


def clear_credentials_for_service(service_name, home_dir=None):
    """Clear credentials for a single service by name."""
    s = service_name.lower().replace('-', '').replace(' ', '')
    if 'realdebrid' in s or s == 'rd':
        return clear_realdebrid_credentials(home_dir)
    elif 'premiumize' in s or s == 'pm':
        return clear_premiumize_credentials(home_dir)
    elif 'alldebrid' in s or s == 'ad':
        return clear_alldebrid_credentials(home_dir)
    elif 'trakt' in s:
        return clear_trakt_credentials(home_dir)
    elif 'youtube' in s or s == 'yt':
        return clear_youtube_credentials(home_dir)
    elif 'github' in s or 'gh' in s:
        return clear_github_credentials(home_dir)
    elif 'all' in s:
        return clear_all_credentials(home_dir)
    return []


def clear_all_credentials(home_dir=None, include_github=True):
    """Wipe all saved logins and tokens across all supported add-ons."""
    clear_realdebrid_credentials(home_dir)
    clear_premiumize_credentials(home_dir)
    clear_alldebrid_credentials(home_dir)
    clear_trakt_credentials(home_dir)
    clear_youtube_credentials(home_dir)
    if include_github:
        clear_github_credentials(home_dir)
    return ['Umbrella', 'Seren', 'ResolveURL', 'The Gears', 'Otaku', 'TMDb Helper', 'The Crew', 'YouTube'] + (['StarWave Wizard'] if include_github else [])


# -----------------------------------------------------------------------------
# Status Inspection
# -----------------------------------------------------------------------------

def get_account_status(home_dir=None):
    """Inspect all configured accounts across all add-ons."""
    status = {
        'realdebrid': {'active': False, 'username': '', 'addons': []},
        'premiumize': {'active': False, 'username': '', 'addons': []},
        'alldebrid': {'active': False, 'username': '', 'addons': []},
        'trakt': {'active': False, 'username': '', 'addons': []},
        'youtube': {'active': False, 'username': '', 'addons': []},
    }

    # RD inspection
    rd_umbrella = _safe_get_addon_setting('plugin.video.umbrella', 'realdebridtoken', '', home_dir)
    rd_seren = _safe_get_addon_setting('plugin.video.seren', 'rd.auth', '', home_dir)
    rd_resolveurl = _safe_get_addon_setting('script.module.resolveurl', 'RealDebridResolver_token', '', home_dir)
    rd_gears = _read_gears_db('rd.token', '', home_dir)
    rd_otaku = _safe_get_addon_setting('plugin.video.otaku.testing', 'realdebrid.token', '', home_dir)

    if any((rd_umbrella, rd_seren, rd_resolveurl, rd_gears, rd_otaku)):
        status['realdebrid']['active'] = True
        u = (_safe_get_addon_setting('plugin.video.umbrella', 'realdebridusername', '', home_dir) or
             _safe_get_addon_setting('plugin.video.seren', 'rd.username', '', home_dir) or
             _read_gears_db('rd.account_id', '', home_dir))
        status['realdebrid']['username'] = u
        if rd_umbrella: status['realdebrid']['addons'].append('Umbrella')
        if rd_seren: status['realdebrid']['addons'].append('Seren')
        if rd_resolveurl: status['realdebrid']['addons'].append('ResolveURL (The Crew)')
        if rd_gears: status['realdebrid']['addons'].append('The Gears')
        if rd_otaku: status['realdebrid']['addons'].append('Otaku')

    # PM inspection
    pm_umbrella = _safe_get_addon_setting('plugin.video.umbrella', 'premiumizetoken', '', home_dir)
    pm_seren = _safe_get_addon_setting('plugin.video.seren', 'premiumize.token', '', home_dir)
    pm_resolveurl = _safe_get_addon_setting('script.module.resolveurl', 'PremiumizeMeResolver_token', '', home_dir)
    pm_gears = _read_gears_db('pm.token', '', home_dir)
    pm_otaku = _safe_get_addon_setting('plugin.video.otaku.testing', 'premiumize.token', '', home_dir)

    if any((pm_umbrella, pm_seren, pm_resolveurl, pm_gears, pm_otaku)):
        status['premiumize']['active'] = True
        u = (_safe_get_addon_setting('plugin.video.umbrella', 'premiumize.username', '', home_dir) or
             _safe_get_addon_setting('plugin.video.seren', 'premiumize.username', '', home_dir) or
             _read_gears_db('pm.account_id', '', home_dir))
        status['premiumize']['username'] = u
        if pm_umbrella: status['premiumize']['addons'].append('Umbrella')
        if pm_seren: status['premiumize']['addons'].append('Seren')
        if pm_resolveurl: status['premiumize']['addons'].append('ResolveURL (The Crew)')
        if pm_gears: status['premiumize']['addons'].append('The Gears')
        if pm_otaku: status['premiumize']['addons'].append('Otaku')

    # AllDebrid inspection
    ad_umbrella = _safe_get_addon_setting('plugin.video.umbrella', 'alldebridtoken', '', home_dir)
    ad_seren = _safe_get_addon_setting('plugin.video.seren', 'alldebrid.token', '', home_dir)
    ad_resolveurl = _safe_get_addon_setting('script.module.resolveurl', 'AllDebridResolver_token', '', home_dir)
    ad_gears = _read_gears_db('ad.token', '', home_dir)
    ad_otaku = _safe_get_addon_setting('plugin.video.otaku.testing', 'alldebrid.token', '', home_dir)

    if any((ad_umbrella, ad_seren, ad_resolveurl, ad_gears, ad_otaku)):
        status['alldebrid']['active'] = True
        u = (_safe_get_addon_setting('plugin.video.umbrella', 'alldebridusername', '', home_dir) or
             _safe_get_addon_setting('plugin.video.seren', 'alldebrid.username', '', home_dir) or
             _read_gears_db('ad.account_id', '', home_dir))
        status['alldebrid']['username'] = u
        if ad_umbrella: status['alldebrid']['addons'].append('Umbrella')
        if ad_seren: status['alldebrid']['addons'].append('Seren')
        if ad_resolveurl: status['alldebrid']['addons'].append('ResolveURL (The Crew)')
        if ad_gears: status['alldebrid']['addons'].append('The Gears')
        if ad_otaku: status['alldebrid']['addons'].append('Otaku')

    # Trakt inspection
    tr_umbrella = _safe_get_addon_setting('plugin.video.umbrella', 'trakt.user.token', '', home_dir)
    tr_seren = _safe_get_addon_setting('plugin.video.seren', 'trakt.auth', '', home_dir)
    tr_gears = _read_gears_db('trakt.token', '', home_dir)
    tr_tmdb_raw = _safe_get_addon_setting('plugin.video.themoviedb.helper', 'trakt_token', '', home_dir)
    tr_tmdb = ''
    if tr_tmdb_raw:
        try:
            tok = json.loads(tr_tmdb_raw).get('access_token', '')
            tr_tmdb = _clean_val(tok)
        except Exception:
            tr_tmdb = _clean_val(tr_tmdb_raw)
    if any((tr_umbrella, tr_seren, tr_gears, tr_tmdb)):
        status['trakt']['active'] = True
        u = (_safe_get_addon_setting('plugin.video.umbrella', 'trakt.username', '', home_dir) or
             _safe_get_addon_setting('plugin.video.seren', 'trakt.username', '', home_dir) or
             _read_gears_db('trakt.user', '', home_dir))
        status['trakt']['username'] = u
        if tr_umbrella: status['trakt']['addons'].append('Umbrella')
        if tr_seren: status['trakt']['addons'].append('Seren')
        if tr_gears: status['trakt']['addons'].append('The Gears')
        if tr_tmdb: status['trakt']['addons'].append('TMDb Helper')

    # YouTube inspection
    yt_key = _safe_get_addon_setting('plugin.video.youtube', 'youtube.api.key', '', home_dir)
    yt_id = _safe_get_addon_setting('plugin.video.youtube', 'youtube.api.id', '', home_dir)
    if yt_key or yt_id:
        status['youtube']['active'] = True
        status['youtube']['username'] = 'Custom API Key' if yt_key else 'Client ID Set'
        status['youtube']['addons'].append('YouTube')

    return status


# -----------------------------------------------------------------------------
# Interactive OAuth Device Flows (Kodi UI)
# -----------------------------------------------------------------------------

def _http_get_json(url, headers=None, timeout=5):
    if headers is None:
        headers = {}
    headers = dict(headers)
    headers.setdefault('User-Agent', 'StarWave-Wizard')
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode('utf-8'))


def _http_post_json(url, data=None, headers=None, timeout=5):
    if headers is None:
        headers = {}
    headers = dict(headers)
    headers.setdefault('User-Agent', 'StarWave-Wizard')
    encoded_data = None
    if isinstance(data, dict):
        if headers.get('Content-Type') == 'application/json':
            encoded_data = json.dumps(data).encode('utf-8')
        else:
            encoded_data = urllib.parse.urlencode(data).encode('utf-8')
    req = urllib.request.Request(url, data=encoded_data, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode('utf-8'))


def auth_realdebrid(dialog_title='Real-Debrid Authorization'):
    """Interactive Real-Debrid OAuth Device Code Flow with QR code and Fan-Out."""
    if not KODI_AVAILABLE:
        return None
    try:
        url = f'https://api.real-debrid.com/oauth/v2/device/code?client_id={RD_APP_ID}&new_credentials=yes'
        res = _http_get_json(url)
        device_code = res['device_code']
        user_code = res['user_code']
        interval = max(int(res.get('interval', 5)), 1)
        # Give generous timeout window (minimum 15 mins / 900s)
        device_ttl = max(int(res.get('expires_in', 900)), 900)
        verification_url = res.get('verification_url', 'https://real-debrid.com/device')

        qr_img = make_qr_file(verification_url, tag='realdebrid')
        line1 = f'1. Scan QR code or visit: [B]{verification_url}[/B]'
        line2 = f'2. Enter Code: [B][COLOR gold]{user_code}[/COLOR][/B]'
        line3 = 'Waiting for confirmation on your phone or browser...'

        dialog = QRCodeProgressDialog(dialog_title, line1, line2, line3, qr_img)

        poll_url = f'https://api.real-debrid.com/oauth/v2/device/credentials?client_id={RD_APP_ID}&code={device_code}'
        start = time.time()
        creds = None
        while not dialog.iscanceled() and (time.time() - start) < device_ttl:
            if _wait_dialog(dialog, interval):
                break
            elapsed = int(time.time() - start)
            remaining = max(0, device_ttl - elapsed)
            pct = min(100, int(elapsed / device_ttl * 100))
            dialog.update(
                pct,
                line1=line1,
                line2=line2,
                line3=f'Waiting for phone approval... ({remaining}s remaining)',
                image=qr_img
            )
            try:
                poll_res = _http_get_json(poll_url)
                if 'client_id' in poll_res and 'client_secret' in poll_res:
                    creds = poll_res
                    break
            except urllib.error.HTTPError as exc:
                # 400 or 404 means authorization pending; keep waiting
                if exc.code in (400, 404, 429):
                    continue
                break
            except Exception:
                continue
        dialog.close()

        if not creds:
            xbmcgui.Dialog().ok(dialog_title, 'Authorization cancelled or timed out.')
            return None

        token_url = 'https://api.real-debrid.com/oauth/v2/token'
        token_data = {
            'client_id': creds['client_id'],
            'client_secret': creds['client_secret'],
            'code': device_code,
            'grant_type': 'http://oauth.net/grant_type/device/1.0'
        }
        token_res = _http_post_json(token_url, data=token_data)
        access_token = token_res['access_token']
        refresh_token = token_res.get('refresh_token', '')
        client_id = creds['client_id']
        client_secret = creds['client_secret']

        username = ''
        try:
            user_info = _http_get_json(
                'https://api.real-debrid.com/rest/1.0/user',
                headers={'Authorization': f'Bearer {access_token}'}
            )
            username = user_info.get('username', '')
        except Exception:
            pass

        updated = fanout_realdebrid(access_token, refresh_token, client_id, client_secret, username)
        msg = f'Real-Debrid authorized successfully for [B]{username or "User"}[/B]!\n\nCredentials fanned out to:\n• ' + '\n• '.join(updated)
        xbmcgui.Dialog().ok(dialog_title, msg)
        return {'token': access_token, 'username': username, 'updated': updated}
    except Exception as exc:
        _log(f'RD auth error: {exc}')
        xbmcgui.Dialog().ok(dialog_title, f'Authorization failed: {exc}')
        return None


def auth_premiumize(dialog_title='Premiumize Authorization'):
    """Interactive Premiumize Device Code Flow with QR code and Fan-Out."""
    if not KODI_AVAILABLE:
        return None
    try:
        url = 'https://www.premiumize.me/token'
        data = {'response_type': 'device_code', 'client_id': PM_CLIENT_ID}
        res = _http_post_json(url, data=data)
        device_code = res['device_code']
        user_code = res['user_code']
        interval = max(int(res.get('interval', 5)), 1)
        device_ttl = max(int(res.get('expires_in', 900)), 900)
        verification_url = res.get('verification_uri', 'https://www.premiumize.me/device')

        qr_img = make_qr_file(verification_url, tag='premiumize')
        line1 = f'1. Scan QR code or visit: [B]{verification_url}[/B]'
        line2 = f'2. Enter Code: [B][COLOR gold]{user_code}[/COLOR][/B]'
        line3 = 'Waiting for confirmation on your phone or browser...'

        dialog = QRCodeProgressDialog(dialog_title, line1, line2, line3, qr_img)

        poll_data = {'grant_type': 'device_code', 'client_id': PM_CLIENT_ID, 'code': device_code}
        start = time.time()
        token = None
        while not dialog.iscanceled() and (time.time() - start) < device_ttl:
            if _wait_dialog(dialog, interval):
                break
            elapsed = int(time.time() - start)
            remaining = max(0, device_ttl - elapsed)
            pct = min(100, int(elapsed / device_ttl * 100))
            dialog.update(
                pct,
                line1=line1,
                line2=line2,
                line3=f'Waiting for phone approval... ({remaining}s remaining)',
                image=qr_img
            )
            try:
                poll_res = _http_post_json(url, data=poll_data)
                if 'access_token' in poll_res:
                    token = poll_res['access_token']
                    break
            except urllib.error.HTTPError as exc:
                if exc.code in (400, 404, 429):
                    continue
                break
            except Exception:
                continue
        dialog.close()

        if not token:
            xbmcgui.Dialog().ok(dialog_title, 'Authorization cancelled or timed out.')
            return None

        username = ''
        try:
            account_info = _http_get_json(
                'https://www.premiumize.me/api/account/info',
                headers={'Authorization': f'Bearer {token}'}
            )
            username = str(account_info.get('customer_id', ''))
        except Exception:
            pass

        updated = fanout_premiumize(token, username)
        msg = f'Premiumize authorized successfully for [B]{username or "User"}[/B]!\n\nCredentials fanned out to:\n• ' + '\n• '.join(updated)
        xbmcgui.Dialog().ok(dialog_title, msg)
        return {'token': token, 'username': username, 'updated': updated}
    except Exception as exc:
        _log(f'PM auth error: {exc}')
        xbmcgui.Dialog().ok(dialog_title, f'Authorization failed: {exc}')
        return None


def auth_alldebrid(dialog_title='AllDebrid Authorization'):
    """Interactive AllDebrid Pin Flow with QR code and Fan-Out."""
    if not KODI_AVAILABLE:
        return None
    try:
        url = f'https://api.alldebrid.com/v4/pin/get?agent={AD_AGENT}'
        res = _http_get_json(url)
        data = res.get('data', {})
        pin = data['pin']
        check_url = data['check_url']
        device_ttl = max(int(data.get('expires_in', 900)), 900)
        verification_url = f'https://alldebrid.com/pin?pin={pin}'

        qr_img = make_qr_file(verification_url, tag='alldebrid')
        line1 = f'1. Scan QR code or visit: [B]{verification_url}[/B]'
        line2 = f'2. PIN: [B][COLOR gold]{pin}[/COLOR][/B]'
        line3 = 'Waiting for confirmation on your phone or browser...'

        dialog = QRCodeProgressDialog(dialog_title, line1, line2, line3, qr_img)

        start = time.time()
        apikey = None
        while not dialog.iscanceled() and (time.time() - start) < device_ttl:
            if _wait_dialog(dialog, 5):
                break
            elapsed = int(time.time() - start)
            remaining = max(0, device_ttl - elapsed)
            pct = min(100, int(elapsed / device_ttl * 100))
            dialog.update(
                pct,
                line1=line1,
                line2=line2,
                line3=f'Waiting for phone approval... ({remaining}s remaining)',
                image=qr_img
            )
            try:
                poll_res = _http_get_json(check_url)
                poll_data = poll_res.get('data', {})
                if poll_data.get('activated') and poll_data.get('apikey'):
                    apikey = poll_data['apikey']
                    break
            except urllib.error.HTTPError as exc:
                if exc.code in (400, 404, 429):
                    continue
                break
            except Exception:
                continue
        dialog.close()

        if not apikey:
            xbmcgui.Dialog().ok(dialog_title, 'Authorization cancelled or timed out.')
            return None

        username = ''
        try:
            user_info = _http_get_json(
                f'https://api.alldebrid.com/v4/user?agent={AD_AGENT}',
                headers={'Authorization': f'Bearer {apikey}'}
            )
            username = user_info.get('data', {}).get('user', {}).get('username', '')
        except Exception:
            pass

        updated = fanout_alldebrid(apikey, username)
        msg = f'AllDebrid authorized successfully for [B]{username or "User"}[/B]!\n\nCredentials fanned out to:\n• ' + '\n• '.join(updated)
        xbmcgui.Dialog().ok(dialog_title, msg)
        return {'token': apikey, 'username': username, 'updated': updated}
    except Exception as exc:
        _log(f'AllDebrid auth error: {exc}')
        xbmcgui.Dialog().ok(dialog_title, f'Authorization failed: {exc}')
        return None


def auth_trakt(dialog_title='Trakt Authorization'):
    """Interactive Trakt OAuth Device Code Flow with QR code and Fan-Out."""
    if not KODI_AVAILABLE:
        return None
    try:
        url = 'https://api.trakt.tv/oauth/device/code'
        headers = {'Content-Type': 'application/json', 'trakt-api-key': STARWAVE_TRAKT_CLIENT_ID, 'trakt-api-version': '2'}
        data = {'client_id': STARWAVE_TRAKT_CLIENT_ID, 'scope': STARWAVE_TRAKT_SCOPE}
        res = _http_post_json(url, data=data, headers=headers)
        device_code = res['device_code']
        user_code = res['user_code']
        interval = max(int(res.get('interval', 5)), 1)
        device_ttl = max(int(res.get('expires_in', 900)), 900)
        verification_url = res.get('verification_url', 'https://trakt.tv/activate')

        qr_img = make_qr_file(verification_url, tag='trakt')
        line1 = f'1. Scan QR code or visit: [B]{verification_url}[/B]'
        line2 = f'2. Enter Code: [B][COLOR gold]{user_code}[/COLOR][/B]'
        line3 = 'Waiting for confirmation on your phone or browser...'

        dialog = QRCodeProgressDialog(dialog_title, line1, line2, line3, qr_img)

        poll_url = 'https://api.trakt.tv/oauth/device/token'
        poll_data = {
            'code': device_code,
            'client_id': STARWAVE_TRAKT_CLIENT_ID,
            'client_secret': STARWAVE_TRAKT_CLIENT_SECRET
        }
        start = time.time()
        token_info = None
        while not dialog.iscanceled() and (time.time() - start) < device_ttl:
            if _wait_dialog(dialog, interval):
                break
            elapsed = int(time.time() - start)
            remaining = max(0, device_ttl - elapsed)
            pct = min(100, int(elapsed / device_ttl * 100))
            dialog.update(
                pct,
                line1=line1,
                line2=line2,
                line3=f'Waiting for phone approval... ({remaining}s remaining)',
                image=qr_img
            )
            try:
                poll_res = _http_post_json(poll_url, data=poll_data, headers=headers)
                if 'access_token' in poll_res:
                    token_info = poll_res
                    break
            except urllib.error.HTTPError as exc:
                if exc.code in (400, 404, 429):
                    continue
                break
            except Exception:
                continue
        dialog.close()

        if not token_info:
            xbmcgui.Dialog().ok(dialog_title, 'Authorization cancelled or timed out.')
            return None

        access_token = token_info['access_token']
        refresh_token = token_info.get('refresh_token', '')
        created_at = token_info.get('created_at', int(time.time()))
        token_ttl = token_info.get('expires_in', 90 * 86400)
        expires_at = created_at + token_ttl

        username = ''
        try:
            user_headers = {
                'Content-Type': 'application/json',
                'trakt-api-key': STARWAVE_TRAKT_CLIENT_ID,
                'trakt-api-version': '2',
                'Authorization': f'Bearer {access_token}'
            }
            user_info = _http_get_json('https://api.trakt.tv/users/me', headers=user_headers) or {}
            # /users/me returns the user object at the TOP level. The nested {'user': {...}}
            # read that used to live here always produced '', so The Crew never received a
            # trakt.user and logged 'Crew Trakt not configured' on every boot. The nested shape
            # is kept as a fallback so a differently-shaped response still works.
            nested = user_info.get('user') if isinstance(user_info, dict) else None
            username = ((user_info.get('username') if isinstance(user_info, dict) else '')
                        or (nested.get('username', '') if isinstance(nested, dict) else '')
                        or '')
        except Exception as exc:
            _log(f'Trakt username lookup failed: {exc}')

        granted_scope = str(token_info.get('scope', '') or '')
        if 'offline_access' not in granted_scope:
            # Not fatal - the token works today - but without offline_access it cannot be
            # refreshed for the long term, so Trakt sync dies quietly about a week later.
            # Make that visible in the log rather than blocking a just-completed sign-in.
            _log(
                f'WARNING: Trakt granted scope "{granted_scope or "(none reported)"}" - '
                'offline_access was not included, so this token may stop refreshing after '
                'about a week and Trakt will need authorizing again.',
                xbmc.LOGWARNING
            )

        updated = fanout_trakt(
            access_token, refresh_token, expires_at,
            STARWAVE_TRAKT_CLIENT_ID, STARWAVE_TRAKT_CLIENT_SECRET, username
        )
        msg = f'Trakt authorized successfully for [B]{username or "User"}[/B]!\n\nCredentials fanned out to:\n• ' + '\n• '.join(updated)
        xbmcgui.Dialog().ok(dialog_title, msg)
        return {'token': access_token, 'username': username, 'updated': updated, 'scope': granted_scope}
    except Exception as exc:
        _log(f'Trakt auth error: {exc}')
        xbmcgui.Dialog().ok(dialog_title, f'Authorization failed: {exc}')
        return None
