# -*- coding: utf-8 -*-
"""StarWave Wizard — installs and updates the StarWave build on this Kodi."""

import os
import sys
import shutil
import time
from urllib.parse import urlencode, parse_qsl
from urllib.request import Request, urlopen

import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ICON = ADDON.getAddonInfo('icon')
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1

# 'latest' resolves to the newest release carrying this asset, so the wizard
# keeps working when a new build is published without needing an update itself.
BUILD_URL = 'https://github.com/strfck3r/starwave/releases/latest/download/StarWave-V1-kodi.zip'

HOME = xbmcvfs.translatePath('special://home/')
PACKAGES = os.path.join(HOME, 'addons', 'packages')
TEMP_ZIP = os.path.join(xbmcvfs.translatePath('special://temp/'), 'starwave-build.zip')
ADDONS_DB = os.path.join(HOME, 'userdata', 'Database', 'Addons33.db')

# The build is assembled on an NVIDIA Shield, so these two ship as android-aarch64 binaries.
# They cannot load anywhere else, and installing them would replace whatever the host Kodi
# already has. Everything else in the build is Python, skin XML or images and is portable.
ANDROID_ONLY = ('inputstream.adaptive', 'vfs.libarchive')

# Update mode leaves these alone when they already exist on the device. They hold the user's
# own state — Kodi's system/player/media/skin settings and their sources, favourites, logins
# and profiles — none of which an update should reset.
USER_FILES = (
    'userdata/guisettings.xml',
    'userdata/sources.xml',
    'userdata/favourites.xml',
    'userdata/passwords.xml',
    'userdata/profiles.xml',
)

# The add-on database is never extracted in update mode: the device's copy also registers
# add-ons the user installed themselves, which the build's copy knows nothing about. New
# build add-ons are merged into it instead (see merge_installed).
ADDONS_DB_MEMBER = 'userdata/Database/Addons33.db'


def is_android():
    return xbmc.getCondVisibility('System.Platform.Android')


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), level)


def notify(msg, ms=4000):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, ICON, ms)


def build_url(**kwargs):
    return '%s?%s' % (sys.argv[0], urlencode(kwargs))


def add_item(label, action, description, folder=False):
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': ICON, 'thumb': ICON})
    li.setInfo('video', {'title': label, 'plot': description})
    xbmcplugin.addDirectoryItem(HANDLE, build_url(action=action), li, folder)


def menu():
    add_item(
        'Update StarWave (keep my settings)',
        'update',
        'Downloads the current StarWave build and applies it over this install: skin, home '
        'menu, widgets and add-ons all update.\n\n'
        'Your own settings survive — Kodi system, player, media and skin settings, and every '
        'add-on login and configuration (Trakt, Real-Debrid, Premiumize and the rest). '
        'Nothing has to be signed in or set up again.\n\n'
        'Kodi closes when it finishes — reopen it and you are on the new version.',
    )
    add_item(
        'Fresh Install (reset to defaults)',
        'install',
        'Downloads the current StarWave build and applies it clean: everything is reset to '
        'the StarWave defaults, including settings and add-on configuration. Saved logins '
        'are wiped — sign in again afterwards via Trakt > Setup.\n\n'
        'Use this for a first install, or to put a broken setup back to a known-good state.\n\n'
        'Kodi closes when it finishes — reopen it and you are on StarWave.',
    )
    add_item(
        'What this installs',
        'info',
        'Details of the build and what each option replaces.',
    )
    xbmcplugin.endOfDirectory(HANDLE)


def show_info():
    xbmcgui.Dialog().textviewer(
        ADDON_NAME,
        'StarWave — a Kodi 21 "Omega" build.\n\n'
        'INSTALLS\n'
        '  108 add-ons, the StarWave skin, the home menu and its widgets, and the Star Hubs '
        'setup screen.\n\n'
        'UPDATE (KEEP MY SETTINGS)\n'
        '  Updates the skin, menus, widgets and add-ons, but keeps your Kodi settings, your '
        'sources and favourites, and every add-on\'s own settings — including saved Trakt, '
        'Real-Debrid and Premiumize logins. Add-ons you installed yourself stay installed '
        'and enabled.\n\n'
        'FRESH INSTALL (RESET TO DEFAULTS)\n'
        '  Replaces everything with the build defaults: skin, menus, settings and add-on '
        'configuration. No credentials are included — sign in afterwards via Trakt > Setup. '
        'For a predictable result, run this on a fresh Kodi install.\n\n'
        'AFTERWARDS\n'
        '  Kodi is closed so it cannot write its old settings back over the new ones. Reopen '
        'Kodi to finish.',
    )


def _cleanup_temp():
    try:
        if os.path.exists(TEMP_ZIP):
            os.remove(TEMP_ZIP)
    except OSError as exc:
        log('could not remove temp zip: %s' % exc, xbmc.LOGWARNING)


def download(url, dest, dialog):
    """Stream the build to dest, driving the progress dialog. Returns False if cancelled."""
    req = Request(url, headers={'User-Agent': 'StarWave-Wizard'})
    resp = urlopen(req, timeout=30)
    total = resp.getheader('content-length')
    total = int(total) if total and total.isdigit() else 0
    total_mb = total / 1048576.0
    got = 0
    block = 1024 * 256

    with open(dest, 'wb') as fh:
        while True:
            if dialog.iscanceled():
                return False
            chunk = resp.read(block)
            if not chunk:
                break
            fh.write(chunk)
            got += len(chunk)
            if total:
                pct = int(got * 100 / total)
                dialog.update(
                    pct,
                    'Downloading the build\n%.0f of %.0f MB' % (got / 1048576.0, total_mb),
                )
            else:
                dialog.update(0, 'Downloading the build\n%.0f MB' % (got / 1048576.0))

    if total and got < total:
        raise IOError('download truncated: got %d of %d bytes' % (got, total))
    return True


def _skip_addon(name, skip_ids):
    return any(name.startswith('addons/%s/' % a) for a in skip_ids)


def _preserved(name, dest):
    """True when update mode must leave this zip member alone."""
    if name == ADDONS_DB_MEMBER:
        return True
    target_exists = os.path.exists(os.path.join(dest, name.replace('/', os.sep)))
    if not target_exists:
        # Nothing on the device to protect — ship the build's copy so the file
        # is at least present (a missing settings.xml would break the add-on).
        return False
    if name in USER_FILES:
        return True
    parts = name.split('/')
    # userdata/addon_data/<id>/settings.xml — the user's own add-on configuration.
    return (
        len(parts) == 4
        and parts[0] == 'userdata'
        and parts[1] == 'addon_data'
        and parts[3] == 'settings.xml'
    )


def extract(zip_path, dest, dialog, skip_ids=(), preserve=False):
    """Extract into dest, omitting add-ons in skip_ids. Returns False if cancelled.

    With preserve=True (update mode), members carrying user state are not overwritten —
    see _preserved.
    """
    import zipfile

    with zipfile.ZipFile(zip_path) as zf:
        members = [m for m in zf.infolist() if not _skip_addon(m.filename, skip_ids)]
        if preserve:
            members = [m for m in members if not _preserved(m.filename, dest)]
        count = len(members)
        for i, member in enumerate(members):
            if dialog.iscanceled():
                return False
            zf.extract(member, dest)
            if i % 25 == 0 or i == count - 1:
                dialog.update(
                    int(i * 100 / max(count, 1)),
                    'Installing\n%d of %d files' % (i + 1, count),
                )
    return True


def build_addon_ids(zip_path, skip_ids=()):
    """Top-level add-on ids the build zip carries."""
    import zipfile

    ids = set()
    with zipfile.ZipFile(zip_path) as zf:
        for name in zf.namelist():
            parts = name.split('/')
            if len(parts) > 1 and parts[0] == 'addons' and parts[1] and parts[1] != 'packages':
                ids.add(parts[1])
    return sorted(ids - set(skip_ids))


def merge_installed(addon_ids):
    """Register the build's add-ons in the device's own add-on database.

    Update mode keeps the device's Addons33.db (so add-ons the user installed themselves
    stay registered). Any build add-on it does not know yet is inserted enabled; the
    metadata rows for every build add-on are dropped so Kodi re-reads each addon.xml at
    the next start — that is what picks up same-version content changes.
    """
    if not addon_ids or not os.path.exists(ADDONS_DB):
        return
    import sqlite3
    now = time.strftime('%Y-%m-%d %H:%M:%S')
    try:
        con = sqlite3.connect(ADDONS_DB)
        for addon_id in addon_ids:
            con.execute(
                'INSERT INTO installed (addonID, enabled, installDate) '
                'SELECT ?, 1, ? WHERE NOT EXISTS '
                '(SELECT 1 FROM installed WHERE addonID = ?)',
                (addon_id, now, addon_id),
            )
            con.execute('DELETE FROM addons WHERE addonID = ?', (addon_id,))
        con.commit()
        con.close()
        log('merged %d build add-ons into the add-on database' % len(addon_ids))
    except Exception as exc:  # noqa: BLE001
        log('could not merge the add-on database: %s' % exc, xbmc.LOGWARNING)


def drop_from_db(addon_ids):
    """Remove add-ons from the add-on database.

    On a platform where their binaries cannot load, leaving those rows in tells Kodi to
    load them anyway.
    """
    if not addon_ids or not os.path.exists(ADDONS_DB):
        return
    import sqlite3
    try:
        con = sqlite3.connect(ADDONS_DB)
        for addon_id in addon_ids:
            for row in list(con.execute('SELECT id FROM addons WHERE addonID = ?', (addon_id,))):
                con.execute('DELETE FROM addonlinkrepo WHERE idAddon = ?', (row[0],))
            for table in ('addons', 'installed', 'update_rules', 'package'):
                con.execute('DELETE FROM %s WHERE addonID = ?' % table, (addon_id,))
        con.commit()
        con.close()
        log('dropped from add-on database: %s' % ', '.join(addon_ids))
    except Exception as exc:  # noqa: BLE001
        log('could not patch the add-on database: %s' % exc, xbmc.LOGWARNING)


def clear_packages():
    """Drop cached add-on packages so Kodi does not reinstall stale versions."""
    if not os.path.isdir(PACKAGES):
        return
    for name in os.listdir(PACKAGES):
        path = os.path.join(PACKAGES, name)
        try:
            if os.path.isfile(path) or os.path.islink(path):
                os.remove(path)
            else:
                shutil.rmtree(path, ignore_errors=True)
        except OSError as exc:
            log('could not clear %s: %s' % (path, exc), xbmc.LOGWARNING)


def _finish(skip_ids, updated):
    tail = ''
    if skip_ids:
        tail = (
            '\n\nTwo add-ons were skipped because this build carries the Android versions and '
            'they cannot run here: %s. Kodi\'s own copies are untouched. If streams will not '
            'play, install InputStream Adaptive from the Kodi Add-on repository.'
            % ', '.join(skip_ids)
        )
    what = 'updated — your settings and logins were kept' if updated else 'installed'
    xbmcgui.Dialog().ok(
        ADDON_NAME,
        'StarWave is %s.\n\nKodi will now close so it cannot write its old settings back '
        'over the new ones.\n\nReopen Kodi to finish.%s' % (what, tail),
    )
    # Hard exit on purpose. A normal Quit() makes Kodi save its in-memory settings on the way
    # out, which would overwrite the configuration that was just extracted.
    log('%s complete, hard-exiting so Kodi cannot rewrite userdata'
        % ('update' if updated else 'install'))
    xbmc.executebuiltin('InhibitIdleShutdown(true)')
    os._exit(1)


def _apply(update):
    """Shared download-and-extract flow for both modes."""
    skip_ids = () if is_android() else ANDROID_ONLY
    dialog = xbmcgui.DialogProgress()
    dialog.create(ADDON_NAME, 'Starting')
    _cleanup_temp()

    try:
        if not download(BUILD_URL, TEMP_ZIP, dialog):
            dialog.close()
            _cleanup_temp()
            notify('Cancelled')
            return

        dialog.update(0, 'Installing')
        if not extract(TEMP_ZIP, HOME, dialog, skip_ids, preserve=update):
            dialog.close()
            _cleanup_temp()
            xbmcgui.Dialog().ok(
                ADDON_NAME,
                'Cancelled part-way through installing, so this Kodi is now a mix of the old '
                'setup and the new one.\n\nRun the wizard again and let it finish.',
            )
            return

        dialog.update(100, 'Tidying up')
        if update:
            merge_installed(build_addon_ids(TEMP_ZIP, skip_ids))
        drop_from_db(skip_ids)
        clear_packages()
        _cleanup_temp()
        dialog.close()

    except Exception as exc:  # noqa: BLE001 - surface anything that goes wrong to the user
        dialog.close()
        _cleanup_temp()
        log('apply failed: %s' % exc, xbmc.LOGERROR)
        xbmcgui.Dialog().ok(
            ADDON_NAME,
            'The install did not finish.\n\n%s\n\nYour Kodi has not been fully changed. Check '
            'your connection and try again.' % exc,
        )
        return

    _finish(skip_ids, update)


def install():
    ok = xbmcgui.Dialog().yesno(
        ADDON_NAME,
        'Fresh Install replaces your current Kodi setup — skin, home menu, widgets, settings '
        'and the configuration of every add-on the build ships, including saved logins.\n\n'
        'Kodi will close when it finishes. Continue?',
        nolabel='Cancel',
        yeslabel='Install',
    )
    if ok:
        _apply(update=False)


def update():
    if not os.path.isdir(os.path.join(HOME, 'addons', 'skin.NTVaura')):
        xbmcgui.Dialog().ok(
            ADDON_NAME,
            'No StarWave install was found on this Kodi, so there are no settings to keep.\n\n'
            'Use Fresh Install instead.',
        )
        return
    ok = xbmcgui.Dialog().yesno(
        ADDON_NAME,
        'Update brings the skin, menus, widgets and add-ons up to the current build. Your '
        'Kodi settings, sources, favourites and add-on logins are kept.\n\n'
        'Kodi will close when it finishes. Continue?',
        nolabel='Cancel',
        yeslabel='Update',
    )
    if ok:
        _apply(update=True)


def router(qs):
    action = dict(parse_qsl(qs.lstrip('?'))).get('action')
    if action == 'install':
        install()
    elif action == 'update':
        update()
    elif action == 'info':
        show_info()
    else:
        menu()


if __name__ == '__main__':
    router(sys.argv[2] if len(sys.argv) > 2 else '')
