# -*- coding: utf-8 -*-
"""StarWave background service.

Two jobs, both of which exist because the owner should not have to chase updates:

1. FORCE A REPOSITORY CHECK AT EVERY START.
   Kodi keeps a per-repository timer and skips any repo whose timer has not elapsed, so
   restarting Kodi does NOT reliably pick up a new add-on version. That is why a published
   wizard sat unnoticed on a device that had been restarted several times. `UpdateAddonRepos`
   forces the check, so a published update lands on the next launch rather than within 24h.

2. APPLY THE PER-DEVICE FIXES ONCE PER WIZARD VERSION.
   Menu icons, the display/audio tuning and The Gears' scrapers all live in files an Update
   deliberately preserves, so they cannot travel in the payload. Running them here means a
   device fixes itself with no build download and nobody pressing anything.

   Gated on a marker holding the wizard version they last ran for, so this is not redone at
   every boot and does not fight an owner who deliberately changed one of these back.

Deliberately quiet: no modal dialog is ever opened. The skin can strand itself on
"Initialising Skin..." if a modal is up about a second after boot, so the service waits for
Kodi to settle first and only ever posts a notification.
"""

import os
import json

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
VERSION = ADDON.getAddonInfo('version')

PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
MARKER = os.path.join(PROFILE, 'autofix.json')

# Let Kodi finish starting before touching anything. The startup skin race is real and the
# cost of waiting is nothing - none of this is time critical.
SETTLE_SECONDS = 45


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[%s.service] %s' % (ADDON_ID, msg), level)


def _already_done():
    try:
        with open(MARKER, 'r', encoding='utf-8') as fh:
            return json.load(fh).get('version')
    except Exception:  # noqa: BLE001 - absent or unreadable both mean "not done"
        return None


def _mark(applied):
    try:
        if not os.path.isdir(PROFILE):
            os.makedirs(PROFILE)
        with open(MARKER, 'w', encoding='utf-8') as fh:
            json.dump({'version': VERSION, 'applied': applied}, fh, indent=2)
    except Exception as exc:  # noqa: BLE001
        log('could not write the marker: %s' % exc, xbmc.LOGWARNING)


def run():
    monitor = xbmc.Monitor()
    if monitor.waitForAbort(SETTLE_SECONDS):
        return

    # 1. Always force the repository check - this is the whole point of running at startup.
    log('forcing a repository check')
    xbmc.executebuiltin('UpdateAddonRepos')

    # 2. The per-device fixes, once per wizard version.
    if _already_done() == VERSION:
        log('per-device fixes already applied for %s' % VERSION)
        return

    try:
        import default as wizard
    except Exception as exc:  # noqa: BLE001
        log('could not load the wizard: %s' % exc, xbmc.LOGERROR)
        return

    applied = []
    try:
        menu = wizard.sync_menu_icons()
        if menu:
            # The generated menu is built FROM the files just changed, so it has to be dropped.
            # The rebuild happens on the next start; no skin reload is attempted here, because
            # reloading the skin during startup is exactly what strands it.
            wizard.force_menu_rebuild()
        applied += menu
        applied += wizard.tune_this_device(on_disk=False)
        applied += wizard.fix_gears_scrapers()
    except Exception as exc:  # noqa: BLE001 - a failed autofix must never break Kodi startup
        log('autofix failed: %s' % exc, xbmc.LOGERROR)
        return

    _mark(applied)
    if not applied:
        log('nothing needed fixing for %s' % VERSION)
        return

    log('applied: %s' % ' | '.join(applied))
    import xbmcgui
    xbmcgui.Dialog().notification(
        ADDON_NAME,
        'Applied %d fix%s for this device' % (len(applied), '' if len(applied) == 1 else 'es'),
        ADDON.getAddonInfo('icon'), 6000)
    if menu:
        xbmcgui.Dialog().notification(
            ADDON_NAME, 'Menu icons updated - restart Kodi to see them',
            ADDON.getAddonInfo('icon'), 8000)


if __name__ == '__main__':
    run()
