# -*- coding: utf-8 -*-
"""StarWave background service.

Two jobs, both of which exist because the owner should not have to chase updates:

1. FORCE A REPOSITORY CHECK AT EVERY START.
   Kodi keeps a per-repository timer and skips any repo whose timer has not elapsed, so
   restarting Kodi does NOT reliably pick up a new add-on version. That is why a published
   wizard sat unnoticed on a device that had been restarted several times. `UpdateAddonRepos`
   forces the check, so a published update lands on the next launch rather than within 24h.

2. APPLY THE PER-DEVICE FIXES ONCE PER WIZARD VERSION.
   Menu icons, the display/audio tuning and The Gears' scrapers all live in files an Update
   deliberately preserves, so they cannot travel in the payload. Running them here means a
   device fixes itself with no build download and nobody pressing anything.

   Gated on a marker holding the wizard version they last ran for, so this is not redone at
   every boot and does not fight an owner who deliberately changed one of these back.

Deliberately quiet: no modal dialog is ever opened. The skin can strand itself on
"Initialising Skin..." if a modal is up about a second after boot, so the service waits for
Kodi to settle first and only ever posts a notification.
"""

import os
import json

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
VERSION = ADDON.getAddonInfo('version')

PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
MARKER = os.path.join(PROFILE, 'autofix.json')

# Let Kodi finish starting before touching anything. The startup skin race is real and the
# cost of waiting is nothing - none of this is time critical.
SETTLE_SECONDS = 45

SKIN_UPDATED = []


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[%s.service] %s' % (ADDON_ID, msg), level)


def _repo_installed():
    """True when repository.starwave is present and enabled - i.e. this device has an update
    source. Installing the wizard straight from its zip skips the repository entirely."""
    try:
        xbmcaddon.Addon('repository.starwave')
        return True
    except Exception:  # noqa: BLE001 - Addon() raises for an id that is not installed
        return False


def _already_done():
    try:
        with open(MARKER, 'r', encoding='utf-8') as fh:
            return json.load(fh).get('version')
    except Exception:  # noqa: BLE001 - absent or unreadable both mean "not done"
        return None


def _mark(applied, pending_menu=False):
    try:
        if not os.path.isdir(PROFILE):
            os.makedirs(PROFILE)
        with open(MARKER, 'w', encoding='utf-8') as fh:
            json.dump({'version': VERSION, 'applied': applied,
                       'menu_rebuild_pending': bool(pending_menu)}, fh, indent=2)
    except Exception as exc:  # noqa: BLE001
        log('could not write the marker: %s' % exc, xbmc.LOGWARNING)


def _menu_pending():
    try:
        with open(MARKER, 'r', encoding='utf-8') as fh:
            return bool(json.load(fh).get('menu_rebuild_pending'))
    except Exception:  # noqa: BLE001
        return False


def _clear_pending():
    try:
        with open(MARKER, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        data['menu_rebuild_pending'] = False
        with open(MARKER, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, indent=2)
    except Exception:  # noqa: BLE001
        pass


def set_window_properties():
    """Set Window(10000) properties for Home skin rules: StarWave.BuildVersion and StarWave.WizardVersion."""
    try:
        import xbmcgui
        import default as wizard
        win = xbmcgui.Window(10000)
        b_ver = wizard.get_build_version()
        w_ver = wizard.get_wizard_version()
        win.setProperty('StarWave.BuildVersion', b_ver)
        win.setProperty('StarWave.WizardVersion', w_ver)
        log('set window properties: StarWave.BuildVersion=%s, StarWave.WizardVersion=%s' % (b_ver, w_ver))
    except Exception as exc:  # noqa: BLE001
        log('could not set window properties: %s' % exc, xbmc.LOGWARNING)


def run():
    # 0. Always set Home window properties for version rules at startup
    set_window_properties()

    monitor = xbmc.Monitor()
    if monitor.waitForAbort(SETTLE_SECONDS):
        return

    # 1. Always force the repository check - this is the whole point of running at startup.
    log('forcing a repository check')
    xbmc.executebuiltin('UpdateAddonRepos')

    # A device can end up with the wizard but NOT the repository, because the repo's datadir is
    # the site root, so every add-on folder is browsable in "Install from zip" and any of them
    # can be installed directly. That works, and then nothing ever updates again - there is no
    # repository offering newer versions. Silent, and exactly the failure this service exists to
    # prevent, so say it out loud once.
    # A skin whose record disagrees with the files on disk will never update itself, silently.
    try:
        import default as _w
        fixed = _w.ensure_skin_current()
        if fixed:
            log(fixed)
            SKIN_UPDATED.append(fixed)
    except Exception as exc:  # noqa: BLE001 - never break startup over this
        log('skin repair check failed: %s' % exc, xbmc.LOGWARNING)

    try:
        import default as _w
        lines = _w.ensure_addons_current()
        for line in (lines or []):
            log(line)
    except Exception as exc:  # noqa: BLE001 - never break startup over this
        log('add-on self-update check failed: %s' % exc, xbmc.LOGWARNING)

    if not _repo_installed():
        log('repository.starwave is NOT installed - this device cannot receive updates',
            xbmc.LOGWARNING)
        import xbmcgui
        xbmcgui.Dialog().notification(
            ADDON_NAME, 'StarWave Repository missing - updates are off',
            ADDON.getAddonInfo('icon'), 9000)

    # 2. The per-device fixes, once per wizard version.
    if _already_done() == VERSION and not _menu_pending():
        log('per-device fixes already applied for %s' % VERSION)
        return

    try:
        import default as wizard
    except Exception as exc:  # noqa: BLE001
        log('could not load the wizard: %s' % exc, xbmc.LOGERROR)
        return

    applied = []
    menu = []
    sly_ok = True
    try:
        # Writing the .DATA.xml / .properties is safe at runtime: nothing reads them while Kodi
        # runs, only skinshortcuts during a rebuild.
        menu = wizard.sync_menu_icons()
        applied += [l for l in menu if not l.startswith('[COLOR red]')]
        applied += [l for l in wizard.tune_this_device(on_disk=False) if not l.startswith('[COLOR red]')]
        applied += [l for l in wizard.fix_gears_scrapers() if not l.startswith('[COLOR red]')]
        sly_lines, sly_ok = wizard.ensure_slyguy()
        applied += [l for l in sly_lines if not l.startswith('[COLOR red]')]
    except Exception as exc:  # noqa: BLE001 - a failed autofix must never break Kodi startup
        log('autofix failed: %s' % exc, xbmc.LOGERROR)
        return

    applied += SKIN_UPDATED
    if sly_ok:
        _mark(applied, pending_menu=bool(menu) or bool(SKIN_UPDATED))
    else:
        log('ensure_slyguy did not complete successfully; pass will retry on next start',
            xbmc.LOGWARNING)

    if applied:
        log('applied: %s' % ' | '.join(applied))
        import xbmcgui
        xbmcgui.Dialog().notification(
            ADDON_NAME,
            'Applied %d fix%s for this device' % (len(applied), '' if len(applied) == 1 else 'es'),
            ADDON.getAddonInfo('icon'), 6000)
        if menu:
            xbmcgui.Dialog().notification(
                ADDON_NAME, 'New menu icons apply next time Kodi starts',
                ADDON.getAddonInfo('icon'), 8000)
    else:
        log('nothing needed fixing for %s' % VERSION)

    # THE MENU REBUILD IS DEFERRED TO SHUTDOWN, ON PURPOSE.
    #
    # force_menu_rebuild() deletes the skin's generated script-skinshortcuts-includes.xml, which
    # is the file the RUNNING skin draws its menu from. Doing that mid-session pulls the rug from
    # under a live skin, and this skin is already known to strand itself on "Initialising Skin..."
    # Waiting for abort costs nothing - a Kodi service is expected to live until shutdown - and
    # at that point nothing is drawing the menu, so the next start regenerates cleanly.
    #
    # If Kodi is force-killed the hook never runs, the pending flag survives, and the next
    # shutdown picks it up. That is why the flag is on disk rather than in memory.
    monitor.waitForAbort()
    if _menu_pending():
        try:
            wizard.force_menu_rebuild()
            _clear_pending()
            log('menu rebuild armed at shutdown; it regenerates on the next start')
        except Exception as exc:  # noqa: BLE001
            log('could not arm the menu rebuild: %s' % exc, xbmc.LOGWARNING)


if __name__ == '__main__':
    run()
